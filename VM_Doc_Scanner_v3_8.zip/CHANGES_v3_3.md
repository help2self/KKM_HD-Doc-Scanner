# VM Doc Scanner – v3.3 changes

Composer
1. Resize handle icon is now a diagonal (top-left <-> bottom-right) double arrow.
2. Rotate slider removed (rotate with the on-picture handle).
3. "Full screen" button now works: Fit to page (biggest size inside margins, same proportions, centred).
4. Text box: tap Edit icon or double-tap to edit text. Box height follows wrapped text. Corner handle scales
   box + text together; side handle changes width only (text re-wraps). Export uses the same layout
   (processing/TextBoxLayout.kt), so saved page = what you see.

Camera / filters
5. Capture JPEG quality 100, lossless-ish re-save, editor preview 2200 px (was 1500).
6. All colour/gray filters get a luminance unsharp-mask (crisp text). Remove Shadow rebuilt: fine
   paper-brightness map (160 px grid) + floor so dark content is not washed out.

Export: format chips read only PDF / JPEG / PNG. JPG/PNG exports now carry DPI metadata.

Passport sheet
7. Photo size and Sheet size are dropdowns; "Custom" shows width/height with in / cm / px.
8. Real DPI setting (chips + number). Sheet is rendered at that DPI and DPI is written into the file
   (JPEG JFIF density / PNG pHYs). Buttons: Save sheet as JPEG / PNG straight to gallery.

Image quality (round 2)
9. downscale(): big reductions in exact 2x steps (true averaging) – used by decode, import, editor preview,
   thumbnails. Less jagged / soft text.
10. denoiseDark(): edge-preserving 3x3 sigma filter, only on dark / shadow areas, before the lighting
    correction (which amplifies noise). Memory: 3 spare rows only.
11. android:largeHeap="true" in the manifest (large photos + filters).
12. warpPerspective: bicubic (Catmull-Rom) sampling, run in parallel bands on all CPU cores; if the page must be
    reduced >1.5x the source is first averaged down (no skipped pixels).

# v3.4 fixes (on top of v3.3)
- v3.3 did not compile: ImageProcessor.kt had lost 14 functions (downscale, solveHomography, detectCorners,
  detectCornersSync, paintWhiteSpots, refineQuadByLines, fitLine, boxBlur3, erode3, largestRegion,
  extremeCorners, isSensibleQuad, ...). All restored; downscale() rewritten with exact 2x averaging steps
  as v3.3 intended.
- Composer "Fit to page" for text now also respects page height (text never runs off the page).
- Verified: full `gradle assembleDebug` build passes (Gradle 9.3.1, AGP 9.1.1, KSP 2.3.6, SDK 36).

## v3.5 (2026-11-03)
1. HD: corner crop ab 4096px tak ki photo se hota hai (pehle 3200), warp maxEdge 4096 (pehle 3000). Page ~30% zyada pixels.
2. Saaf syahi: Magic Color / Remove Shadow / Auto / Grayscale mein naya inkBoost (image ke sabse gehre 0.5% ko near-black, mid-tone gamma, colored ink vivid). Paper safed hi rehta hai.
3. PDF export button: "Save to Files" (Documents), images Gallery mein.
4. Editor filter panel compact (thumbnails 56x70dp).
5. Adjust aur Rotate tab mein Reset button.
6. Signature: bada pad, pen width, 3 color, undo, signature save/reuse; page par layer (ungli se move, do ungli se resize, size slider, delete). Save full resolution par.
7. "Cover Brush": width slider, 5 color (white, black, blue, red, yellow highlight), undo/clear; full resolution par save.

## v3.6 (2026-11-03)
1. Composer text box: box = exact text size (auto width/height), only rotate + resize handles on the box; delete moved to toolbar. New format bar: 7 fonts, Bold/Italic/Underline, align L/C/R, size -/+, 7 colours. Exported page uses the same layout (TextBoxLayout.fit/draw).
2. Camera: batch only (Single/Batch chips removed). Smaller shutter (66dp ring). Last photo thumbnail + count badge on the camera screen; tap or "Review" opens the filter screen. Gallery + phone-camera as small labelled icons.
3. Filter screen (BatchReview) redesigned OKEN-style: cropped + filtered page large in a pager (1/n arrows), editable doc name, Done; filter strip with real previews; "Apply to all pages" checkbox; Retake / Add / Left rotate / Crop / Delete.
4. Document screen: Select mode (top icon, bottom button or long press). Tap order = number badge. Selected pages: Save to Gallery (JPEG), Share, Export (PDF etc. with only those pages), Delete. "Tap to add new pages" tile + Add button: new batch is appended to the same document.
5. Settings: About card with app name, version (3.6, code 36), description.

## v3.7 (2026-11-03)
- Signature: full-screen signing pad; every saved signature kept in a list (filesDir/signatures), tap to place, x to delete. Old my_signature.png migrated.
- True page ratio: warpPerspective estimates the real width/height from the 4 corners (Zhang-He, focal length solved), snaps to A4/Letter/Legal/ID within 3%. Tilted photos no longer squash/stretch.
- Camera preview FIT_CENTER in its own area (top bar | 4:3 preview | controls), nothing cropped or stretched; live outline mapping updated.
- Double inset gap removed app-wide (consumeWindowInsets in MainActivity). Filter screen: smaller filter thumbnails and action bar, bigger image.
- Remove Shadow: per-channel paper division + neutralise near-grey pixels (no blue haze), satBoost 0.1, dilate 3.
- Update without uninstall: fixed signing key vmdoc-stable.keystore in project root used by the debug signingConfig. versionCode 37 / 3.7. Keep this file in every future zip.

## v3.8 (2026-11-03)
- Page detection: new edge + Hough line detector (CamScanner style) works with white paper on light background; competes with colour-region detector. If no page border is visible, the page is still de-skewed/de-keystoned from the tilt of heading bars / borders / rules.
- Camera: removed the separate "Review batch" button (thumbnail with count opens the filter screen).
- Signatures: any number of signatures per page; tap to select, drag/pinch/slider to resize, delete removes the selected one.
- Composer text: new text starts readable (48 size, shrunk to page width if long), box = text size; alignment buttons removed; placeholder localised.
- versionCode 38 / versionName 3.8, same stable keystore.
