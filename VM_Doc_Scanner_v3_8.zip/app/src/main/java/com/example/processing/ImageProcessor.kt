package com.example.processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.example.data.model.ComposedObject
import com.example.data.model.ComposedPageConfig
import com.example.data.model.CornerPoints
import com.example.data.model.EditParameters
import com.example.data.model.FilterType
import com.example.data.model.ObjectType
import com.example.data.model.PageOrientation
import com.example.data.model.PassportConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object ImageProcessor {

    suspend fun loadBitmapFromFile(path: String, maxDimension: Int? = null): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            if (!file.exists()) return@withContext null

            if (maxDimension == null) {
                return@withContext BitmapFactory.decodeFile(path)
            }

            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, options)

            var sampleSize = 1
            val maxEdge = max(options.outWidth, options.outHeight)
            while (maxEdge / (sampleSize * 2) >= maxDimension) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(path, decodeOptions)
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    suspend fun saveBitmapToFile(bitmap: Bitmap, file: File, format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG, quality: Int = 97, dpi: Int = 0): Boolean = withContext(Dispatchers.IO) {
        try {
            file.parentFile?.mkdirs()
            FileOutputStream(file).use { out ->
                bitmap.compress(format, quality, out)
            }
            if (dpi > 0) DpiMetadata.write(file, dpi)
            true
        } catch (e: Throwable) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Loads a JPEG/PNG from disk with its EXIF orientation applied, so a photo taken in portrait
     * looks portrait (BitmapFactory ignores EXIF by itself, which made captured pages appear rotated).
     * The longest edge is limited to [maxEdge] to keep memory use safe.
     */
    fun decodeOriented(path: String, maxEdge: Int = 4096): Bitmap? {
        return try {
            val file = File(path)
            if (!file.exists()) return null

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            val longest = max(bounds.outWidth, bounds.outHeight)
            if (longest <= 0) return null

            var sample = 1
            while (longest / (sample * 2) >= maxEdge) sample *= 2

            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            var bmp = BitmapFactory.decodeFile(path, opts) ?: return null

            // Exact downscale to maxEdge if still larger (high quality, 2x steps)
            if (max(bmp.width, bmp.height) > maxEdge) {
                val scaled = downscale(bmp, maxEdge)
                if (scaled !== bmp) bmp.recycle()
                bmp = scaled
            }

            val orientation = try {
                android.media.ExifInterface(path).getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION,
                    android.media.ExifInterface.ORIENTATION_NORMAL
                )
            } catch (e: Throwable) {
                android.media.ExifInterface.ORIENTATION_NORMAL
            }

            val m = Matrix()
            when (orientation) {
                android.media.ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                android.media.ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                android.media.ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                android.media.ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
                android.media.ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
                else -> {}
            }
            if (m.isIdentity) {
                bmp
            } else {
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (rotated != bmp) bmp.recycle()
                rotated
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Makes a freshly captured / imported photo "upright" on disk: applies EXIF rotation, rewrites
     * the file without needing EXIF afterwards, and returns a bitmap limited to [previewEdge].
     */
    suspend fun importPhoto(file: File, previewEdge: Int = 2400): Bitmap? = withContext(Dispatchers.IO) {
        val upright = decodeOriented(file.absolutePath, 4096) ?: return@withContext null
        try {
            FileOutputStream(file).use { out -> upright.compress(Bitmap.CompressFormat.JPEG, 100, out) }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
        val small = downscale(upright, previewEdge)
        if (small !== upright) upright.recycle()
        small
    }

    /**
     * Straightens the cropped page. Uses a bicubic (Catmull-Rom) sampler, which keeps thin strokes much
     * sharper than bilinear, spread over all CPU cores so saving stays quick. When the page has to be
     * reduced noticeably, the source is first averaged down so no pixels are skipped (no jagged text).
     */
    /**
     * True width / height of the paper from its 4 corners in the photo (Zhang & He, whiteboard scanning).
     * The focal length is solved from the corners; if that is not possible a typical phone lens is used.
     * Results within 3 % of a standard paper (A4, Letter, Legal, ID card) snap to it.
     * Corner arrays are in TL, TR, BR, BL order, pixel units of a full (uncropped) photo.
     */
    fun estimateAspectRatio(sx: DoubleArray, sy: DoubleArray, imgW: Int, imgH: Int): Double? {
        try {
            val u0 = imgW / 2.0; val v0 = imgH / 2.0
            fun v(i: Int) = doubleArrayOf(sx[i] - u0, sy[i] - v0, 1.0)
            val m1 = v(0); val m2 = v(1); val m4 = v(2); val m3 = v(3) // tl, tr, br, bl
            fun cross(a: DoubleArray, b: DoubleArray) = doubleArrayOf(
                a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]
            )
            fun dot(a: DoubleArray, b: DoubleArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
            val c14 = cross(m1, m4)
            val d2 = dot(cross(m2, m4), m3)
            val d3 = dot(cross(m3, m4), m2)
            if (kotlin.math.abs(d2) < 1e-9 || kotlin.math.abs(d3) < 1e-9) return null
            val k2 = dot(c14, m3) / d2
            val k3 = dot(c14, m2) / d3
            val n2 = doubleArrayOf(k2 * m2[0] - m1[0], k2 * m2[1] - m1[1], k2 * m2[2] - m1[2])
            val n3 = doubleArrayOf(k3 * m3[0] - m1[0], k3 * m3[1] - m1[1], k3 * m3[2] - m1[2])
            val big = max(imgW, imgH).toDouble()
            var f2 = (0.78 * big) * (0.78 * big)
            val den = n2[2] * n3[2]
            if (kotlin.math.abs(den) > 1e-12) {
                val cand = -(n2[0] * n3[0] + n2[1] * n3[1]) / den
                if (cand > (0.5 * big) * (0.5 * big) && cand < (2.5 * big) * (2.5 * big)) f2 = cand
            }
            val a = n2[0] * n2[0] / f2 + n2[1] * n2[1] / f2 + n2[2] * n2[2]
            val b = n3[0] * n3[0] / f2 + n3[1] * n3[1] / f2 + n3[2] * n3[2]
            if (a <= 0 || b <= 0) return null
            var r = kotlin.math.sqrt(a / b)
            if (r.isNaN() || r < 0.2 || r > 5.0) return null
            // Snap to standard paper sizes
            val std = doubleArrayOf(1 / 1.4142, 1 / 1.2941, 1 / 1.6471, 1 / 1.5858, 1.0)
            for (q in std) {
                if (kotlin.math.abs(r / q - 1) < 0.03) { r = q; break }
                if (kotlin.math.abs(r * q - 1) < 0.03) { r = 1 / q; break }
            }
            return r
        } catch (e: Exception) {
            return null
        }
    }

    suspend fun warpPerspective(original: Bitmap, corners: CornerPoints, maxEdge: Int? = 4096): Bitmap = withContext(Dispatchers.Default) {
        var srcBmp = original
        var ow = srcBmp.width
        var oh = srcBmp.height

        fun quad(): Pair<DoubleArray, DoubleArray> = Pair(
            doubleArrayOf(
                (corners.tlX * ow).toDouble(), (corners.trX * ow).toDouble(),
                (corners.brX * ow).toDouble(), (corners.blX * ow).toDouble()
            ),
            doubleArrayOf(
                (corners.tlY * oh).toDouble(), (corners.trY * oh).toDouble(),
                (corners.brY * oh).toDouble(), (corners.blY * oh).toDouble()
            )
        )

        var (sx, sy) = quad()
        val quadW = max(hypot(sx[1] - sx[0], sy[1] - sy[0]), hypot(sx[2] - sx[3], sy[2] - sy[3]))
        val quadH = max(hypot(sx[3] - sx[0], sy[3] - sy[0]), hypot(sx[2] - sx[1], sy[2] - sy[1]))

        // Real page proportions: undo the camera tilt (perspective makes the far side look shorter),
        // so an A4 page stays 1 : 1.414 instead of being squashed or stretched.
        val trueRatio = estimateAspectRatio(sx, sy, ow, oh)
        var dstW: Int
        var dstH: Int
        if (trueRatio != null) {
            val longSide = max(quadW, quadH)
            if (trueRatio >= 1.0) { dstW = longSide.toInt(); dstH = (longSide / trueRatio).toInt() }
            else { dstH = longSide.toInt(); dstW = (longSide * trueRatio).toInt() }
            dstW = dstW.coerceAtLeast(100); dstH = dstH.coerceAtLeast(100)
        } else {
            dstW = quadW.toInt().coerceAtLeast(100)
            dstH = quadH.toInt().coerceAtLeast(100)
        }
        if (maxEdge != null && max(dstW, dstH) > maxEdge) {
            val s = maxEdge.toFloat() / max(dstW, dstH)
            dstW = (dstW * s).toInt().coerceAtLeast(100)
            dstH = (dstH * s).toInt().coerceAtLeast(100)
        }

        // Reduction ratio source -> output. Above ~1.5x, average the source down first.
        val ratio = max(quadW / dstW, quadH / dstH).toFloat()
        var ownsSrc = false
        if (ratio > 1.5f) {
            val target = (max(ow, oh) / ratio).toInt().coerceAtLeast(max(dstW, dstH))
            val reduced = downscale(srcBmp, target)
            if (reduced !== srcBmp) {
                srcBmp = reduced
                ownsSrc = true
                ow = srcBmp.width
                oh = srcBmp.height
                val q = quad(); sx = q.first; sy = q.second
            }
        }

        // H maps OUTPUT pixel -> SOURCE pixel (inverse mapping, no holes)
        val dx = doubleArrayOf(0.0, dstW.toDouble(), dstW.toDouble(), 0.0)
        val dy = doubleArrayOf(0.0, 0.0, dstH.toDouble(), dstH.toDouble())
        val h = solveHomography(dx, dy, sx, sy)
            ?: return@withContext Bitmap.createScaledBitmap(original, dstW, dstH, true)

        val src = IntArray(ow * oh)
        srcBmp.getPixels(src, 0, ow, 0, 0, ow, oh)
        if (ownsSrc) srcBmp.recycle()
        val out = IntArray(dstW * dstH)
        val maxX = ow - 1
        val maxY = oh - 1

        // Rows are independent, so split them into bands and run the bands in parallel
        val bands = Runtime.getRuntime().availableProcessors().coerceIn(1, 8) * 2
        val rowsPerBand = (dstH + bands - 1) / bands
        coroutineScope {
            (0 until bands).map { band ->
                async(Dispatchers.Default) {
                    val xo = IntArray(4); val yo = IntArray(4)
                    val wx = FloatArray(4); val wy = FloatArray(4)
                    val yStart = band * rowsPerBand
                    val yEnd = minOf(dstH, yStart + rowsPerBand)
                    for (y in yStart until yEnd) {
                        val yc = y + 0.5
                        var nx = h[0] * 0.5 + h[1] * yc + h[2]
                        var ny = h[3] * 0.5 + h[4] * yc + h[5]
                        var nw = h[6] * 0.5 + h[7] * yc + 1.0
                        val row = y * dstW
                        for (x in 0 until dstW) {
                            val fx = nx / nw - 0.5
                            val fy = ny / nw - 0.5
                            nx += h[0]; ny += h[3]; nw += h[6]

                            if (fx < -1.0 || fy < -1.0 || fx > ow.toDouble() || fy > oh.toDouble()) {
                                out[row + x] = -0x1 // white outside the photo
                                continue
                            }
                            val x0 = kotlin.math.floor(fx).toInt()
                            val y0 = kotlin.math.floor(fy).toInt()
                            val ax = (fx - x0).toFloat()
                            val ay = (fy - y0).toFloat()
                            catmullRom(ax, wx)
                            catmullRom(ay, wy)
                            for (k in 0..3) {
                                xo[k] = (x0 - 1 + k).coerceIn(0, maxX)
                                yo[k] = (y0 - 1 + k).coerceIn(0, maxY) * ow
                            }
                            var r = 0f; var g = 0f; var b = 0f
                            for (j in 0..3) {
                                val ro = yo[j]
                                val wyj = wy[j]
                                for (i in 0..3) {
                                    val c = src[ro + xo[i]]
                                    val w = wx[i] * wyj
                                    r += ((c shr 16) and 0xFF) * w
                                    g += ((c shr 8) and 0xFF) * w
                                    b += (c and 0xFF) * w
                                }
                            }
                            out[row + x] = (0xFF shl 24) or
                                ((r + 0.5f).toInt().coerceIn(0, 255) shl 16) or
                                ((g + 0.5f).toInt().coerceIn(0, 255) shl 8) or
                                (b + 0.5f).toInt().coerceIn(0, 255)
                        }
                    }
                }
            }.forEach { it.await() }
        }

        val result = Bitmap.createBitmap(dstW, dstH, Bitmap.Config.ARGB_8888)
        result.setPixels(out, 0, dstW, 0, 0, dstW, dstH)
        result
    }

    /** Catmull-Rom weights for the 4 taps around a sample at fractional offset [t] (they sum to 1). */
    private fun catmullRom(t: Float, w: FloatArray) {
        val t2 = t * t
        val t3 = t2 * t
        w[0] = -0.5f * t3 + t2 - 0.5f * t
        w[1] = 1.5f * t3 - 2.5f * t2 + 1f
        w[2] = -1.5f * t3 + 2f * t2 + 0.5f * t
        w[3] = 0.5f * t3 - 0.5f * t2
    }


    /**
     * Returns a copy limited to [maxEdge] on its longest side (or the same bitmap if already small).
     * Big reductions are done in exact 2x halving steps (each step averages 2x2 pixels), then one
     * final filtered scale, so small text stays smooth instead of jagged.
     */
    fun downscale(src: Bitmap, maxEdge: Int): Bitmap {
        val longest = max(src.width, src.height)
        if (maxEdge <= 0 || longest <= maxEdge) return src
        var cur = src
        while (max(cur.width, cur.height) / 2 >= maxEdge && cur.width >= 4 && cur.height >= 4) {
            val half = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = half
        }
        val l = max(cur.width, cur.height)
        if (l <= maxEdge) return cur
        val s = maxEdge.toFloat() / l
        val out = Bitmap.createScaledBitmap(
            cur,
            (cur.width * s).toInt().coerceAtLeast(1),
            (cur.height * s).toInt().coerceAtLeast(1),
            true
        )
        if (out !== cur && cur !== src) cur.recycle()
        return out
    }

    /** Paints white circles (whiten brush). Points are normalised 0..1 positions on the bitmap. */
    fun paintWhiteSpots(src: Bitmap, points: List<Pair<Float, Float>>, radiusFraction: Float = 0.03f): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val paint = Paint().apply {
            color = Color.WHITE
            isAntiAlias = true
            style = Paint.Style.FILL
        }
        val r = out.width * radiusFraction
        for ((nx, ny) in points) {
            canvas.drawCircle(nx * out.width, ny * out.height, r, paint)
        }
        return out
    }

    suspend fun detectCorners(bitmap: Bitmap): Pair<CornerPoints, Boolean> = withContext(Dispatchers.Default) {
        val (otsu, ok) = detectCornersSync(bitmap, 320)
        // Second detector (CamScanner style): straight edges + Hough lines. Finds the page even when it
        // is white on a light table, fills the frame, or only a printed border is visible.
        val best = try { detectByLines(bitmap, if (ok) otsu else null) } catch (e: Throwable) { e.printStackTrace(); null }
        if (best != null) Pair(best, true) else Pair(otsu, ok)
    }

    /**
     * Edge / line based page finder. Strong straight lines are found with a Hough transform (votes only
     * from edge pixels whose gradient matches the line direction, so text does not create lines). Every
     * pair of near-vertical + pair of near-horizontal lines (the frame borders count as weak candidates)
     * makes a 4-sided candidate; it is scored by how much of each side really lies on an edge, and the
     * biggest well-supported quad wins. The colour-region result competes on the same score.
     */
    private fun detectByLines(bitmap: Bitmap, regionQuad: CornerPoints?): CornerPoints? {
        val maxDim = 480
        val sc = min(1f, maxDim.toFloat() / max(bitmap.width, bitmap.height))
        val w = (bitmap.width * sc).toInt().coerceAtLeast(32)
        val h = (bitmap.height * sc).toInt().coerceAtLeast(32)
        val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small != bitmap) small.recycle()
        var g = IntArray(w * h) { val c = px[it]; (((c shr 16) and 0xFF) * 77 + ((c shr 8) and 0xFF) * 150 + (c and 0xFF) * 29) shr 8 }
        g = boxBlur3(g, w, h)

        // Sobel
        val n = w * h
        val gxA = FloatArray(n); val gyA = FloatArray(n); val mag = FloatArray(n)
        val magHist = IntArray(1024)
        for (y in 0 until h) {
            val y0 = max(0, y - 1) * w; val y1 = y * w; val y2 = min(h - 1, y + 1) * w
            for (x in 0 until w) {
                val x0 = max(0, x - 1); val x2 = min(w - 1, x + 1)
                val gx = (g[y0 + x2] + 2 * g[y1 + x2] + g[y2 + x2]) - (g[y0 + x0] + 2 * g[y1 + x0] + g[y2 + x0])
                val gy = (g[y2 + x0] + 2 * g[y2 + x] + g[y2 + x2]) - (g[y0 + x0] + 2 * g[y0 + x] + g[y0 + x2])
                val i = y1 + x
                gxA[i] = gx.toFloat(); gyA[i] = gy.toFloat()
                val m = kotlin.math.sqrt((gx * gx + gy * gy).toFloat())
                mag[i] = m
                magHist[m.toInt().coerceIn(0, 1023)]++
            }
        }
        var acc0 = 0; var p65 = 0
        for (v in 0 until 1024) { acc0 += magHist[v]; if (acc0 >= n * 0.65) { p65 = v; break } }
        val thr = max(20, p65).toFloat()

        // Edge classes: "vertical edge" (normal mostly horizontal) and "horizontal edge", each dilated 2 px
        val vEdge = BooleanArray(n); val hEdge = BooleanArray(n)
        val diag = hypot(w.toFloat(), h.toFloat()).toInt() + 1
        val rN = 2 * diag + 1
        val acc = IntArray(180 * rN)
        val cosT = FloatArray(180) { cos(Math.toRadians(it.toDouble())).toFloat() }
        val sinT = FloatArray(180) { sin(Math.toRadians(it.toDouble())).toFloat() }
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (mag[i] <= thr) continue
            val ax = kotlin.math.abs(gxA[i]) / mag[i]
            if (ax > 0.9f) vEdge[i] = true
            if (ax < 0.44f) hEdge[i] = true
            var deg = Math.toDegrees(atan2(gyA[i].toDouble(), gxA[i].toDouble())).toInt()
            deg = ((deg % 180) + 180) % 180
            for (dt in -2..2) {
                val t = (deg + dt + 180) % 180
                val r = (x * cosT[t] + y * sinT[t]).toInt() + diag
                if (r in 0 until rN) acc[t * rN + r]++
            }
        }
        val vD = dilate2(vEdge, w, h); val hD = dilate2(hEdge, w, h)

        // Peaks (with suppression) in a range of normal angles
        fun peaks(vertical: Boolean): MutableList<FloatArray> {
            val out = ArrayList<FloatArray>()
            val a = acc.copyOf()
            for (t in 0 until 180) {
                val ok = if (vertical) (t <= 30 || t >= 150) else (t in 60..120)
                if (!ok) java.util.Arrays.fill(a, t * rN, (t + 1) * rN, 0)
            }
            val minVotes = (0.15f * min(w, h)).toInt()
            repeat(14) {
                var bi = 0; var bv = 0
                for (k in a.indices) if (a[k] > bv) { bv = a[k]; bi = k }
                if (bv < minVotes) return out
                val t = bi / rN; val r = bi % rN - diag
                out.add(floatArrayOf(cosT[t], sinT[t], r.toFloat(), 0f))
                for (tt in t - 6..t + 6) {
                    val tm = ((tt % 180) + 180) % 180
                    for (rr in (bi % rN - 8)..(bi % rN + 8)) if (rr in 0 until rN) a[tm * rN + rr] = 0
                    // a line near theta 0 is the same as theta 180 with -r
                    if (tt < 0 || tt >= 180) {
                        val mr = 2 * diag - (bi % rN)
                        for (rr in (mr - 8)..(mr + 8)) if (rr in 0 until rN) a[tm * rN + rr] = 0
                    }
                }
            }
            return out
        }
        val vLines = peaks(true)
        val hLines = peaks(false)
        val vPeaks = vLines.toList()
        val hPeaks = hLines.toList()
        // frame borders as weak candidates (last value 1 = frame)
        vLines.add(floatArrayOf(1f, 0f, 0f, 1f)); vLines.add(floatArrayOf(1f, 0f, (w - 1).toFloat(), 1f))
        hLines.add(floatArrayOf(0f, 1f, 0f, 1f)); hLines.add(floatArrayOf(0f, 1f, (h - 1).toFloat(), 1f))

        fun inter(a: FloatArray, b: FloatArray): FloatArray? {
            val det = a[0] * b[1] - b[0] * a[1]
            if (kotlin.math.abs(det) < 1e-6f) return null
            return floatArrayOf((a[2] * b[1] - b[2] * a[1]) / det, (a[0] * b[2] - b[0] * a[2]) / det)
        }
        fun cover(p: FloatArray, q: FloatArray, map: BooleanArray): Float {
            val len = hypot(q[0] - p[0], q[1] - p[1]).toInt()
            if (len < 5) return 0f
            var hit = 0
            for (k in 0 until len) {
                val x = (p[0] + (q[0] - p[0]) * k / len).toInt()
                val y = (p[1] + (q[1] - p[1]) * k / len).toInt()
                if (x in 0 until w && y in 0 until h && map[y * w + x]) hit++
            }
            return hit.toFloat() / len
        }
        fun scoreQuad(pts: Array<FloatArray>, frames: BooleanArray): Float {
            for (pt in pts) if (pt[0] < -0.02f * w || pt[0] > 1.02f * w || pt[1] < -0.02f * h || pt[1] > 1.02f * h) return -1f
            var a2 = 0f
            for (k in 0 until 4) { val j = (k + 1) % 4; a2 += pts[k][0] * pts[j][1] - pts[j][0] * pts[k][1] }
            val area = kotlin.math.abs(a2) / 2f / (w * h)
            if (area < 0.25f) return -1f
            var sum = 0f; var minC = 1f; var nf = 0
            for (k in 0 until 4) {
                val c = if (frames[k]) { nf++; 0.5f } else cover(pts[k], pts[(k + 1) % 4], if (k % 2 == 0) hD else vD)
                sum += c; minC = min(minC, c)
                if (minC < 0.35f) return -1f
            }
            if (nf > 2) return -1f
            // frame borders only count when the quad is big (two heading bars must not crop the page)
            if ((nf == 2 && area < 0.7f) || (nf == 1 && area < 0.45f)) return -1f
            return area + 0.15f * sum / 4f - 0.08f * nf
        }

        var bestScore = -1f
        var best: Array<FloatArray>? = null
        val frames = BooleanArray(4)
        for (i in 0 until vLines.size) for (j in i + 1 until vLines.size) {
            for (k in 0 until hLines.size) for (m in k + 1 until hLines.size) {
                var l = vLines[i]; var r = vLines[j]; var t = hLines[k]; var b = hLines[m]
                var tl = inter(l, t) ?: continue; var tr = inter(r, t) ?: continue
                if (tl[0] > tr[0]) { val z = l; l = r; r = z; tl = inter(l, t) ?: continue; tr = inter(r, t) ?: continue }
                var bl = inter(l, b) ?: continue
                if (tl[1] > bl[1]) { val z = t; t = b; b = z; tl = inter(l, t) ?: continue; tr = inter(r, t) ?: continue; bl = inter(l, b) ?: continue }
                val br = inter(r, b) ?: continue
                val pts = arrayOf(tl, tr, br, bl)
                // side order: top, right, bottom, left
                frames[0] = t[3] == 1f; frames[1] = r[3] == 1f; frames[2] = b[3] == 1f; frames[3] = l[3] == 1f
                val sc2 = scoreQuad(pts, frames)
                if (sc2 > bestScore) { bestScore = sc2; best = pts }
            }
        }
        // The colour-region result competes on the same score (slight bonus: it saw the paper itself)
        if (regionQuad != null) {
            val rq = arrayOf(
                floatArrayOf(regionQuad.tlX * w, regionQuad.tlY * h), floatArrayOf(regionQuad.trX * w, regionQuad.trY * h),
                floatArrayOf(regionQuad.brX * w, regionQuad.brY * h), floatArrayOf(regionQuad.blX * w, regionQuad.blY * h)
            )
            val rs = scoreQuad(rq, BooleanArray(4))
            if (rs >= 0f && rs + 0.05f >= bestScore) return regionQuad
        }
        val q = best ?: return regionQuad ?: straightenByLineAngles(vPeaks, hPeaks, w, h)
        val cp = CornerPoints(
            (q[0][0] / w).coerceIn(0f, 1f), (q[0][1] / h).coerceIn(0f, 1f),
            (q[1][0] / w).coerceIn(0f, 1f), (q[1][1] / h).coerceIn(0f, 1f),
            (q[2][0] / w).coerceIn(0f, 1f), (q[2][1] / h).coerceIn(0f, 1f),
            (q[3][0] / w).coerceIn(0f, 1f), (q[3][1] / h).coerceIn(0f, 1f)
        )
        return if (isSensibleQuad(cp, w, h)) cp else null
    }

    /**
     * No page outline found (the paper fills the photo): still make it straight, like CamScanner.
     * The tilt of the top-most and bottom-most straight lines (headings, borders, rules) and of the
     * left-most and right-most vertical lines gives the perspective; a quad with those side angles is
     * fitted just inside the photo, so the page is de-skewed / de-keystoned with almost no crop.
     */
    private fun straightenByLineAngles(vPeaks: List<FloatArray>, hPeaks: List<FloatArray>, w: Int, h: Int): CornerPoints? {
        if (hPeaks.isEmpty() && vPeaks.isEmpty()) return null
        fun yAt(l: FloatArray) = (l[2] - l[0] * w / 2f) / l[1]
        fun xAt(l: FloatArray) = (l[2] - l[1] * h / 2f) / l[0]
        val hl = hPeaks.filter { kotlin.math.abs(it[0]) < 0.21f }                 // within ~12 degrees of level
        val vl = vPeaks.map { if (it[0] < 0) floatArrayOf(-it[0], -it[1], -it[2]) else it }
            .filter { kotlin.math.abs(it[1]) < 0.21f }
        val axisH = floatArrayOf(0f, 1f, 0f); val axisV = floatArrayOf(1f, 0f, 0f)
        var top = hl.minByOrNull { yAt(it) } ?: axisH
        var bot = hl.maxByOrNull { yAt(it) } ?: axisH
        var lef = vl.minByOrNull { xAt(it) } ?: axisV
        var rig = vl.maxByOrNull { xAt(it) } ?: axisV
        // two sides that disagree a lot are not trusted: use the steadier (more level) one for both
        fun ang(l: FloatArray) = Math.toDegrees(atan2(l[0].toDouble(), l[1].toDouble())).toFloat()
        if (kotlin.math.abs(ang(top) - ang(bot)) > 8f) { if (kotlin.math.abs(ang(top)) < kotlin.math.abs(ang(bot))) bot = top else top = bot }
        fun angV(l: FloatArray) = Math.toDegrees(atan2(l[1].toDouble(), l[0].toDouble())).toFloat()
        if (kotlin.math.abs(angV(lef) - angV(rig)) > 8f) { if (kotlin.math.abs(angV(lef)) < kotlin.math.abs(angV(rig))) rig = lef else lef = rig }
        // nothing to correct?
        val maxTilt = maxOf(kotlin.math.abs(ang(top)), kotlin.math.abs(ang(bot)), kotlin.math.abs(angV(lef)), kotlin.math.abs(angV(rig)))
        if (maxTilt < 0.6f) return null
        // place each side just inside the photo
        val wf = w.toFloat(); val hf = h.toFloat()
        val t = floatArrayOf(top[0], top[1], maxOf(0f, top[0] * wf))
        val b = floatArrayOf(bot[0], bot[1], minOf(bot[1] * hf, bot[0] * wf + bot[1] * hf))
        val l = floatArrayOf(lef[0], lef[1], maxOf(0f, lef[1] * hf))
        val r = floatArrayOf(rig[0], rig[1], minOf(rig[0] * wf, rig[0] * wf + rig[1] * hf))
        fun inter(a: FloatArray, c: FloatArray): FloatArray? {
            val det = a[0] * c[1] - c[0] * a[1]
            if (kotlin.math.abs(det) < 1e-6f) return null
            return floatArrayOf((a[2] * c[1] - c[2] * a[1]) / det, (a[0] * c[2] - c[0] * a[2]) / det)
        }
        val tl = inter(l, t) ?: return null; val tr = inter(r, t) ?: return null
        val br = inter(r, b) ?: return null; val bl = inter(l, b) ?: return null
        val cp = CornerPoints(
            (tl[0] / wf).coerceIn(0f, 1f), (tl[1] / hf).coerceIn(0f, 1f),
            (tr[0] / wf).coerceIn(0f, 1f), (tr[1] / hf).coerceIn(0f, 1f),
            (br[0] / wf).coerceIn(0f, 1f), (br[1] / hf).coerceIn(0f, 1f),
            (bl[0] / wf).coerceIn(0f, 1f), (bl[1] / hf).coerceIn(0f, 1f)
        )
        return if (isSensibleQuad(cp, w, h)) cp else null
    }

    private fun dilate2(m: BooleanArray, w: Int, h: Int): BooleanArray {
        val tmp = BooleanArray(m.size)
        for (y in 0 until h) for (x in 0 until w) {
            var v = false
            for (dx in -2..2) { val xx = x + dx; if (xx in 0 until w && m[y * w + xx]) { v = true; break } }
            tmp[y * w + x] = v
        }
        val out = BooleanArray(m.size)
        for (y in 0 until h) for (x in 0 until w) {
            var v = false
            for (dy in -2..2) { val yy = y + dy; if (yy in 0 until h && tmp[yy * w + x]) { v = true; break } }
            out[y * w + x] = v
        }
        return out
    }

    /**
     * Finds the paper (a large bright region against a darker background) and returns its four
     * corners as normalised coordinates. Steps: downscale -> blur -> Otsu threshold -> erode ->
     * biggest connected region -> extreme points give TL/TR/BR/BL.
     * Returns (corners, true) when a believable document was found, else an inset full-frame and false.
     */
    fun detectCornersSync(bitmap: Bitmap, maxDim: Int = 320): Pair<CornerPoints, Boolean> {
        val fallback = Pair(CornerPoints(0.04f, 0.04f, 0.96f, 0.04f, 0.96f, 0.96f, 0.04f, 0.96f), false)
        try {
            val w = bitmap.width
            val h = bitmap.height
            if (w < 16 || h < 16) return fallback

            val scale = min(1f, maxDim.toFloat() / max(w, h))
            val sw = (w * scale).toInt().coerceAtLeast(24)
            val sh = (h * scale).toInt().coerceAtLeast(24)
            val small = Bitmap.createScaledBitmap(bitmap, sw, sh, true)
            val px = IntArray(sw * sh)
            small.getPixels(px, 0, sw, 0, 0, sw, sh)
            if (small != bitmap) small.recycle()

            var luma = IntArray(sw * sh)
            for (i in px.indices) {
                val c = px[i]
                luma[i] = (((c shr 16) and 0xFF) * 77 + ((c shr 8) and 0xFF) * 150 + (c and 0xFF) * 29) shr 8
            }

            // Blur twice (3x3 box) so printed text melts into the paper tone
            repeat(2) { luma = boxBlur3(luma, sw, sh) }

            // Otsu threshold
            val hist = IntArray(256)
            for (v in luma) hist[v.coerceIn(0, 255)]++
            val total = luma.size
            var sumAll = 0L
            for (i in 0..255) sumAll += i.toLong() * hist[i]
            var sumB = 0L
            var wB = 0
            var bestVar = -1.0
            var otsu = 128
            for (t in 0..255) {
                wB += hist[t]
                if (wB == 0) continue
                val wF = total - wB
                if (wF == 0) break
                sumB += t.toLong() * hist[t]
                val mB = sumB.toDouble() / wB
                val mF = (sumAll - sumB).toDouble() / wF
                val between = wB.toDouble() * wF * (mB - mF) * (mB - mF)
                if (between > bestVar) {
                    bestVar = between
                    otsu = t
                }
            }
            // Slightly favour including shaded paper: move the threshold towards the dark class mean
            var darkSum = 0L
            var darkCnt = 0
            for (i in 0..otsu) { darkSum += i.toLong() * hist[i]; darkCnt += hist[i] }
            val darkMean = if (darkCnt > 0) (darkSum / darkCnt).toInt() else otsu / 2
            val threshold = darkMean + ((otsu - darkMean) * 0.8f).toInt()

            // Try bright-paper-on-dark first, then dark-paper-on-bright as a second chance
            for (invert in booleanArrayOf(false, true)) {
                var mask = BooleanArray(sw * sh) { if (invert) luma[it] < threshold else luma[it] >= threshold }
                mask = erode3(mask, sw, sh)

                val region = largestRegion(mask, sw, sh) ?: continue
                val areaFrac = region.count.toFloat() / (sw * sh)
                if (areaFrac < 0.10f || areaFrac > 0.985f) continue

                // Extreme points (average the few best pixels so a stray pixel cannot win)
                val corners = extremeCorners(region.pixels, sw, sh) ?: continue
                val cp = CornerPoints(
                    corners[0], corners[1], corners[2], corners[3],
                    corners[4], corners[5], corners[6], corners[7]
                )
                if (isSensibleQuad(cp, sw, sh)) {
                    val refined = refineQuadByLines(region.pixels, sw, sh, cp)
                    return Pair(if (isSensibleQuad(refined, sw, sh)) refined else cp, true)
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
        return fallback
    }

    private class Region(val pixels: IntArray, val count: Int)

    /**
     * Makes the detected corners precise: the paper's outline pixels are split into its four
     * sides, a straight line is fitted through each side (ignoring fingers / torn bits), and the
     * corners become the intersections of those lines. Extreme-point corners alone are often a
     * few pixels off (rounded or hidden corners), which made the flattened page look slightly
     * tilted.
     */
    private fun refineQuadByLines(pixels: IntArray, w: Int, h: Int, init: CornerPoints): CornerPoints {
        try {
            val inRegion = BooleanArray(w * h)
            for (p in pixels) inRegion[p] = true

            val qx = floatArrayOf(init.tlX * w, init.trX * w, init.brX * w, init.blX * w)
            val qy = floatArrayOf(init.tlY * h, init.trY * h, init.brY * h, init.blY * h)
            val maxDist = 0.07f * min(w, h)

            val sideX = Array(4) { ArrayList<Float>() }
            val sideY = Array(4) { ArrayList<Float>() }

            for (p in pixels) {
                val x = p % w
                val y = p / w
                // Outline pixel = has a 4-neighbour outside the region (frame border counts as outside)
                val edge = x == 0 || y == 0 || x == w - 1 || y == h - 1 ||
                        !inRegion[p - 1] || !inRegion[p + 1] || !inRegion[p - w] || !inRegion[p + w]
                if (!edge) continue
                val fx = x + 0.5f
                val fy = y + 0.5f
                var best = -1
                var bestD = maxDist
                for (s in 0 until 4) {
                    val ax = qx[s]; val ay = qy[s]
                    val bx = qx[(s + 1) % 4]; val by = qy[(s + 1) % 4]
                    val vx = bx - ax; val vy = by - ay
                    val len2 = vx * vx + vy * vy
                    if (len2 < 1f) continue
                    val t = ((fx - ax) * vx + (fy - ay) * vy) / len2
                    if (t < 0.12f || t > 0.88f) continue // stay away from the corners
                    val d = kotlin.math.abs((fx - ax) * vy - (fy - ay) * vx) / kotlin.math.sqrt(len2)
                    if (d < bestD) { bestD = d; best = s }
                }
                if (best >= 0) { sideX[best].add(fx); sideY[best].add(fy) }
            }

            // Fit each side: total least squares, then refit without outliers
            val lines = arrayOfNulls<FloatArray>(4) // (a, b, c) with a*x + b*y = c, (a,b) unit
            for (s in 0 until 4) {
                val xs = sideX[s]; val ys = sideY[s]
                if (xs.size < 8) return init
                var line = fitLine(xs, ys, null, 0f) ?: return init
                var sum = 0f
                for (i in xs.indices) { val r = line[0] * xs[i] + line[1] * ys[i] - line[2]; sum += r * r }
                val rms = kotlin.math.sqrt(sum / xs.size)
                line = fitLine(xs, ys, line, max(1.0f, 2f * rms)) ?: line
                lines[s] = line
            }

            // Corner k is the intersection of side (k-1) and side k
            val out = FloatArray(8)
            val maxShift = 0.08f * hypot(w.toFloat(), h.toFloat())
            for (k in 0 until 4) {
                val l1 = lines[(k + 3) % 4]!!
                val l2 = lines[k]!!
                val det = l1[0] * l2[1] - l2[0] * l1[1]
                if (kotlin.math.abs(det) < 1e-4f) return init
                val cx = (l1[2] * l2[1] - l2[2] * l1[1]) / det
                val cy = (l1[0] * l2[2] - l2[0] * l1[2]) / det
                if (hypot(cx - qx[k], cy - qy[k]) > maxShift) return init
                out[k * 2] = (cx / w).coerceIn(0f, 1f)
                out[k * 2 + 1] = (cy / h).coerceIn(0f, 1f)
            }
            return CornerPoints(out[0], out[1], out[2], out[3], out[4], out[5], out[6], out[7])
        } catch (e: Throwable) {
            e.printStackTrace()
            return init
        }
    }

    /** Total-least-squares line through the points; with [prev] only points within [tol] of it are used. */
    private fun fitLine(xs: List<Float>, ys: List<Float>, prev: FloatArray?, tol: Float): FloatArray? {
        var n = 0
        var mx = 0.0; var my = 0.0
        for (i in xs.indices) {
            if (prev != null && kotlin.math.abs(prev[0] * xs[i] + prev[1] * ys[i] - prev[2]) > tol) continue
            mx += xs[i]; my += ys[i]; n++
        }
        if (n < 6) return null
        mx /= n; my /= n
        var sxx = 0.0; var syy = 0.0; var sxy = 0.0
        for (i in xs.indices) {
            if (prev != null && kotlin.math.abs(prev[0] * xs[i] + prev[1] * ys[i] - prev[2]) > tol) continue
            val dx = xs[i] - mx; val dy = ys[i] - my
            sxx += dx * dx; syy += dy * dy; sxy += dx * dy
        }
        // Direction of the line = principal axis; normal is perpendicular to it
        val theta = 0.5 * kotlin.math.atan2(2 * sxy, sxx - syy)
        val dirX = kotlin.math.cos(theta)
        val dirY = kotlin.math.sin(theta)
        val a = (-dirY).toFloat()
        val b = dirX.toFloat()
        val c = (a * mx + b * my).toFloat()
        return floatArrayOf(a, b, c)
    }

    private fun boxBlur3(src: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(src.size)
        for (y in 0 until h) {
            val y0 = max(0, y - 1)
            val y1 = min(h - 1, y + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - 1)
                val x1 = min(w - 1, x + 1)
                var s = 0
                var n = 0
                for (yy in y0..y1) {
                    val row = yy * w
                    for (xx in x0..x1) { s += src[row + xx]; n++ }
                }
                out[y * w + x] = s / n
            }
        }
        return out
    }

    private fun erode3(mask: BooleanArray, w: Int, h: Int): BooleanArray {
        val out = BooleanArray(mask.size)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                var all = true
                loop@ for (yy in y - 1..y + 1) {
                    for (xx in x - 1..x + 1) {
                        if (!mask[yy * w + xx]) { all = false; break@loop }
                    }
                }
                out[y * w + x] = all
            }
        }
        // Keep pixels on the image border if their inner neighbour is set (paper touching the frame)
        for (x in 0 until w) {
            out[x] = mask[x] && mask[w + x]
            out[(h - 1) * w + x] = mask[(h - 1) * w + x] && mask[(h - 2) * w + x]
        }
        for (y in 0 until h) {
            out[y * w] = mask[y * w] && mask[y * w + 1]
            out[y * w + w - 1] = mask[y * w + w - 1] && mask[y * w + w - 2]
        }
        return out
    }

    private fun largestRegion(mask: BooleanArray, w: Int, h: Int): Region? {
        val visited = BooleanArray(mask.size)
        val queue = IntArray(mask.size)
        var bestPixels: IntArray? = null
        var bestCount = 0
        for (start in mask.indices) {
            if (!mask[start] || visited[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = true
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                if (x > 0) { val q = p - 1; if (mask[q] && !visited[q]) { visited[q] = true; queue[tail++] = q } }
                if (x < w - 1) { val q = p + 1; if (mask[q] && !visited[q]) { visited[q] = true; queue[tail++] = q } }
                if (y > 0) { val q = p - w; if (mask[q] && !visited[q]) { visited[q] = true; queue[tail++] = q } }
                if (y < h - 1) { val q = p + w; if (mask[q] && !visited[q]) { visited[q] = true; queue[tail++] = q } }
            }
            if (tail > bestCount) {
                bestCount = tail
                bestPixels = queue.copyOf(tail)
            }
        }
        return bestPixels?.let { Region(it, bestCount) }
    }

    /** Returns [tlX,tlY,trX,trY,brX,brY,blX,blY] normalised, or null. */
    private fun extremeCorners(pixels: IntArray, w: Int, h: Int): FloatArray? {
        if (pixels.isEmpty()) return null
        var minSum = Int.MAX_VALUE
        var maxSum = Int.MIN_VALUE
        var minDiff = Int.MAX_VALUE
        var maxDiff = Int.MIN_VALUE
        for (p in pixels) {
            val x = p % w
            val y = p / w
            val s = x + y
            val d = x - y
            if (s < minSum) minSum = s
            if (s > maxSum) maxSum = s
            if (d < minDiff) minDiff = d
            if (d > maxDiff) maxDiff = d
        }
        val tol = 1
        var tlx = 0f; var tly = 0f; var tln = 0
        var trx = 0f; var try_ = 0f; var trn = 0
        var brx = 0f; var bry = 0f; var brn = 0
        var blx = 0f; var bly = 0f; var bln = 0
        for (p in pixels) {
            val x = p % w
            val y = p / w
            val s = x + y
            val d = x - y
            if (s <= minSum + tol) { tlx += x; tly += y; tln++ }
            if (d >= maxDiff - tol) { trx += x; try_ += y; trn++ }
            if (s >= maxSum - tol) { brx += x; bry += y; brn++ }
            if (d <= minDiff + tol) { blx += x; bly += y; bln++ }
        }
        if (tln == 0 || trn == 0 || brn == 0 || bln == 0) return null
        fun nx(v: Float, n: Int) = ((v / n + 0.5f) / w).coerceIn(0f, 1f)
        fun ny(v: Float, n: Int) = ((v / n + 0.5f) / h).coerceIn(0f, 1f)
        return floatArrayOf(
            nx(tlx, tln), ny(tly, tln),
            nx(trx, trn), ny(try_, trn),
            nx(brx, brn), ny(bry, brn),
            nx(blx, bln), ny(bly, bln)
        )
    }

    private fun isSensibleQuad(c: CornerPoints, sw: Int, sh: Int): Boolean {
        val xs = floatArrayOf(c.tlX * sw, c.trX * sw, c.brX * sw, c.blX * sw)
        val ys = floatArrayOf(c.tlY * sh, c.trY * sh, c.brY * sh, c.blY * sh)
        var area2 = 0f
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            area2 += xs[i] * ys[j] - xs[j] * ys[i]
        }
        val area = kotlin.math.abs(area2) / 2f
        if (area < 0.10f * sw * sh) return false
        val minSide = 0.12f * min(sw, sh)
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            if (hypot(xs[i] - xs[j], ys[i] - ys[j]) < minSide) return false
        }
        // Convexity check: all cross products have the same sign
        var sign = 0
        for (i in 0 until 4) {
            val a = i
            val b = (i + 1) % 4
            val c2 = (i + 2) % 4
            val cross = (xs[b] - xs[a]) * (ys[c2] - ys[b]) - (ys[b] - ys[a]) * (xs[c2] - xs[b])
            val s = if (cross > 0) 1 else if (cross < 0) -1 else 0
            if (s != 0) {
                if (sign == 0) sign = s else if (sign != s) return false
            }
        }
        return true
    }

    // ------------------------------------------------------------------------------------------
    // Perspective correction
    // ------------------------------------------------------------------------------------------

    /**
     * Solves the 3x3 homography H that maps the 4 points (x[i], y[i]) to (u[i], v[i]).
     * Returns h0..h7 (h8 = 1) or null when the points are degenerate.
     */
    private fun solveHomography(x: DoubleArray, y: DoubleArray, u: DoubleArray, v: DoubleArray): DoubleArray? {
        val a = Array(8) { DoubleArray(9) }
        for (i in 0 until 4) {
            val r1 = a[i * 2]
            r1[0] = x[i]; r1[1] = y[i]; r1[2] = 1.0
            r1[3] = 0.0; r1[4] = 0.0; r1[5] = 0.0
            r1[6] = -x[i] * u[i]; r1[7] = -y[i] * u[i]; r1[8] = u[i]
            val r2 = a[i * 2 + 1]
            r2[0] = 0.0; r2[1] = 0.0; r2[2] = 0.0
            r2[3] = x[i]; r2[4] = y[i]; r2[5] = 1.0
            r2[6] = -x[i] * v[i]; r2[7] = -y[i] * v[i]; r2[8] = v[i]
        }
        // Gaussian elimination with partial pivoting
        for (col in 0 until 8) {
            var pivot = col
            for (r in col + 1 until 8) if (kotlin.math.abs(a[r][col]) > kotlin.math.abs(a[pivot][col])) pivot = r
            if (kotlin.math.abs(a[pivot][col]) < 1e-12) return null
            if (pivot != col) { val t = a[pivot]; a[pivot] = a[col]; a[col] = t }
            val p = a[col][col]
            for (c in col until 9) a[col][c] /= p
            for (r in 0 until 8) {
                if (r == col) continue
                val f = a[r][col]
                if (f == 0.0) continue
                for (c in col until 9) a[r][c] -= f * a[col][c]
            }
        }
        return DoubleArray(8) { a[it][8] }
    }


    // ------------------------------------------------------------------------------------------
    // Filters
    // ------------------------------------------------------------------------------------------

    /**
     * Applies geometry (flip, rotate, straighten), then the chosen scanner filter, then the
     * brightness / contrast sliders.
     *
     * The scanner filters first estimate the paper's own colour at every point (a text-free,
     * smoothed copy of the page, per colour channel) and divide it out. That removes shadows,
     * uneven light AND coloured tints (bluish / yellowish light), so paper becomes truly white
     * while the ink keeps its colour. "Original" is left completely untouched.
     */
    suspend fun applyFiltersAndEdits(
        bitmap: Bitmap,
        filter: FilterType,
        params: EditParameters,
        rotationDeg: Int = 0
    ): Bitmap = withContext(Dispatchers.Default) {
        // Step 1: geometry
        val matrix = Matrix()
        if (params.flipH || params.flipV) {
            matrix.postScale(
                if (params.flipH) -1f else 1f,
                if (params.flipV) -1f else 1f,
                bitmap.width / 2f,
                bitmap.height / 2f
            )
        }
        val totalRotation = (rotationDeg.toFloat() + params.straightenAngle)
        if (totalRotation != 0f) {
            matrix.postRotate(totalRotation, bitmap.width / 2f, bitmap.height / 2f)
        }

        var geometry: Bitmap = if (!matrix.isIdentity) {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else {
            bitmap
        }
        var ownsGeometry = geometry !== bitmap

        if (params.straightenAngle != 0f && geometry.hasAlpha()) {
            val flat = Bitmap.createBitmap(geometry.width, geometry.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(flat)
            c.drawColor(Color.WHITE)
            c.drawBitmap(geometry, 0f, 0f, null)
            if (ownsGeometry) geometry.recycle()
            geometry = flat
            ownsGeometry = true
        }

        // Step 2: the scanner filter itself
        val filtered: Bitmap = if (filter == FilterType.ORIGINAL) geometry else scannerFilter(geometry, filter)
        val ownsFiltered = filtered !== geometry

        // Step 3: user sliders
        val colorMatrix = ColorMatrix()
        if (params.brightness != 0f) adjustBrightness(colorMatrix, params.brightness * 80f)
        if (params.contrast != 1f) adjustContrast(colorMatrix, params.contrast)

        val result = Bitmap.createBitmap(filtered.width, filtered.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }
        canvas.drawBitmap(filtered, 0f, 0f, paint)

        if (ownsFiltered && !filtered.isRecycled) filtered.recycle()
        if (ownsGeometry && !geometry.isRecycled) geometry.recycle()
        result
    }

    /** Maps v linearly so lo -> 0 and hi -> 255. */
    private fun levelsLut(lo: Int, hi: Int, gamma: Float = 1f): IntArray {
        val lut = IntArray(256)
        val range = (hi - lo).coerceAtLeast(1).toFloat()
        for (i in 0..255) {
            var t = ((i - lo) / range).coerceIn(0f, 1f)
            if (gamma != 1f) t = Math.pow(t.toDouble(), gamma.toDouble()).toFloat()
            lut[i] = (t * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        return lut
    }

    private fun scannerFilter(src: Bitmap, filter: FilterType): Bitmap {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)

        // Paper colour estimate per channel (packed RGB per pixel)
        val bg = if (filter == FilterType.REMOVE_SHADOW)
            estimatePaper(src, grid = 160, dilate = 3, blur = 3, floorFrac = 0.5f)
        else estimatePaper(src)

        // Remove camera noise BEFORE the lighting correction multiplies it (dark / shadow areas get
        // a big gain, which is what made filtered pages look grainy and soft).
        if (n >= 250_000) denoiseDark(px, w, h, bg)

        val out = IntArray(n)
        when (filter) {
            FilterType.MAGIC_COLOR -> {
                val lut = levelsLut(40, 235)
                for (i in 0 until n) {
                    val c = px[i]; val b = bg[i]
                    var r = lut[norm((c shr 16) and 0xFF, (b shr 16) and 0xFF)]
                    var g = lut[norm((c shr 8) and 0xFF, (b shr 8) and 0xFF)]
                    var bl = lut[norm(c and 0xFF, b and 0xFF)]
                    // gentle saturation boost so coloured ink / stamps stay vivid
                    val m = (r + g + bl) / 3
                    r = (m + (r - m) * 1.15f).toInt().coerceIn(0, 255)
                    g = (m + (g - m) * 1.15f).toInt().coerceIn(0, 255)
                    bl = (m + (bl - m) * 1.15f).toInt().coerceIn(0, 255)
                    out[i] = pack(r, g, bl)
                }
            }
            FilterType.AUTO_ENHANCE -> {
                val lut = levelsLut(15, 245)
                for (i in 0 until n) {
                    val c = px[i]; val b = bg[i]
                    val r0 = (c shr 16) and 0xFF; val g0 = (c shr 8) and 0xFF; val b0 = c and 0xFF
                    val r = r0 + ((norm(r0, (b shr 16) and 0xFF) - r0) * 0.6f).toInt()
                    val g = g0 + ((norm(g0, (b shr 8) and 0xFF) - g0) * 0.6f).toInt()
                    val bl = b0 + ((norm(b0, b and 0xFF) - b0) * 0.6f).toInt()
                    out[i] = pack(lut[r.coerceIn(0, 255)], lut[g.coerceIn(0, 255)], lut[bl.coerceIn(0, 255)])
                }
            }
            FilterType.REMOVE_SHADOW -> {
                // Shadow-free: a fine paper-brightness map (shadow edges included) is divided out, so the
                // page becomes evenly lit and paper turns white while text / pictures keep their colours.
                // Each colour channel is divided by its own paper value, so a bluish / yellowish tint of
                // the shadow (daylight, tube light) is removed too. Then near-grey pixels are made fully
                // neutral, so no coloured haze is left where the shadow was. Real coloured ink stays.
                val lut = levelsLut(25, 238)
                for (i in 0 until n) {
                    val c = px[i]; val b = bg[i]
                    var r = lut[norm((c shr 16) and 0xFF, (b shr 16) and 0xFF)]
                    var g = lut[norm((c shr 8) and 0xFF, (b shr 8) and 0xFF)]
                    var bb = lut[norm(c and 0xFF, b and 0xFF)]
                    val m = (r + g + bb) / 3
                    val dev = max(kotlin.math.abs(r - m), max(kotlin.math.abs(g - m), kotlin.math.abs(bb - m)))
                    // dev < 18: grey -> neutral; 18..45: partly; above: coloured ink kept as is
                    val keep = ((dev - 18f) / 27f).coerceIn(0f, 1f)
                    if (keep < 1f) {
                        r = (m + (r - m) * keep).toInt()
                        g = (m + (g - m) * keep).toInt()
                        bb = (m + (bb - m) * keep).toInt()
                    }
                    out[i] = pack(r, g, bb)
                }
            }
            FilterType.LIGHTEN -> {
                val lut = levelsLut(20, 225, 0.8f)
                for (i in 0 until n) {
                    val c = px[i]; val b = bg[i]
                    out[i] = pack(
                        lut[norm((c shr 16) and 0xFF, (b shr 16) and 0xFF)],
                        lut[norm((c shr 8) and 0xFF, (b shr 8) and 0xFF)],
                        lut[norm(c and 0xFF, b and 0xFF)]
                    )
                }
            }
            FilterType.GRAYSCALE, FilterType.DOCUMENT_BW, FilterType.BW2 -> {
                // Lighting-corrected luminance first
                val lum = IntArray(n)
                for (i in 0 until n) {
                    val c = px[i]; val b = bg[i]
                    lum[i] = luma(
                        norm((c shr 16) and 0xFF, (b shr 16) and 0xFF),
                        norm((c shr 8) and 0xFF, (b shr 8) and 0xFF),
                        norm(c and 0xFF, b and 0xFF)
                    )
                }
                when (filter) {
                    FilterType.GRAYSCALE -> {
                        val lut = levelsLut(30, 240)
                        for (i in 0 until n) { val v = lut[lum[i]]; out[i] = pack(v, v, v) }
                    }
                    FilterType.BW2 -> {
                        // Soft black & white: crisp but keeps thin / light strokes readable
                        val lut = levelsLut(120, 215)
                        for (i in 0 until n) { val v = lut[lum[i]]; out[i] = pack(v, v, v) }
                    }
                    else -> {
                        // Document B&W: adaptive (local) threshold with a soft edge, so faint
                        // text stays and nothing is wiped out by one global cut-off.
                        val radius = (max(w, h) / 50).coerceIn(4, 80)
                        val mean = boxMean(lum, w, h, radius)
                        val dark = levelsLut(60, 200)
                        for (i in 0 until n) {
                            val l = lum[i]
                            val t = mean[i] * 0.88f - 10f
                            var v = (((l - t) / 16f).coerceIn(0f, 1f) * 255f).toInt()
                            if (l <= 200) v = min(v, dark[l])
                            out[i] = pack(v, v, v)
                        }
                    }
                }
            }
            FilterType.ORIGINAL -> System.arraycopy(px, 0, out, 0, n)
        }

        // Deep, clear ink (like CamScanner / OKEN): after the paper is made white, the writing itself is
        // usually left too light and greyish. Stretch the darkest ink to near-black per channel (hue kept),
        // darken the mid tones and make coloured ink a little more vivid. Paper stays pure white.
        when (filter) {
            FilterType.MAGIC_COLOR -> inkBoost(out, gamma = 1.35f, spread = 45, satBoost = 0.6f)
            FilterType.REMOVE_SHADOW -> inkBoost(out, gamma = 1.25f, spread = 40, satBoost = 0.1f)
            FilterType.AUTO_ENHANCE -> inkBoost(out, gamma = 1.15f, spread = 30, satBoost = 0.3f)
            FilterType.GRAYSCALE -> inkBoost(out, gamma = 1.3f, spread = 40, satBoost = 0f)
            else -> {}
        }

        // CamScanner-style crisp text: sharpen every filter except the pure black & white ones
        if (filter != FilterType.ORIGINAL && filter != FilterType.DOCUMENT_BW && filter != FilterType.BW2) {
            sharpenLuma(out, w, h, amount = 0.9f, radius = (max(w, h) / 1200).coerceIn(1, 3))
        }

        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(out, 0, w, 0, 0, w, h)
        return result
    }

    /**
     * Edge-preserving noise removal (3x3 "sigma" filter) done in place with only 3 spare rows of memory.
     * A neighbour is averaged in only if it is similar to the centre pixel, so text edges stay sharp.
     * It only touches pixels the lighting correction will brighten (paper darker than ~80 %), and the
     * darker the spot, the stronger the smoothing. Well-lit areas are left exactly as photographed.
     */
    private fun denoiseDark(px: IntArray, w: Int, h: Int, bg: IntArray) {
        val rows = Array(3) { IntArray(w) }
        val lums = Array(3) { IntArray(w) }
        fun load(slot: Int, y: Int) {
            val yy = y.coerceIn(0, h - 1)
            System.arraycopy(px, yy * w, rows[slot], 0, w)
            val r = rows[slot]; val l = lums[slot]
            for (x in 0 until w) { val c = r[x]; l[x] = luma((c shr 16) and 0xFF, (c shr 8) and 0xFF, c and 0xFF) }
        }
        for (y in 0 until h) {
            load(0, y - 1); load(1, y); load(2, y + 1)
            for (x in 0 until w) {
                val b = bg[y * w + x]
                val bl = luma((b shr 16) and 0xFF, (b shr 8) and 0xFF, b and 0xFF).coerceAtLeast(40)
                if (bl >= 204) continue
                val thr = (6f + 14f * (255f / bl - 1f)).toInt().coerceIn(6, 40)
                val centre = lums[1][x]
                var sr = 0; var sg = 0; var sb = 0; var cnt = 0
                for (dy in 0..2) {
                    val r = rows[dy]; val l = lums[dy]
                    for (dx in -1..1) {
                        val xx = (x + dx).coerceIn(0, w - 1)
                        if (kotlin.math.abs(l[xx] - centre) <= thr) {
                            val c = r[xx]
                            sr += (c shr 16) and 0xFF; sg += (c shr 8) and 0xFF; sb += c and 0xFF; cnt++
                        }
                    }
                }
                px[y * w + x] = pack(sr / cnt, sg / cnt, sb / cnt)
            }
        }
    }

    /** Unsharp mask on brightness only (no colour fringes); the change is limited so no halos appear. */
    private fun sharpenLuma(px: IntArray, w: Int, h: Int, amount: Float, radius: Int) {
        val n = w * h
        val lum = IntArray(n)
        for (i in 0 until n) {
            val c = px[i]
            lum[i] = luma((c shr 16) and 0xFF, (c shr 8) and 0xFF, c and 0xFF)
        }
        val blurred = boxMean(lum, w, h, radius)
        for (i in 0 until n) {
            val d = ((lum[i] - blurred[i]) * amount).toInt().coerceIn(-70, 70)
            if (d == 0) continue
            val c = px[i]
            val r = (((c shr 16) and 0xFF) + d).coerceIn(0, 255)
            val g = (((c shr 8) and 0xFF) + d).coerceIn(0, 255)
            val b = ((c and 0xFF) + d).coerceIn(0, 255)
            px[i] = pack(r, g, b)
        }
    }

    /**
     * Makes faint ink dark and clear. The black point is taken from the image itself (the darkest 0.5 %
     * of pixels), so pale ball-pen writing becomes deep blue / black, while pages that are already dark
     * are only given the mid-tone curve. Values >= 238 become pure white paper.
     */
    private fun inkBoost(px: IntArray, gamma: Float, spread: Int, satBoost: Float) {
        val n = px.size
        if (n == 0) return
        val hist = IntArray(256)
        for (i in 0 until n) {
            val c = px[i]
            hist[(((c shr 16) and 0xFF) + ((c shr 8) and 0xFF) + (c and 0xFF)) / 3]++
        }
        val target = (n * 0.005).toLong().coerceAtLeast(1)
        var acc = 0L
        var dark = 0
        for (v in 0..255) { acc += hist[v]; if (acc >= target) { dark = v; break } }
        val lo = (dark - spread).coerceIn(0, 150)
        val lut = levelsLut(lo, 238, gamma)
        for (i in 0 until n) {
            val c = px[i]
            var r = lut[(c shr 16) and 0xFF]
            var g = lut[(c shr 8) and 0xFF]
            var b = lut[c and 0xFF]
            if (satBoost > 0f) {
                val m = (r + g + b) / 3
                val k = 1f + satBoost * (255 - m) / 255f
                r = (m + (r - m) * k).toInt().coerceIn(0, 255)
                g = (m + (g - m) * k).toInt().coerceIn(0, 255)
                b = (m + (b - m) * k).toInt().coerceIn(0, 255)
            }
            px[i] = pack(r, g, b)
        }
    }

    /** One brush stroke on the page: positions are 0..1 of the picture, width is a fraction of its width. */
    data class BrushStroke(val points: List<Pair<Float, Float>>, val widthFraction: Float, val color: Int)

    /** Paints brush strokes (cover / highlight brush) at any resolution. */
    fun paintStrokes(src: Bitmap, strokes: List<BrushStroke>): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        for (st in strokes) {
            if (st.points.isEmpty()) continue
            val paint = Paint().apply {
                color = st.color
                isAntiAlias = true
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                strokeWidth = (st.widthFraction * out.width).coerceAtLeast(1f)
            }
            val path = android.graphics.Path()
            val (x0, y0) = st.points.first()
            path.moveTo(x0 * out.width, y0 * out.height)
            if (st.points.size == 1) path.lineTo(x0 * out.width + 0.1f, y0 * out.height)
            for (k in 1 until st.points.size) {
                val (x, y) = st.points[k]
                path.lineTo(x * out.width, y * out.height)
            }
            canvas.drawPath(path, paint)
        }
        return out
    }

    /** Draws a (transparent background) signature picture onto the page. Rect values are 0..1 of the page. */
    fun drawOverlay(src: Bitmap, overlay: Bitmap, left: Float, top: Float, widthFrac: Float): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val w = widthFrac * out.width
        val h = w * overlay.height / overlay.width
        val l = left * out.width
        val t = top * out.height
        canvas.drawBitmap(overlay, null, RectF(l, t, l + w, t + h), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun pack(r: Int, g: Int, b: Int): Int = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    private fun luma(r: Int, g: Int, b: Int): Int = (r * 77 + g * 150 + b * 29) shr 8
    /** Channel value divided by the paper's value for that channel (paper -> 255). */
    private fun norm(v: Int, paper: Int): Int = (v * 255 / paper.coerceAtLeast(40)).coerceAtMost(255)

    /**
     * Returns, for every pixel, the estimated colour of blank paper at that point (packed RGB).
     * Works on a ~64 px wide copy: a max filter removes text, a blur makes it smooth.
     */
    private fun estimatePaper(src: Bitmap, grid: Int = 64, dilate: Int = 3, blur: Int = 3, floorFrac: Float = 0f): IntArray {
        val w = src.width
        val h = src.height
        val factor = max(4, max(w, h) / grid)
        val sw = max(8, w / factor)
        val sh = max(8, h / factor)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val sp = IntArray(sw * sh)
        small.getPixels(sp, 0, sw, 0, 0, sw, sh)
        if (small != src) small.recycle()

        val chans = Array(3) { ch ->
            var a = IntArray(sw * sh) { (sp[it] shr (16 - ch * 8)) and 0xFF }
            repeat(dilate) { a = maxFilter3(a, sw, sh) }
            repeat(blur) { a = boxBlur3(a, sw, sh) }
            if (floorFrac > 0f) {
                // Reference paper level = 90th percentile. Anything darker than floorFrac * reference is
                // treated as real content (dark band, photo) and is NOT brightened like a shadow.
                val hist = IntArray(256)
                for (v in a) hist[v.coerceIn(0, 255)]++
                var acc = 0
                var ref = 255
                for (i in 0..255) { acc += hist[i]; if (acc >= a.size * 0.90f) { ref = i; break } }
                val floor = (ref * floorFrac).toInt()
                for (i in a.indices) if (a[i] < floor) a[i] = floor
            }
            a
        }
        val bp = IntArray(sw * sh) { pack(chans[0][it].coerceIn(0, 255), chans[1][it].coerceIn(0, 255), chans[2][it].coerceIn(0, 255)) }
        val bgSmall = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        bgSmall.setPixels(bp, 0, sw, 0, 0, sw, sh)
        val big = Bitmap.createScaledBitmap(bgSmall, w, h, true)
        if (big != bgSmall) bgSmall.recycle()
        val out = IntArray(w * h)
        big.getPixels(out, 0, w, 0, 0, w, h)
        big.recycle()
        return out
    }

    /** Box mean with the given radius (separable running sums, O(n)). */
    private fun boxMean(src: IntArray, w: Int, h: Int, radius: Int): IntArray {
        val tmp = IntArray(w * h)
        val out = IntArray(w * h)
        // horizontal
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (x in -radius..radius) sum += src[row + x.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = sum
                sum += src[row + (x + radius + 1).coerceAtMost(w - 1)] - src[row + (x - radius).coerceAtLeast(0)]
            }
        }
        // vertical
        val area = (2 * radius + 1) * (2 * radius + 1)
        for (x in 0 until w) {
            var sum = 0
            for (y in -radius..radius) sum += tmp[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = sum / area
                sum += tmp[(y + radius + 1).coerceAtMost(h - 1) * w + x] - tmp[(y - radius).coerceAtLeast(0) * w + x]
            }
        }
        return out
    }

    private fun maxFilter3(src: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(src.size)
        for (y in 0 until h) {
            val y0 = max(0, y - 1)
            val y1 = min(h - 1, y + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - 1)
                val x1 = min(w - 1, x + 1)
                var m = 0
                for (yy in y0..y1) {
                    val row = yy * w
                    for (xx in x0..x1) { if (src[row + xx] > m) m = src[row + xx] }
                }
                out[y * w + x] = m
            }
        }
        return out
    }
    private fun adjustBrightness(cm: ColorMatrix, value: Float) {
        val brightnessMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, value,
                0f, 1f, 0f, 0f, value,
                0f, 0f, 1f, 0f, value,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(brightnessMatrix)
    }

    private fun adjustContrast(cm: ColorMatrix, contrast: Float) {
        val scale = contrast
        val translate = (-0.5f * scale + 0.5f) * 255f
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(contrastMatrix)
    }

    /**
     * Renders a Passport Photo Sheet at the DPI chosen in [config] with neat grid and optional cut guidelines.
     */
    suspend fun renderPassportSheet(config: PassportConfig, photoBitmap: Bitmap): Bitmap = withContext(Dispatchers.Default) {
        val dpi = config.dpi.coerceIn(72, 1200).toFloat()
        val mmToPx = dpi / 25.4f

        val sheetW = (config.customSheetWidthMm * mmToPx).toInt().coerceAtLeast(300)
        val sheetH = (config.customSheetHeightMm * mmToPx).toInt().coerceAtLeast(300)

        val photoW = (config.customPhotoWidthMm * mmToPx).toInt().coerceAtLeast(100)
        val photoH = (config.customPhotoHeightMm * mmToPx).toInt().coerceAtLeast(100)

        val gapPx = (config.gapMm * mmToPx).toInt()
        val marginPx = (config.marginMm * mmToPx).toInt()

        val sheetBitmap = Bitmap.createBitmap(sheetW, sheetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheetBitmap)
        canvas.drawColor(Color.WHITE)

        val cols = ((sheetW - 2 * marginPx + gapPx) / (photoW + gapPx)).coerceAtLeast(1)
        val rows = ((sheetH - 2 * marginPx + gapPx) / (photoH + gapPx)).coerceAtLeast(1)

        val maxPossible = cols * rows
        val totalToDraw = if (config.isFitMaximum) maxPossible else config.copiesCount.coerceIn(1, maxPossible)

        val photoPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        val cutLinePaint = Paint().apply {
            color = 0xFFCCCCCC.toInt()
            strokeWidth = 2f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
        }

        // Centre-crop the photo to the passport aspect ratio so faces are never stretched
        val targetAspect = photoW.toFloat() / photoH
        val srcAspect = photoBitmap.width.toFloat() / photoBitmap.height
        val srcCrop = if (srcAspect > targetAspect) {
            val cw = (photoBitmap.height * targetAspect).toInt()
            val left = (photoBitmap.width - cw) / 2
            Rect(left, 0, left + cw, photoBitmap.height)
        } else {
            val ch = (photoBitmap.width / targetAspect).toInt()
            val top = (photoBitmap.height - ch) / 2
            Rect(0, top, photoBitmap.width, top + ch)
        }

        var count = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (count >= totalToDraw) break
                val x = marginPx + c * (photoW + gapPx)
                val y = marginPx + r * (photoH + gapPx)

                val dstRect = Rect(x, y, x + photoW, y + photoH)
                canvas.drawBitmap(photoBitmap, srcCrop, dstRect, photoPaint)

                if (config.showCutLines) {
                    canvas.drawRect(
                        (x - 1).toFloat(),
                        (y - 1).toFloat(),
                        (x + photoW + 1).toFloat(),
                        (y + photoH + 1).toFloat(),
                        cutLinePaint
                    )
                }
                count++
            }
        }

        sheetBitmap
    }

    /**
     * Renders a blank composed page with multiple images and text objects in exact millimeter measurements.
     */
    suspend fun renderComposedPage(
        config: ComposedPageConfig,
        objects: List<ComposedObject>,
        dpi: Int = 300
    ): Bitmap = withContext(Dispatchers.Default) {
        val mmToPx = dpi / 25.4f

        val effectiveW = if (config.orientation == PageOrientation.PORTRAIT) config.widthMm else config.heightMm
        val effectiveH = if (config.orientation == PageOrientation.PORTRAIT) config.heightMm else config.widthMm

        val pageW = (effectiveW * mmToPx).toInt().coerceAtLeast(200)
        val pageH = (effectiveH * mmToPx).toInt().coerceAtLeast(200)

        val outBitmap = Bitmap.createBitmap(pageW, pageH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)
        canvas.drawColor(config.backgroundColor)

        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        val textPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        // Render objects in layer order
        val sortedObjects = objects.sortedBy { it.layer }

        for (obj in sortedObjects) {
            val ox = obj.xMm * mmToPx
            val oy = obj.yMm * mmToPx
            val ow = obj.widthMm * mmToPx
            val oh = obj.heightMm * mmToPx

            canvas.save()
            if (obj.rotationDeg != 0f) {
                canvas.rotate(obj.rotationDeg, ox + ow / 2f, oy + oh / 2f)
            }

            if (obj.type == ObjectType.IMAGE && obj.imagePath != null) {
                val img = loadBitmapFromFile(obj.imagePath)
                if (img != null) {
                    val dst = RectF(ox, oy, ox + ow, oy + oh)
                    canvas.drawBitmap(img, null, dst, paint)
                    img.recycle()
                }
            } else if (obj.type == ObjectType.TEXT && obj.text != null) {
                canvas.save()
                canvas.translate(ox, oy)
                canvas.scale(mmToPx, mmToPx)
                TextBoxLayout.draw(canvas, obj)
                canvas.restore()
            }

            if (obj.borderWidthMm > 0f) {
                borderPaint.color = obj.borderColor
                borderPaint.strokeWidth = obj.borderWidthMm * mmToPx
                canvas.drawRect(ox, oy, ox + ow, oy + oh, borderPaint)
            }

            canvas.restore()
        }

        outBitmap
    }

    /**
     * Generates a multi-page PDF document on the device using standard Android PdfDocument.
     */
    suspend fun generatePdf(bitmaps: List<Bitmap>, outputFile: File): Boolean = withContext(Dispatchers.IO) {
        try {
            outputFile.parentFile?.mkdirs()
            val pdfDocument = PdfDocument()

            for ((index, bmp) in bitmaps.withIndex()) {
                val pageInfo = PdfDocument.PageInfo.Builder(bmp.width, bmp.height, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas
                val paint = Paint().apply {
                    isAntiAlias = true
                    isFilterBitmap = true
                }
                canvas.drawBitmap(bmp, 0f, 0f, paint)
                pdfDocument.finishPage(page)
            }

            FileOutputStream(outputFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()
            true
        } catch (e: Throwable) {
            e.printStackTrace()
            false
        }
    }
}
