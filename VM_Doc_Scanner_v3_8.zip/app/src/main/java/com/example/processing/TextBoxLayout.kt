package com.example.processing

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.data.model.ComposedObject

/**
 * Single source of truth for text boxes. The screen and the exported page both use this,
 * so size and look are identical everywhere. Everything is laid out in a fixed
 * "unit space" (UNITS_PER_MM units for 1 mm) and then scaled to any dpi / screen size.
 *
 * A text box is always exactly as big as its text: width = longest line, height = all lines.
 */
object TextBoxLayout {
    const val UNITS_PER_MM = 20f
    const val PAD_MM = 1.2f
    private const val MM_PER_FONT_UNIT = 25.4f / 160f

    /** Font choices shown in the composer: key to label. */
    val FONTS = listOf(
        "sans" to "Sans",
        "serif" to "Serif",
        "mono" to "Mono",
        "condensed" to "Condensed",
        "cursive" to "Cursive",
        "light" to "Light",
        "black" to "Black"
    )

    fun fontMm(fontSizeSp: Float) = fontSizeSp * MM_PER_FONT_UNIT

    private fun typeface(family: String, bold: Boolean, italic: Boolean): Typeface {
        val base = when (family) {
            "serif" -> Typeface.SERIF
            "mono" -> Typeface.MONOSPACE
            "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            "cursive" -> Typeface.create("cursive", Typeface.NORMAL)
            "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            "black" -> Typeface.create("sans-serif-black", Typeface.NORMAL)
            else -> Typeface.SANS_SERIF
        }
        val style = when {
            bold && italic -> Typeface.BOLD_ITALIC
            bold -> Typeface.BOLD
            italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        return Typeface.create(base, style)
    }

    private fun paintFor(o: ComposedObject, color: Int = o.fontColor) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = fontMm(o.fontSizeSp) * UNITS_PER_MM
        typeface = typeface(o.fontFamily, o.bold, o.italic)
        isUnderlineText = o.underline
    }

    private fun build(o: ComposedObject, widthMm: Float): StaticLayout {
        val text = o.text ?: ""
        val paint = paintFor(o)
        val innerW = ((widthMm - 2 * PAD_MM) * UNITS_PER_MM).toInt().coerceAtLeast(10)
        val align = when (o.textAlign) {
            1 -> Layout.Alignment.ALIGN_CENTER
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, innerW)
            .setAlignment(align)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.1f)
            .build()
    }

    /** Width (mm) of the longest line (lines break only where the user pressed Enter). */
    fun naturalWidthMm(o: ComposedObject): Float {
        val paint = paintFor(o)
        var maxW = 0f
        for (line in (o.text ?: "").split('\n')) {
            maxW = maxOf(maxW, paint.measureText(line.ifEmpty { " " }))
        }
        // +2 units so rounding can never push the last word onto a new line
        return (maxW + 2f) / UNITS_PER_MM + 2 * PAD_MM
    }

    fun heightMm(o: ComposedObject, widthMm: Float): Float =
        build(o, widthMm).height / UNITS_PER_MM + 2 * PAD_MM

    /** Returns the object with its box shrunk / grown to exactly fit the text (top-left stays put). */
    fun fit(o: ComposedObject): ComposedObject {
        if (o.text == null) return o
        val w = naturalWidthMm(o)
        return o.copy(widthMm = w, heightMm = heightMm(o, w))
    }

    /** Draws the text with its box origin at (0,0) in a canvas that is already scaled so 1 unit = 1 mm. */
    fun draw(canvas: Canvas, o: ComposedObject) {
        val l = build(o, o.widthMm)
        canvas.save()
        canvas.translate(PAD_MM, PAD_MM)
        canvas.scale(1f / UNITS_PER_MM, 1f / UNITS_PER_MM)
        l.draw(canvas)
        canvas.restore()
    }
}
