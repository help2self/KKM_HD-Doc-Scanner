package com.example.processing

import java.io.File
import java.io.RandomAccessFile
import java.util.zip.CRC32

/**
 * Writes the print resolution (DPI) into the image file itself, because Bitmap.compress() leaves it
 * out. Online forms that check "image must be 200 DPI" read exactly this value.
 *  - JPEG: JFIF header (units = dots per inch, X / Y density)
 *  - PNG : pHYs chunk (pixels per metre)
 */
object DpiMetadata {

    fun write(file: File, dpi: Int) {
        if (dpi <= 0 || !file.exists()) return
        try {
            val head = ByteArray(8)
            RandomAccessFile(file, "r").use { it.read(head) }
            val isJpeg = head[0] == 0xFF.toByte() && head[1] == 0xD8.toByte()
            val isPng = head[0] == 0x89.toByte() && head[1] == 'P'.code.toByte()
            if (isJpeg) writeJpeg(file, dpi) else if (isPng) writePng(file, dpi)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun writeJpeg(file: File, dpi: Int) {
        val bytes = file.readBytes()
        val d = dpi.coerceIn(1, 65535)
        // Android writes an APP0/JFIF segment right after SOI: FF D8 FF E0 len len 'J' 'F' 'I' 'F' 00 vMaj vMin units xD xD yD yD
        val hasJfif = bytes.size > 20 && bytes[2] == 0xFF.toByte() && bytes[3] == 0xE0.toByte() &&
            bytes[6] == 'J'.code.toByte() && bytes[7] == 'F'.code.toByte() && bytes[8] == 'I'.code.toByte() && bytes[9] == 'F'.code.toByte()
        if (hasJfif) {
            bytes[13] = 1 // dots per inch
            bytes[14] = (d shr 8).toByte(); bytes[15] = d.toByte()
            bytes[16] = (d shr 8).toByte(); bytes[17] = d.toByte()
            file.writeBytes(bytes)
        } else {
            // No JFIF segment: insert a fresh one right after SOI
            val jfif = byteArrayOf(
                0xFF.toByte(), 0xE0.toByte(), 0x00, 0x10,
                'J'.code.toByte(), 'F'.code.toByte(), 'I'.code.toByte(), 'F'.code.toByte(), 0x00,
                0x01, 0x01, 0x01,
                (d shr 8).toByte(), d.toByte(), (d shr 8).toByte(), d.toByte(),
                0x00, 0x00
            )
            file.writeBytes(bytes.copyOfRange(0, 2) + jfif + bytes.copyOfRange(2, bytes.size))
        }
    }

    private fun writePng(file: File, dpi: Int) {
        val bytes = file.readBytes()
        val ppm = Math.round(dpi / 0.0254).toInt()
        val data = ByteArray(9)
        for (i in 0..3) data[i] = (ppm shr (24 - 8 * i)).toByte()
        for (i in 0..3) data[4 + i] = (ppm shr (24 - 8 * i)).toByte()
        data[8] = 1 // unit = metre
        val type = "pHYs".toByteArray(Charsets.US_ASCII)
        val crc = CRC32().apply { update(type); update(data) }.value
        val chunk = ByteArray(4 + 4 + 9 + 4)
        chunk[3] = 9
        System.arraycopy(type, 0, chunk, 4, 4)
        System.arraycopy(data, 0, chunk, 8, 9)
        for (i in 0..3) chunk[17 + i] = (crc shr (24 - 8 * i)).toByte()
        // Insert after IHDR (8 byte signature + 25 byte IHDR chunk), dropping any pHYs already there
        val cut = 33
        val out = bytes.copyOfRange(0, cut) + chunk + stripPhys(bytes, cut)
        file.writeBytes(out)
    }

    private fun stripPhys(b: ByteArray, from: Int): ByteArray {
        var pos = from
        val keep = java.io.ByteArrayOutputStream()
        while (pos + 12 <= b.size) {
            val len = ((b[pos].toInt() and 0xFF) shl 24) or ((b[pos + 1].toInt() and 0xFF) shl 16) or
                ((b[pos + 2].toInt() and 0xFF) shl 8) or (b[pos + 3].toInt() and 0xFF)
            val total = 12 + len
            if (len < 0 || pos + total > b.size) { keep.write(b, pos, b.size - pos); break }
            val isPhys = b[pos + 4] == 'p'.code.toByte() && b[pos + 5] == 'H'.code.toByte() &&
                b[pos + 6] == 'Y'.code.toByte() && b[pos + 7] == 's'.code.toByte()
            if (!isPhys) keep.write(b, pos, total)
            pos += total
        }
        return keep.toByteArray()
    }
}
