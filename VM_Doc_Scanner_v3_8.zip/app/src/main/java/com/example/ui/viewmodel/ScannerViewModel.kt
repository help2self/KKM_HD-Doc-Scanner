package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.DocumentEntity
import com.example.data.local.FolderEntity
import com.example.data.local.PageEntity
import com.example.data.local.TagEntity
import com.example.data.model.*
import com.example.data.repository.DocumentRepository
import com.example.i18n.I18n
import com.example.i18n.Language
import com.example.processing.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class SortOption { DATE, NAME, SIZE }
enum class DateFilterOption { ALL_TIME, TODAY, THIS_WEEK, THIS_MONTH }

data class BatchCaptureItem(
    val id: String = UUID.randomUUID().toString(),
    val originalFile: File,
    val previewBitmap: Bitmap,
    var corners: CornerPoints,
    var autoCropSuccess: Boolean,
    var filter: FilterType = FilterType.ORIGINAL
)

class ScannerViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    val repository = DocumentRepository(context)
    private val prefs = context.getSharedPreferences("scanner_prefs", Context.MODE_PRIVATE)

    // Language & Theme state
    private val _language = MutableStateFlow(
        if (prefs.getString("lang", "hi") == "en") Language.ENGLISH else Language.HINDI
    )
    val language: StateFlow<Language> = _language.asStateFlow()

    private val _themeMode = MutableStateFlow(
        ThemeMode.valueOf(prefs.getString("theme", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Navigation state
    private val _navigationStack = MutableStateFlow<List<com.example.ui.Screen>>(listOf(com.example.ui.Screen.Home))
    val currentScreen: StateFlow<com.example.ui.Screen> = _navigationStack.map { it.last() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, com.example.ui.Screen.Home)

    // Data streams from repository
    val allDocuments: StateFlow<List<DocumentEntity>> = repository.getAllDocuments()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allFolders: StateFlow<List<FolderEntity>> = repository.getAllFolders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allTags: StateFlow<List<TagEntity>> = repository.getAllTags()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val totalPagesCount: StateFlow<Int> = repository.getTotalPagesCount()
        .stateIn(viewModelScope, SharingStarted.Lazily, 0)

    /** docId -> (thumbnail of first page, number of pages) for the Library grid. */
    val docPreviews: StateFlow<Map<String, Pair<String?, Int>>> = repository.getAllPages()
        .map { pages ->
            pages.groupBy { it.documentId }.mapValues { (_, list) ->
                val first = list.minByOrNull { it.pageOrder }
                val thumb = first?.let { if (it.thumbnailImagePath.isNotBlank()) it.thumbnailImagePath else it.originalImagePath }
                Pair(thumb, list.size)
            }
        }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyMap())

    /** Library display mode: true = grid, false = list (remembered). */
    val libraryGridView = MutableStateFlow(prefs.getBoolean("library_grid", true))
    fun setLibraryGridView(grid: Boolean) {
        libraryGridView.value = grid
        prefs.edit().putBoolean("library_grid", grid).apply()
    }

    // Library Filter & Search state
    val searchQuery = MutableStateFlow("")
    val selectedFolderId = MutableStateFlow<String?>(null) // null = all
    val selectedTagId = MutableStateFlow<String?>(null)
    val dateFilter = MutableStateFlow(DateFilterOption.ALL_TIME)
    val sortOption = MutableStateFlow(SortOption.DATE)

    // Storage info
    private val _storageInfo = MutableStateFlow(StorageInfo())
    val storageInfo: StateFlow<StorageInfo> = _storageInfo.asStateFlow()

    // Active document in DocumentDetailScreen
    val activeDocumentId = MutableStateFlow<String?>(null)
    val activeDocumentPages = MutableStateFlow<List<PageEntity>>(emptyList())

    // Capture & Batch scanning state
    val batchItems = MutableStateFlow<List<BatchCaptureItem>>(emptyList())
    val isAutoCropEnabled = MutableStateFlow(true)
    val autoApplyDefaultFilter = MutableStateFlow(false)
    val isSingleCaptureFlow = MutableStateFlow(true)
    var capturedTempFile: File? = null
    // 0 = Single, 1 = Batch : set by Home tiles so the camera opens in the chosen mode
    var initialScanMode: Int = 0
    // When set, the batch being scanned is added to this existing document instead of a new one
    val appendTargetDocId = MutableStateFlow<String?>(null)

    // Corner Editor state
    var cornerEditingBitmap: Bitmap? = null
    var cornerEditingPath: String? = null
    val cornerPoints = MutableStateFlow(CornerPoints.defaultFull())
    val autoDetectFailedMessage = MutableStateFlow(false)

    // Page Editor state
    val activeEditingPage = MutableStateFlow<PageEntity?>(null)
    var editorWorkingBitmap: Bitmap? = null
    val currentFilter = MutableStateFlow(FilterType.ORIGINAL)
    val editParameters = MutableStateFlow(EditParameters())
    val rotationAngle = MutableStateFlow(0)
    val editorHistory = MutableStateFlow<List<Pair<FilterType, EditParameters>>>(emptyList())
    val editorRedoStack = MutableStateFlow<List<Pair<FilterType, EditParameters>>>(emptyList())

    // Composer state
    val composerConfig = MutableStateFlow(ComposedPageConfig())
    val composerObjects = MutableStateFlow<List<ComposedObject>>(emptyList())
    val selectedObjectId = MutableStateFlow<String?>(null)
    val composerHistory = MutableStateFlow<List<List<ComposedObject>>>(emptyList())
    val composerRedoStack = MutableStateFlow<List<List<ComposedObject>>>(emptyList())

    // Passport Sheet state
    val passportConfig = MutableStateFlow(PassportConfig())
    var passportSourceBitmap: Bitmap? = null
    var passportGeneratedSheet: Bitmap? = null

    // Export state
    val exportFormat = MutableStateFlow(ExportFormat.PDF)
    val exportQuality = MutableStateFlow(ExportQuality.HIGH)
    val selectedExportPageIds = MutableStateFlow<Set<String>>(emptySet())

    // Feedback message
    val userNotification = MutableStateFlow<String?>(null)

    init {
        refreshStorageInfo()
        viewModelScope.launch {
            activeDocumentId.collectLatest { docId ->
                if (docId != null) {
                    repository.getPagesForDocument(docId).collectLatest { pages ->
                        activeDocumentPages.value = pages
                    }
                } else {
                    activeDocumentPages.value = emptyList()
                }
            }
        }
    }

    fun navigateTo(screen: com.example.ui.Screen) {
        _navigationStack.value = _navigationStack.value + screen
    }

    /** Opens the camera for a brand-new document (never appends to the last opened one). */
    fun startNewScan(mode: Int) {
        initialScanMode = mode
        activeDocumentId.value = null
        appendTargetDocId.value = null
        navigateTo(com.example.ui.Screen.CameraCapture)
    }

    /** Clears the composer so every new Blank Page starts empty. */
    fun resetComposer() {
        composerObjects.value = emptyList()
        composerHistory.value = emptyList()
        composerRedoStack.value = emptyList()
        selectedObjectId.value = null
    }

    fun openComposer() {
        resetComposer()
        navigateTo(com.example.ui.Screen.Composer)
    }

    /** Pictures shared into the app from Gallery / other apps ("Share -> VM Doc Scanner"). */
    fun importSharedImages(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            activeDocumentId.value = null
            val imported = mutableListOf<Pair<File, Bitmap>>()
            for (uri in uris) {
                try {
                    val file = File(context.filesDir, "shared_${UUID.randomUUID()}.jpg")
                    kotlinx.coroutines.withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            file.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                    val bmp = ImageProcessor.importPhoto(file)
                    if (bmp != null) imported.add(Pair(file, bmp))
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            if (imported.isEmpty()) {
                userNotification.value = "Could not open the shared image"
                return@launch
            }
            _navigationStack.value = listOf(com.example.ui.Screen.Home)
            if (imported.size == 1) {
                val (file, bmp) = imported.first()
                startSingleCapture(file, bmp)
            } else {
                batchItems.value = emptyList()
                for ((file, bmp) in imported) {
                    val (corners, success) = ImageProcessor.detectCorners(bmp)
                    batchItems.value = batchItems.value + BatchCaptureItem(
                        originalFile = file,
                        previewBitmap = bmp,
                        corners = corners,
                        autoCropSuccess = success,
                        filter = FilterType.MAGIC_COLOR
                    )
                }
                navigateTo(com.example.ui.Screen.BatchReview)
            }
        }
    }

    /** Untouched (cropped, unfiltered) copy of a page, used so filters never stack on filters. */
    fun baseFileFor(pageId: String): File = File(context.filesDir, "base_${pageId}.jpg")

    /** Re-renders every other page of a document from its untouched copy with [filter]. */
    fun applyFilterToOtherPages(documentId: String, exceptPageId: String, filter: FilterType) {
        viewModelScope.launch {
            val pages = repository.getPagesForDocumentSync(documentId)
            for (other in pages) {
                if (other.id == exceptPageId || other.pageType != "scan") continue
                val base = baseFileFor(other.id)
                if (!base.exists()) continue
                val src = ImageProcessor.loadBitmapFromFile(base.absolutePath) ?: continue
                val out = ImageProcessor.applyFiltersAndEdits(src, filter, EditParameters(), other.rotationDeg)
                ImageProcessor.saveBitmapToFile(out, File(other.originalImagePath))
                val thumb = Bitmap.createScaledBitmap(out, 300, (300f * out.height / out.width).toInt().coerceAtLeast(50), true)
                ImageProcessor.saveBitmapToFile(thumb, File(other.thumbnailImagePath), quality = 80)
                repository.savePage(other.copy(filterType = filter.name))
            }
        }
    }

    fun navigateBack(): Boolean {
        if (_navigationStack.value.size > 1) {
            _navigationStack.value = _navigationStack.value.dropLast(1)
            return true
        }
        return false
    }

    fun setLanguage(lang: Language) {
        _language.value = lang
        prefs.edit().putString("lang", lang.code).apply()
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString("theme", mode.name).apply()
    }

    fun refreshStorageInfo() {
        viewModelScope.launch {
            _storageInfo.value = repository.calculateStorageInfo()
        }
    }

    fun simulateStorage(percentage: Int) {
        when (percentage) {
            80 -> {
                repository.isSimulated80 = true
                repository.isSimulated95 = false
                repository.isSimulatedQuotaError = false
            }
            95 -> {
                repository.isSimulated80 = false
                repository.isSimulated95 = true
                repository.isSimulatedQuotaError = false
            }
            100 -> { // Quota error simulation
                repository.isSimulated80 = false
                repository.isSimulated95 = true
                repository.isSimulatedQuotaError = true
            }
            else -> {
                repository.isSimulated80 = false
                repository.isSimulated95 = false
                repository.isSimulatedQuotaError = false
            }
        }
        refreshStorageInfo()
    }

    // Capture & Batch actions
    fun addCapturedImage(imageFile: File, bitmap: Bitmap) {
        viewModelScope.launch {
            val (corners, success) = if (isAutoCropEnabled.value) {
                ImageProcessor.detectCorners(bitmap)
            } else {
                Pair(CornerPoints.defaultFull(), true)
            }

            val newItem = BatchCaptureItem(
                originalFile = imageFile,
                previewBitmap = bitmap,
                corners = corners,
                autoCropSuccess = success,
                filter = FilterType.MAGIC_COLOR
            )
            batchItems.value = batchItems.value + newItem
        }
    }

    fun startSingleCapture(imageFile: File, bitmap: Bitmap) {
        viewModelScope.launch {
            val (corners, success) = ImageProcessor.detectCorners(bitmap)
            cornerEditingBitmap = bitmap
            cornerEditingPath = imageFile.absolutePath
            capturedTempFile = imageFile
            cornerPoints.value = corners
            autoDetectFailedMessage.value = !success
            isSingleCaptureFlow.value = true
            navigateTo(com.example.ui.Screen.CornerEditor)
        }
    }

    /** Opens the corner editor for one page of the batch. */
    fun editBatchItemCorners(item: BatchCaptureItem) {
        cornerEditingBitmap = item.previewBitmap
        cornerEditingPath = item.originalFile.absolutePath
        cornerPoints.value = item.corners
        autoDetectFailedMessage.value = !item.autoCropSuccess
        isSingleCaptureFlow.value = false
        navigateTo(com.example.ui.Screen.CornerEditor)
    }

    /** Rotating a batch page in the corner editor rotates the saved file too. */
    fun rotateBatchItem(path: String, rotatedPreview: Bitmap, newCorners: CornerPoints) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val full = ImageProcessor.decodeOriented(path, 4096)
                if (full != null) {
                    val m = android.graphics.Matrix().apply { postRotate(90f) }
                    val rotated = Bitmap.createBitmap(full, 0, 0, full.width, full.height, m, true)
                    ImageProcessor.saveBitmapToFile(rotated, File(path), quality = 95)
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
            batchItems.value = batchItems.value.map { item ->
                if (item.originalFile.absolutePath == path) {
                    item.copy(previewBitmap = rotatedPreview, corners = newCorners, autoCropSuccess = true)
                } else item
            }
        }
    }

    /** Opens the camera to add more pages to an already saved document. */
    fun startAddPagesTo(docId: String) {
        appendTargetDocId.value = docId
        activeDocumentId.value = docId
        batchItems.value = emptyList()
        navigateTo(com.example.ui.Screen.CameraCapture)
    }

    /** After a batch is saved, show its document with Home underneath (no camera screens left on the stack). */
    fun showDocumentAfterSave(docId: String) {
        activeDocumentId.value = docId
        _navigationStack.value = listOf(com.example.ui.Screen.Home, com.example.ui.Screen.DocumentDetail)
    }

    fun setFilterForBatchItem(id: String, filter: FilterType) {
        batchItems.value = batchItems.value.map { if (it.id == id) it.copy(filter = filter) else it }
    }

    /** Rotates one batch page by 90 degrees to the left (file, preview and crop corners together). */
    fun rotateBatchItemLeft(item: BatchCaptureItem) {
        viewModelScope.launch(Dispatchers.Default) {
            val m = android.graphics.Matrix().apply { postRotate(-90f) }
            val prev = item.previewBitmap
            val rotatedPreview = Bitmap.createBitmap(prev, 0, 0, prev.width, prev.height, m, true)
            val c = item.corners
            // (x, y) -> (y, 1 - x) when the picture turns 90 degrees anticlockwise
            fun px(x: Float, y: Float) = y
            fun py(x: Float, y: Float) = 1f - x
            val newCorners = CornerPoints(
                tlX = px(c.trX, c.trY), tlY = py(c.trX, c.trY),
                trX = px(c.brX, c.brY), trY = py(c.brX, c.brY),
                brX = px(c.blX, c.blY), brY = py(c.blX, c.blY),
                blX = px(c.tlX, c.tlY), blY = py(c.tlX, c.tlY)
            )
            batchItems.value = batchItems.value.map {
                if (it.id == item.id) it.copy(previewBitmap = rotatedPreview, corners = newCorners) else it
            }
            withContext(Dispatchers.IO) {
                try {
                    val path = item.originalFile.absolutePath
                    val full = ImageProcessor.decodeOriented(path, 4096)
                    if (full != null) {
                        val rotated = Bitmap.createBitmap(full, 0, 0, full.width, full.height, m, true)
                        ImageProcessor.saveBitmapToFile(rotated, File(path), quality = 100)
                    }
                } catch (e: Throwable) { e.printStackTrace() }
            }
        }
    }

    fun setFilterForAllBatchItems(filter: FilterType) {
        batchItems.value = batchItems.value.map { it.copy(filter = filter) }
    }

    fun onCropConfirmed(warpedBitmap: Bitmap) {
        if (isSingleCaptureFlow.value) {
            editorWorkingBitmap = warpedBitmap
            currentFilter.value = FilterType.MAGIC_COLOR
            activeEditingPage.value = null
            navigateTo(com.example.ui.Screen.PageEditor)
        } else {
            batchItems.value = batchItems.value.map { item ->
                if (item.originalFile.absolutePath == cornerEditingPath) {
                    item.copy(corners = cornerPoints.value, autoCropSuccess = true)
                } else item
            }
            navigateBack()
        }
    }

    fun saveNewCapturedPage(
        bitmap: Bitmap,
        filter: FilterType,
        editParams: EditParameters,
        rotationDeg: Int,
        baseBitmap: Bitmap? = null,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            try {
                val timestamp = System.currentTimeMillis()
                var docId = activeDocumentId.value
                if (docId == null) {
                    docId = UUID.randomUUID().toString()
                    val doc = DocumentEntity(
                        id = docId,
                        name = I18n.defaultScanName(timestamp),
                        folderId = selectedFolderId.value,
                        createdAt = timestamp,
                        updatedAt = timestamp
                    )
                    repository.saveDocument(doc)
                    activeDocumentId.value = docId
                }

                val existingPages = repository.getPagesForDocumentSync(docId)
                val pageOrder = existingPages.size

                val pageId = UUID.randomUUID().toString()
                val origFile = File(context.filesDir, "scan_${pageId}.jpg")
                val thumbFile = File(context.filesDir, "thumb_${pageId}.jpg")

                ImageProcessor.saveBitmapToFile(bitmap, origFile)
                if (baseBitmap != null) ImageProcessor.saveBitmapToFile(baseBitmap, baseFileFor(pageId), quality = 95)
                val thumbBmp = Bitmap.createScaledBitmap(
                    bitmap,
                    300,
                    (300f * bitmap.height / bitmap.width).toInt().coerceAtLeast(50),
                    true
                )
                ImageProcessor.saveBitmapToFile(thumbBmp, thumbFile, quality = 80)

                val newPage = PageEntity(
                    id = pageId,
                    documentId = docId,
                    pageOrder = pageOrder,
                    pageType = "scan",
                    originalImagePath = origFile.absolutePath,
                    thumbnailImagePath = thumbFile.absolutePath,
                    cropCornersJson = JSONObject().apply {
                        put("tlX", cornerPoints.value.tlX)
                        put("tlY", cornerPoints.value.tlY)
                        put("trX", cornerPoints.value.trX)
                        put("trY", cornerPoints.value.trY)
                        put("brX", cornerPoints.value.brX)
                        put("brY", cornerPoints.value.brY)
                        put("blX", cornerPoints.value.blX)
                        put("blY", cornerPoints.value.blY)
                    }.toString(),
                    filterType = filter.name,
                    rotationDeg = rotationDeg
                )
                repository.savePage(newPage)
                refreshStorageInfo()

                capturedTempFile = null
                cornerEditingBitmap = null
                editorWorkingBitmap = null

                // Replace stack so user is at DocumentDetail
                _navigationStack.value = listOf(com.example.ui.Screen.Home, com.example.ui.Screen.DocumentDetail)
                onComplete()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun removeBatchItem(id: String) {
        batchItems.value = batchItems.value.filter { it.id != id }
    }

    fun finishBatch(documentName: String? = null, onComplete: (String) -> Unit) {
        viewModelScope.launch {
            if (batchItems.value.isEmpty()) return@launch
            try {
                val timestamp = System.currentTimeMillis()
                val target = appendTargetDocId.value?.let { repository.getDocumentById(it) }
                val docId: String
                val startOrder: Int
                if (target != null) {
                    // Add the new pages after the last page of the existing document
                    docId = target.id
                    startOrder = repository.getPagesForDocumentSync(docId).size
                    repository.saveDocument(target.copy(updatedAt = timestamp))
                } else {
                    docId = UUID.randomUUID().toString()
                    startOrder = 0
                    val finalName = documentName?.ifBlank { null } ?: I18n.defaultScanName(timestamp)
                    val doc = DocumentEntity(
                        id = docId,
                        name = finalName,
                        folderId = selectedFolderId.value,
                        createdAt = timestamp,
                        updatedAt = timestamp
                    )
                    repository.saveDocument(doc)
                }

                val pages = mutableListOf<PageEntity>()
                for ((index, item) in batchItems.value.withIndex()) {
                    val pageId = UUID.randomUUID().toString()
                    val fullRes = ImageProcessor.decodeOriented(item.originalFile.absolutePath, 4096)
                        ?: item.previewBitmap
                    val warped = ImageProcessor.warpPerspective(fullRes, item.corners)
                    ImageProcessor.saveBitmapToFile(warped, baseFileFor(pageId), quality = 95)
                    val filtered = ImageProcessor.applyFiltersAndEdits(warped, item.filter, EditParameters())

                    val origFile = File(context.filesDir, "scan_${pageId}.jpg")
                    val thumbFile = File(context.filesDir, "thumb_${pageId}.jpg")
                    ImageProcessor.saveBitmapToFile(filtered, origFile)

                    val thumbBmp = Bitmap.createScaledBitmap(filtered, 300, (300f * filtered.height / filtered.width).toInt().coerceAtLeast(50), true)
                    ImageProcessor.saveBitmapToFile(thumbBmp, thumbFile, quality = 80)

                    // Free memory before the next page is processed
                    if (thumbBmp != filtered) thumbBmp.recycle()
                    filtered.recycle()
                    warped.recycle()
                    if (fullRes !== item.previewBitmap) fullRes.recycle()

                    pages.add(
                        PageEntity(
                            id = pageId,
                            documentId = docId,
                            pageOrder = startOrder + index,
                            pageType = "scan",
                            originalImagePath = origFile.absolutePath,
                            thumbnailImagePath = thumbFile.absolutePath,
                            cropCornersJson = JSONObject().apply {
                                put("tlX", item.corners.tlX)
                                put("tlY", item.corners.tlY)
                                put("trX", item.corners.trX)
                                put("trY", item.corners.trY)
                                put("brX", item.corners.brX)
                                put("brY", item.corners.brY)
                                put("blX", item.corners.blX)
                                put("blY", item.corners.blY)
                            }.toString(),
                            filterType = item.filter.name
                        )
                    )
                }

                repository.savePages(pages)
                batchItems.value = emptyList()
                appendTargetDocId.value = null
                refreshStorageInfo()
                activeDocumentId.value = docId
                onComplete(docId)
            } catch (e: Exception) {
                userNotification.value = "Storage error: ${e.message}"
            }
        }
    }

    // Document actions
    fun renameDocument(docId: String, newName: String) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId) ?: return@launch
            repository.saveDocument(doc.copy(name = newName.trim(), updatedAt = System.currentTimeMillis()))
        }
    }

    fun updateNotes(docId: String, notes: String) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId) ?: return@launch
            repository.saveDocument(doc.copy(notes = notes, updatedAt = System.currentTimeMillis()))
        }
    }

    fun setDocumentFolder(docId: String, folderId: String?) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId) ?: return@launch
            repository.saveDocument(doc.copy(folderId = folderId, updatedAt = System.currentTimeMillis()))
        }
    }

    fun toggleDocumentTag(docId: String, tagId: String) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId) ?: return@launch
            val arr = try { JSONArray(doc.tagIdsJson) } catch (e: Exception) { JSONArray() }
            val newArr = JSONArray()
            var found = false
            for (i in 0 until arr.length()) {
                val tid = arr.optString(i)
                if (tid == tagId) {
                    found = true
                } else {
                    newArr.put(tid)
                }
            }
            if (!found) {
                newArr.put(tagId)
            }
            repository.saveDocument(doc.copy(tagIdsJson = newArr.toString(), updatedAt = System.currentTimeMillis()))
        }
    }

    fun duplicatePage(page: PageEntity) {
        viewModelScope.launch {
            repository.duplicatePage(page)
            refreshStorageInfo()
        }
    }

    fun deletePage(page: PageEntity) {
        viewModelScope.launch {
            repository.deletePage(page)
            refreshStorageInfo()
        }
    }

    fun deleteDocument(doc: DocumentEntity) {
        viewModelScope.launch {
            repository.deleteDocument(doc)
            refreshStorageInfo()
            if (activeDocumentId.value == doc.id) {
                activeDocumentId.value = null
                navigateBack()
            }
        }
    }

    // Composer Undo/Redo & Tools
    fun updateComposerObjects(newObjects: List<ComposedObject>) {
        composerHistory.value = (composerHistory.value + listOf(composerObjects.value)).takeLast(50)
        composerRedoStack.value = emptyList()
        composerObjects.value = newObjects
    }

    fun undoComposer() {
        if (composerHistory.value.isNotEmpty()) {
            val prev = composerHistory.value.last()
            composerHistory.value = composerHistory.value.dropLast(1)
            composerRedoStack.value = composerRedoStack.value + listOf(composerObjects.value)
            composerObjects.value = prev
        }
    }

    fun redoComposer() {
        if (composerRedoStack.value.isNotEmpty()) {
            val next = composerRedoStack.value.last()
            composerRedoStack.value = composerRedoStack.value.dropLast(1)
            composerHistory.value = composerHistory.value + listOf(composerObjects.value)
            composerObjects.value = next
        }
    }

    fun applyReadyLayout(layoutType: String, importedPaths: List<String>) {
        if (importedPaths.isEmpty()) return
        val w = composerConfig.value.widthMm
        val h = composerConfig.value.heightMm
        val margin = composerConfig.value.marginMm

        val availW = w - 2 * margin
        val availH = h - 2 * margin

        val newObjs = mutableListOf<ComposedObject>()
        when (layoutType) {
            "1" -> {
                newObjs.add(
                    ComposedObject(
                        id = UUID.randomUUID().toString(),
                        type = ObjectType.IMAGE,
                        imagePath = importedPaths.first(),
                        xMm = margin,
                        yMm = margin,
                        widthMm = availW,
                        heightMm = availH
                    )
                )
            }
            "2" -> {
                val itemH = (availH - 5f) / 2f
                for (i in 0 until minOf(2, importedPaths.size)) {
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = importedPaths[i],
                            xMm = margin,
                            yMm = margin + i * (itemH + 5f),
                            widthMm = availW,
                            heightMm = itemH
                        )
                    )
                }
            }
            "4" -> {
                val itemW = (availW - 5f) / 2f
                val itemH = (availH - 5f) / 2f
                for (i in 0 until minOf(4, importedPaths.size)) {
                    val col = i % 2
                    val row = i / 2
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = importedPaths[i],
                            xMm = margin + col * (itemW + 5f),
                            yMm = margin + row * (itemH + 5f),
                            widthMm = itemW,
                            heightMm = itemH
                        )
                    )
                }
            }
            "6" -> {
                val itemW = (availW - 5f) / 2f
                val itemH = (availH - 10f) / 3f
                for (i in 0 until minOf(6, importedPaths.size)) {
                    val col = i % 2
                    val row = i / 2
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = importedPaths[i],
                            xMm = margin + col * (itemW + 5f),
                            yMm = margin + row * (itemH + 5f),
                            widthMm = itemW,
                            heightMm = itemH
                        )
                    )
                }
            }
            "id_card" -> {
                // Exact Indian/Standard ID Card size: 85.6 mm x 54.0 mm
                val cardW = 85.6f
                val cardH = 54.0f
                val centerX = (w - cardW) / 2f
                val gap = 20f
                val startY = (h - (cardH * 2 + gap)) / 2f

                for (i in 0 until minOf(2, importedPaths.size)) {
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = importedPaths[i],
                            xMm = centerX,
                            yMm = startY + i * (cardH + gap),
                            widthMm = cardW,
                            heightMm = cardH,
                            borderWidthMm = 0.3f,
                            borderColor = 0xFFCCCCCC.toInt()
                        )
                    )
                }
            }
        }
        updateComposerObjects(newObjs)
    }

    // Save composed page into active document or new document
    fun saveComposedPage(documentId: String?, onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                val targetDocId = documentId ?: run {
                    val newId = UUID.randomUUID().toString()
                    val timestamp = System.currentTimeMillis()
                    val newDoc = DocumentEntity(
                        id = newId,
                        name = "Composed " + I18n.defaultScanName(timestamp),
                        createdAt = timestamp,
                        updatedAt = timestamp
                    )
                    repository.saveDocument(newDoc)
                    newId
                }

                val pageId = UUID.randomUUID().toString()
                val renderedBmp = ImageProcessor.renderComposedPage(composerConfig.value, composerObjects.value, dpi = 300)
                val origFile = File(context.filesDir, "composed_${pageId}.jpg")
                val thumbFile = File(context.filesDir, "thumb_${pageId}.jpg")
                ImageProcessor.saveBitmapToFile(renderedBmp, origFile)

                val thumb = Bitmap.createScaledBitmap(renderedBmp, 300, (300f * renderedBmp.height / renderedBmp.width).toInt(), true)
                ImageProcessor.saveBitmapToFile(thumb, thumbFile, quality = 80)

                val currentPages = repository.getPagesForDocumentSync(targetDocId)
                val newPage = PageEntity(
                    id = pageId,
                    documentId = targetDocId,
                    pageOrder = currentPages.size,
                    pageType = "composed",
                    originalImagePath = origFile.absolutePath,
                    thumbnailImagePath = thumbFile.absolutePath
                )
                repository.savePage(newPage)
                refreshStorageInfo()
                activeDocumentId.value = targetDocId
                // The blank page is finished: start the next one empty
                resetComposer()
                onComplete()
            } catch (e: Exception) {
                userNotification.value = "Failed to save composed page: ${e.message}"
            }
        }
    }
}
