package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.data.model.EditParameters
import com.example.data.model.FilterType
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageEditorScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val activePage by viewModel.activeEditingPage.collectAsState()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }   // preview-size base
    var fullBitmap by remember { mutableStateOf<Bitmap?>(null) }       // full-size base used when saving
    var currentDisplayBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var recomputeJob by remember { mutableStateOf<Job?>(null) }
    var isSaving by remember { mutableStateOf(false) }
    val filterThumbs = remember { mutableStateMapOf<FilterType, ImageBitmap>() }

    var filter by remember { mutableStateOf(FilterType.ORIGINAL) }
    var editParams by remember { mutableStateOf(EditParameters()) }
    var rotationDeg by remember { mutableStateOf(0) }

    var isHoldingCompare by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf(0) } // 0: Filters, 1: Adjust, 2: Transform, 3: Tools

    // History stack (at least 30 steps)
    val undoStack = remember { mutableStateListOf<Triple<FilterType, EditParameters, Int>>() }
    val redoStack = remember { mutableStateListOf<Triple<FilterType, EditParameters, Int>>() }

    val context = LocalContext.current

    // Cover brush: strokes stored as 0..1 positions on the picture, so they survive any screen size
    val brushStrokes = remember { mutableStateListOf<ImageProcessor.BrushStroke>() }
    var currentStroke by remember { mutableStateOf<List<Pair<Float, Float>>>(emptyList()) }
    var isWhitenMode by remember { mutableStateOf(false) }
    var brushWidth by remember { mutableStateOf(0.05f) }          // fraction of the picture width
    var brushColor by remember { mutableStateOf(android.graphics.Color.WHITE) }

    // Signature: drawn once, then placed on the page as a movable / resizable layer
    var showSignatureDialog by remember { mutableStateOf(false) }
    // Any number of signatures can be placed; tap one to select it, then drag / pinch / resize it
    val sigLayers = remember { mutableStateListOf<SigLayer>() }
    var selSig by remember { mutableStateOf(-1) }
    val selLayer: SigLayer? = sigLayers.getOrNull(selSig)
    // All saved signatures live in filesDir/signatures (the old single my_signature.png is moved there)
    val signatureDir = remember {
        File(context.filesDir, "signatures").apply {
            mkdirs()
            val old = File(context.filesDir, "my_signature.png")
            if (old.exists()) old.renameTo(File(this, "sig_${old.lastModified()}.png"))
        }
    }

    // Apply to all pages toggle
    var applyToAllPages by remember { mutableStateOf(false) }

    // Load initial page bitmap or working bitmap from crop
    LaunchedEffect(activePage, viewModel.editorWorkingBitmap) {
        val page = activePage
        if (page != null && page.originalImagePath.isNotBlank()) {
            // Edit from the untouched cropped copy, so a new filter never stacks on the old one
            val baseFile = viewModel.baseFileFor(page.id)
            val hasBase = baseFile.exists()
            val path = if (hasBase) baseFile.absolutePath else page.originalImagePath
            val full = ImageProcessor.loadBitmapFromFile(path, maxDimension = 3000)
            val preview = full?.let { ImageProcessor.downscale(it, 2200) }
            fullBitmap = full
            originalBitmap = preview
            if (hasBase) {
                filter = try { FilterType.valueOf(page.filterType) } catch (e: Exception) { FilterType.ORIGINAL }
                rotationDeg = page.rotationDeg
            } else {
                // Old page without an untouched copy: what is saved is the starting point
                filter = FilterType.ORIGINAL
                rotationDeg = 0
            }
            currentDisplayBitmap = preview?.let { ImageProcessor.applyFiltersAndEdits(it, filter, editParams, rotationDeg) }
        } else if (viewModel.editorWorkingBitmap != null) {
            val full = viewModel.editorWorkingBitmap!!
            // Work on a screen-sized copy so every filter tap is instant; the full copy is used on save
            val preview = ImageProcessor.downscale(full, 2200)
            fullBitmap = full
            originalBitmap = preview
            filter = FilterType.MAGIC_COLOR // CamScanner signature default
            rotationDeg = 0
            currentDisplayBitmap = ImageProcessor.applyFiltersAndEdits(preview, FilterType.MAGIC_COLOR, editParams, 0)
        }
    }

    // Small preview picture for every filter button
    LaunchedEffect(originalBitmap) {
        val base = originalBitmap ?: return@LaunchedEffect
        val small = ImageProcessor.downscale(base, 180)
        for (f in FilterType.values()) {
            val t = ImageProcessor.applyFiltersAndEdits(small, f, EditParameters(), 0)
            filterThumbs[f] = t.asImageBitmap()
        }
    }

    // Live update rendered preview (latest request wins)
    fun recomputePreview() {
        val base = originalBitmap ?: return
        recomputeJob?.cancel()
        recomputeJob = coroutineScope.launch {
            val processed = ImageProcessor.applyFiltersAndEdits(base, filter, editParams, rotationDeg)
            currentDisplayBitmap = processed
        }
    }

    fun pushHistory() {
        if (undoStack.size >= 40) undoStack.removeAt(0)
        undoStack.add(Triple(filter, editParams, rotationDeg))
        redoStack.clear()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("page_editor_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    // Undo
                    IconButton(
                        onClick = {
                            if (undoStack.isNotEmpty()) {
                                redoStack.add(Triple(filter, editParams, rotationDeg))
                                val state = undoStack.removeLast()
                                filter = state.first
                                editParams = state.second
                                rotationDeg = state.third
                                recomputePreview()
                            }
                        },
                        enabled = undoStack.isNotEmpty(),
                        modifier = Modifier.testTag("editor_undo_btn")
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = I18n.get("undo", lang))
                    }

                    // Redo
                    IconButton(
                        onClick = {
                            if (redoStack.isNotEmpty()) {
                                undoStack.add(Triple(filter, editParams, rotationDeg))
                                val state = redoStack.removeLast()
                                filter = state.first
                                editParams = state.second
                                rotationDeg = state.third
                                recomputePreview()
                            }
                        },
                        enabled = redoStack.isNotEmpty(),
                        modifier = Modifier.testTag("editor_redo_btn")
                    ) {
                        Icon(Icons.Default.Redo, contentDescription = I18n.get("redo", lang))
                    }

                    // Save
                    TextButton(
                        enabled = !isSaving,
                        onClick = {
                            isSaving = true
                            coroutineScope.launch {
                                try {
                                    // Re-render from the full-size picture so the saved page stays sharp
                                    val src = fullBitmap ?: originalBitmap
                                    var bmpToSave: Bitmap? = if (src != null) {
                                        ImageProcessor.applyFiltersAndEdits(src, filter, editParams, rotationDeg)
                                    } else {
                                        currentDisplayBitmap
                                    }
                                    if (bmpToSave == null) return@launch
                                    // Brush and signature are drawn on the FULL-size page, so they stay sharp
                                    if (brushStrokes.isNotEmpty()) {
                                        bmpToSave = withContext(Dispatchers.Default) {
                                            ImageProcessor.paintStrokes(bmpToSave!!, brushStrokes.toList())
                                        }
                                    }
                                    for (layer in sigLayers.toList()) {
                                        bmpToSave = withContext(Dispatchers.Default) {
                                            ImageProcessor.drawOverlay(bmpToSave!!, layer.bmp, layer.left, layer.top, layer.width)
                                        }
                                    }

                                    val finalBmp: Bitmap = bmpToSave ?: return@launch
                                    val page = activePage
                                    if (page != null) {
                                        // Existing page update. Keep an untouched copy first (older pages had none)
                                        val baseFile = viewModel.baseFileFor(page.id)
                                        if (!baseFile.exists() && File(page.originalImagePath).exists()) {
                                            File(page.originalImagePath).copyTo(baseFile, overwrite = true)
                                        }
                                        val origFile = File(page.originalImagePath)
                                        val thumbFile = File(page.thumbnailImagePath)
                                        ImageProcessor.saveBitmapToFile(finalBmp, origFile)

                                        val thumb = Bitmap.createScaledBitmap(
                                            finalBmp, 300,
                                            (300f * finalBmp.height / finalBmp.width).toInt().coerceAtLeast(50), true
                                        )
                                        ImageProcessor.saveBitmapToFile(thumb, thumbFile, quality = 80)

                                        val updatedPage = page.copy(
                                            filterType = filter.name,
                                            rotationDeg = rotationDeg
                                        )
                                        viewModel.repository.savePage(updatedPage)

                                        if (applyToAllPages) {
                                            viewModel.applyFilterToOtherPages(page.documentId, page.id, filter)
                                        }
                                        viewModel.refreshStorageInfo()
                                        viewModel.navigateBack()
                                    } else {
                                        // New capture flow
                                        viewModel.saveNewCapturedPage(
                                            bitmap = finalBmp,
                                            filter = filter,
                                            editParams = editParams,
                                            rotationDeg = rotationDeg,
                                            baseBitmap = fullBitmap
                                        ) {
                                            // navigated to DocumentDetail
                                        }
                                    }
                                } finally {
                                    isSaving = false
                                }
                            }
                        },
                        modifier = Modifier.testTag("save_edits_btn")
                    ) {
                        Text(I18n.get("save", lang), fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(bottom = 8.dp)
                ) {
                    // Tab Row: Filters, Adjust, Transform, Tools
                    TabRow(selectedTabIndex = activeTab) {
                        Tab(
                            selected = activeTab == 0,
                            onClick = { activeTab = 0 },
                            text = { Text(I18n.get("tab_filters", lang), maxLines = 1, softWrap = false, style = MaterialTheme.typography.labelLarge) }
                        )
                        Tab(
                            selected = activeTab == 1,
                            onClick = { activeTab = 1 },
                            text = { Text(I18n.get("tab_adjust", lang), maxLines = 1, softWrap = false, style = MaterialTheme.typography.labelLarge) }
                        )
                        Tab(
                            selected = activeTab == 2,
                            onClick = { activeTab = 2 },
                            text = { Text(I18n.get("tab_transform", lang), maxLines = 1, softWrap = false, style = MaterialTheme.typography.labelLarge) }
                        )
                        Tab(
                            selected = activeTab == 3,
                            onClick = { activeTab = 3 },
                            text = { Text(I18n.get("tab_tools", lang), maxLines = 1, softWrap = false, style = MaterialTheme.typography.labelLarge) }
                        )
                    }

                    when (activeTab) {
                        0 -> {
                            // Filters List (compact, so the picture gets more room)
                            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val camFilters = listOf(
                                        FilterType.MAGIC_COLOR,
                                        FilterType.ORIGINAL,
                                        FilterType.DOCUMENT_BW,
                                        FilterType.BW2,
                                        FilterType.GRAYSCALE,
                                        FilterType.LIGHTEN,
                                        FilterType.AUTO_ENHANCE,
                                        FilterType.REMOVE_SHADOW
                                    )
                                    camFilters.forEach { f ->
                                        val labelKey = when (f) {
                                            FilterType.ORIGINAL -> "filter_original"
                                            FilterType.MAGIC_COLOR -> "filter_magic_color"
                                            FilterType.DOCUMENT_BW -> "filter_doc_bw"
                                            FilterType.BW2 -> "filter_bw2"
                                            FilterType.GRAYSCALE -> "filter_grayscale"
                                            FilterType.LIGHTEN -> "filter_lighten"
                                            FilterType.AUTO_ENHANCE -> "filter_auto_enhance"
                                            FilterType.REMOVE_SHADOW -> "filter_remove_shadow"
                                        }
                                        val selected = filter == f
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier
                                                .width(60.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .clickable {
                                                    pushHistory()
                                                    filter = f
                                                    recomputePreview()
                                                }
                                                .testTag("filter_chip_${f.name}")
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(56.dp, 70.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color.White)
                                                    .border(
                                                        if (selected) 3.dp else 1.dp,
                                                        if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                                        RoundedCornerShape(8.dp)
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                val thumb = filterThumbs[f]
                                                if (thumb != null) {
                                                    Image(
                                                        bitmap = thumb,
                                                        contentDescription = null,
                                                        contentScale = ContentScale.Fit,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                } else {
                                                    CircularProgressIndicator(
                                                        modifier = Modifier.size(20.dp),
                                                        strokeWidth = 2.dp
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = I18n.get(labelKey, lang),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(
                                            checked = applyToAllPages,
                                            onCheckedChange = { applyToAllPages = it }
                                        )
                                        Text(I18n.get("apply_all_pages", lang), style = MaterialTheme.typography.bodySmall)
                                    }

                                    // Reset to original button
                                    TextButton(onClick = {
                                        pushHistory()
                                        filter = FilterType.ORIGINAL
                                        editParams = EditParameters()
                                        rotationDeg = 0
                                        brushStrokes.clear()
                                        recomputePreview()
                                    }) {
                                        Text(I18n.get("reset_original", lang))
                                    }
                                }
                            }
                        }
                        1 -> {
                            // Adjust: Brightness, Contrast, Sharpness
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    "${I18n.get("brightness", lang)}: ${(editParams.brightness * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Slider(
                                    value = editParams.brightness,
                                    onValueChange = {
                                        editParams = editParams.copy(brightness = it)
                                        recomputePreview()
                                    },
                                    onValueChangeFinished = { pushHistory() },
                                    valueRange = -1f..1f,
                                    modifier = Modifier.testTag("brightness_slider")
                                )

                                Text(
                                    "${I18n.get("contrast", lang)}: ${(editParams.contrast * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Slider(
                                    value = editParams.contrast,
                                    onValueChange = {
                                        editParams = editParams.copy(contrast = it)
                                        recomputePreview()
                                    },
                                    onValueChangeFinished = { pushHistory() },
                                    valueRange = 0.5f..2.5f,
                                    modifier = Modifier.testTag("contrast_slider")
                                )
                                TextButton(
                                    onClick = {
                                        pushHistory()
                                        editParams = editParams.copy(brightness = 0f, contrast = 1f, sharpness = 0f)
                                        recomputePreview()
                                    },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Icon(Icons.Default.RestartAlt, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(I18n.get("reset", lang))
                                }
                            }
                        }
                        2 -> {
                            // Transform: Rotate 90, Straighten, Flip H, Flip V
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            pushHistory()
                                            rotationDeg = (rotationDeg + 90) % 360
                                            brushStrokes.clear()
                                            recomputePreview()
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.RotateRight, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(I18n.get("rotate_90", lang), style = MaterialTheme.typography.bodySmall)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            pushHistory()
                                            editParams = editParams.copy(flipH = !editParams.flipH)
                                            brushStrokes.clear()
                                            recomputePreview()
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(I18n.get("flip_h", lang), style = MaterialTheme.typography.bodySmall)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            pushHistory()
                                            editParams = editParams.copy(flipV = !editParams.flipV)
                                            brushStrokes.clear()
                                            recomputePreview()
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(I18n.get("flip_v", lang), style = MaterialTheme.typography.bodySmall)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    "${I18n.get("straighten", lang)}: ${editParams.straightenAngle.toInt()}°",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Slider(
                                    value = editParams.straightenAngle,
                                    onValueChange = {
                                        editParams = editParams.copy(straightenAngle = it)
                                        brushStrokes.clear()
                                        recomputePreview()
                                    },
                                    onValueChangeFinished = { pushHistory() },
                                    valueRange = -45f..45f
                                )
                                TextButton(
                                    onClick = {
                                        pushHistory()
                                        rotationDeg = 0
                                        editParams = editParams.copy(flipH = false, flipV = false, straightenAngle = 0f)
                                        brushStrokes.clear()
                                        recomputePreview()
                                    },
                                    modifier = Modifier.align(Alignment.End).testTag("rotate_reset_btn")
                                ) {
                                    Icon(Icons.Default.RestartAlt, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(I18n.get("reset", lang))
                                }
                            }
                        }
                        3 -> {
                            // Tools: cover brush (width + colour) and signature (movable / resizable layer)
                            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    FilterChip(
                                        selected = isWhitenMode,
                                        onClick = { isWhitenMode = !isWhitenMode },
                                        label = { Text(I18n.get("whiten_brush", lang), maxLines = 1) },
                                        leadingIcon = { Icon(Icons.Default.Brush, contentDescription = null) },
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        onClick = { isWhitenMode = false; showSignatureDialog = true },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Draw, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(I18n.get("signature_tool", lang), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                                    }
                                }

                                if (isWhitenMode) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(I18n.get("brush_width", lang), style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(72.dp))
                                        Slider(
                                            value = brushWidth,
                                            onValueChange = { brushWidth = it },
                                            valueRange = 0.01f..0.15f,
                                            modifier = Modifier.weight(1f).testTag("brush_width_slider")
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        listOf(
                                            android.graphics.Color.WHITE,
                                            android.graphics.Color.BLACK,
                                            0xFF1E3A8A.toInt(),
                                            0xFFDC2626.toInt(),
                                            0x80FFEB3B.toInt()
                                        ).forEach { c ->
                                            Box(
                                                modifier = Modifier
                                                    .size(30.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(c))
                                                    .border(
                                                        if (brushColor == c) 3.dp else 1.dp,
                                                        if (brushColor == c) MaterialTheme.colorScheme.primary else Color.Gray,
                                                        CircleShape
                                                    )
                                                    .clickable { brushColor = c }
                                            )
                                        }
                                        Spacer(modifier = Modifier.weight(1f))
                                        IconButton(
                                            onClick = { if (brushStrokes.isNotEmpty()) brushStrokes.removeAt(brushStrokes.size - 1) },
                                            enabled = brushStrokes.isNotEmpty()
                                        ) { Icon(Icons.Default.Undo, contentDescription = I18n.get("undo", lang)) }
                                        IconButton(
                                            onClick = { brushStrokes.clear() },
                                            enabled = brushStrokes.isNotEmpty()
                                        ) { Icon(Icons.Default.DeleteSweep, contentDescription = I18n.get("reset", lang)) }
                                    }
                                }

                                if (selLayer != null && !isWhitenMode) {
                                    Text(I18n.get("signature_move_hint", lang), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(I18n.get("signature_size", lang), style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(72.dp))
                                        Slider(
                                            value = selLayer.width,
                                            onValueChange = { v -> if (selSig in sigLayers.indices) sigLayers[selSig] = sigLayers[selSig].copy(width = v) },
                                            valueRange = 0.08f..0.9f,
                                            modifier = Modifier.weight(1f).testTag("signature_size_slider")
                                        )
                                        IconButton(onClick = {
                                            if (selSig in sigLayers.indices) sigLayers.removeAt(selSig)
                                            selSig = sigLayers.size - 1
                                        }) {
                                            Icon(Icons.Default.Delete, contentDescription = I18n.get("remove_signature", lang))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            val bmpToDisplay = if (isHoldingCompare) originalBitmap else currentDisplayBitmap
            val displayState = rememberUpdatedState(bmpToDisplay)
            // The brush only paints while the Tools tab is open and the brush is switched on,
            // so ordinary touches on the picture never leave marks.
            val brushActive = isWhitenMode && activeTab == 3 && !isHoldingCompare
            // The signature layer can be moved (one finger) and resized (two fingers) on the Tools tab
            val sigActive = sigLayers.isNotEmpty() && !isWhitenMode && activeTab == 3 && !isHoldingCompare

            if (bmpToDisplay != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Picture rectangle on screen for the current canvas size
                    fun fit(cw: Float, ch: Float, b: Bitmap): FloatArray {
                        val sc = minOf(cw / b.width, ch / b.height)
                        val dw = b.width * sc
                        val dh = b.height * sc
                        return floatArrayOf((cw - dw) / 2f, (ch - dh) / 2f, dw, dh)
                    }
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(sigActive) {
                                // Tap a signature to select it (the top-most one under the finger)
                                if (sigActive) detectTapGestures { pos ->
                                    val b = displayState.value ?: return@detectTapGestures
                                    val r = fit(size.width.toFloat(), size.height.toFloat(), b)
                                    for (k in sigLayers.indices.reversed()) {
                                        val l = sigLayers[k]
                                        val sw = l.width * r[2]
                                        val sh = sw * l.bmp.height / l.bmp.width
                                        val sl = r[0] + l.left * r[2]
                                        val st = r[1] + l.top * r[3]
                                        if (pos.x in sl..(sl + sw) && pos.y in st..(st + sh)) { selSig = k; break }
                                    }
                                }
                            }
                            .pointerInput(brushActive, sigActive) {
                                if (brushActive) {
                                    detectDragGestures(
                                        onDragStart = { pos ->
                                            val b = displayState.value ?: return@detectDragGestures
                                            val r = fit(size.width.toFloat(), size.height.toFloat(), b)
                                            currentStroke = listOf(Pair((pos.x - r[0]) / r[2], (pos.y - r[1]) / r[3]))
                                        },
                                        onDragEnd = {
                                            if (currentStroke.isNotEmpty()) {
                                                brushStrokes.add(ImageProcessor.BrushStroke(currentStroke, brushWidth, brushColor))
                                            }
                                            currentStroke = emptyList()
                                        },
                                        onDragCancel = { currentStroke = emptyList() }
                                    ) { change, _ ->
                                        change.consume()
                                        val b = displayState.value ?: return@detectDragGestures
                                        val r = fit(size.width.toFloat(), size.height.toFloat(), b)
                                        val nx = (change.position.x - r[0]) / r[2]
                                        val ny = (change.position.y - r[1]) / r[3]
                                        currentStroke = currentStroke + Pair(nx, ny)
                                    }
                                } else if (sigActive) {
                                    detectTransformGestures { _, pan, zoom, _ ->
                                        val b = displayState.value ?: return@detectTransformGestures
                                        val r = fit(size.width.toFloat(), size.height.toFloat(), b)
                                        val idx = selSig
                                        val layer = sigLayers.getOrNull(idx) ?: return@detectTransformGestures
                                        val sig = layer.bmp
                                        val oldW = layer.width
                                        val newW = (oldW * zoom).coerceIn(0.05f, 1f)
                                        val aspect = sig.height.toFloat() / sig.width
                                        // keep the centre where it is while resizing
                                        val cx = layer.left + oldW / 2f
                                        val cy = layer.top + oldW * aspect * r[2] / r[3] / 2f
                                        val hFrac = newW * aspect * r[2] / r[3]
                                        sigLayers[idx] = layer.copy(
                                            width = newW,
                                            left = (cx - newW / 2f + pan.x / r[2]).coerceIn(-newW / 2f, 1f - newW / 2f),
                                            top = (cy - hFrac / 2f + pan.y / r[3]).coerceIn(-hFrac / 2f, 1f - hFrac / 2f)
                                        )
                                    }
                                }
                            }
                    ) {
                        val r = fit(size.width, size.height, bmpToDisplay)
                        val ox = r[0]; val oy = r[1]; val dw = r[2]; val dh = r[3]

                        drawImage(
                            image = bmpToDisplay.asImageBitmap(),
                            dstOffset = IntOffset(ox.toInt(), oy.toInt()),
                            dstSize = IntSize(dw.toInt(), dh.toInt())
                        )

                        if (!isHoldingCompare) {
                            // Brush strokes (same size / position as they will be saved)
                            val all = brushStrokes.toList() +
                                (if (currentStroke.isNotEmpty()) listOf(ImageProcessor.BrushStroke(currentStroke, brushWidth, brushColor)) else emptyList())
                            for (st in all) {
                                val col = Color(st.color)
                                val wPx = st.widthFraction * dw
                                val pts = st.points.map { Offset(ox + it.first * dw, oy + it.second * dh) }
                                if (pts.size == 1) drawCircle(col, wPx / 2f, pts[0])
                                for (q in 0 until pts.size - 1) {
                                    drawLine(col, pts[q], pts[q + 1], strokeWidth = wPx, cap = StrokeCap.Round)
                                }
                            }

                            // Signature layer
                            sigLayers.forEachIndexed { k, layer ->
                                val sig = layer.bmp
                                val sw = layer.width * dw
                                val sh = sw * sig.height / sig.width
                                val sl = ox + layer.left * dw
                                val st = oy + layer.top * dh
                                drawImage(
                                    image = sig.asImageBitmap(),
                                    dstOffset = IntOffset(sl.toInt(), st.toInt()),
                                    dstSize = IntSize(sw.toInt().coerceAtLeast(1), sh.toInt().coerceAtLeast(1))
                                )
                                if (sigActive) {
                                    drawRect(
                                        color = if (k == selSig) Color(0xFF2196F3) else Color(0x882196F3),
                                        topLeft = Offset(sl, st),
                                        size = androidx.compose.ui.geometry.Size(sw, sh),
                                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Hold-to-compare Floating Pill
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                isHoldingCompare = event.changes.any { it.pressed }
                            }
                        }
                    }
                    .testTag("hold_to_compare_btn"),
                color = if (isHoldingCompare) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.6f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Compare,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isHoldingCompare) I18n.get("showing_original", lang) else I18n.get("hold_to_compare", lang),
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
    }

    // Signature pad: big drawing area, pen width and colour; the result becomes a layer on the page
    if (showSignatureDialog) {
        SignaturePadDialog(
            lang = lang,
            savedDir = signatureDir,
            onDismiss = { showSignatureDialog = false },
            onDone = { bmp ->
                showSignatureDialog = false
                // each new signature is added as its own layer (slightly offset so they do not overlap)
                val n = sigLayers.size
                sigLayers.add(SigLayer(bmp, left = (0.58f - 0.06f * n).coerceAtLeast(0.02f), top = (0.8f - 0.07f * n).coerceAtLeast(0.05f), width = 0.35f))
                selSig = sigLayers.size - 1
                isWhitenMode = false
                activeTab = 3
            }
        )
    }
}

/** One signature placed on the page: position and width are fractions of the picture. */
private data class SigLayer(val bmp: Bitmap, val left: Float, val top: Float, val width: Float)

@Composable
private fun SignaturePadDialog(
    lang: com.example.i18n.Language,
    savedDir: File,
    onDismiss: () -> Unit,
    onDone: (Bitmap) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var penWidth by remember { mutableStateOf(5f) } // dp
    var penColor by remember { mutableStateOf(android.graphics.Color.BLACK) }
    var saveForLater by remember { mutableStateOf(true) }
    val saved = remember { mutableStateListOf<Pair<File, Bitmap>>() }
    var toDelete by remember { mutableStateOf<File?>(null) }
    val density = androidx.compose.ui.platform.LocalDensity.current

    suspend fun reload() {
        val list = withContext(Dispatchers.IO) {
            (savedDir.listFiles { f -> f.name.endsWith(".png") } ?: emptyArray())
                .sortedByDescending { it.lastModified() }
                .mapNotNull { f -> android.graphics.BitmapFactory.decodeFile(f.absolutePath)?.let { f to it } }
        }
        saved.clear(); saved.addAll(list)
    }
    LaunchedEffect(savedDir) { reload() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Top bar: close, title, done
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = I18n.get("cancel", lang)) }
                    Text(
                        I18n.get("signature_tool", lang),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        enabled = strokes.isNotEmpty(),
                        onClick = {
                            val wPx = with(density) { penWidth.dp.toPx() }
                            val bmp = renderSignature(strokes.toList(), wPx, penColor) ?: return@Button
                            if (saveForLater) {
                                coroutineScope.launch(Dispatchers.IO) {
                                    try {
                                        val f = File(savedDir, "sig_${System.currentTimeMillis()}.png")
                                        java.io.FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                                    } catch (e: Throwable) { e.printStackTrace() }
                                }
                            }
                            onDone(bmp)
                        },
                        modifier = Modifier.testTag("signature_done_btn")
                    ) { Text(I18n.get("done", lang)) }
                }

                // Saved signatures: tap one to put it on the page
                if (saved.isNotEmpty()) {
                    Text(I18n.get("saved_signatures", lang), style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        saved.forEach { (file, bmp) ->
                            Box(
                                modifier = Modifier
                                    .size(width = 120.dp, height = 64.dp)
                                    .background(Color.White, RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                    .clickable { onDone(bmp) }
                                    .testTag("saved_signature_item")
                            ) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize().padding(6.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .size(22.dp)
                                        .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                                        .clickable { toDelete = file },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = I18n.get("delete", lang), tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                    Text(I18n.get("or_draw_new", lang), style = MaterialTheme.typography.labelLarge)
                }

                // Big drawing pad: takes all the free space
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Color.White, RoundedCornerShape(10.dp))
                        .border(1.dp, Color.Gray, RoundedCornerShape(10.dp))
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { current = listOf(it) },
                                onDragEnd = { if (current.isNotEmpty()) strokes.add(current); current = emptyList() },
                                onDragCancel = { current = emptyList() }
                            ) { change, _ ->
                                change.consume()
                                current = current + change.position
                            }
                        }
                ) {
                    // signing line
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val y = size.height * 0.72f
                        drawLine(Color(0xFFCBD5E1), Offset(size.width * 0.06f, y), Offset(size.width * 0.94f, y), strokeWidth = 2.dp.toPx())
                    }
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val wPx = with(density) { penWidth.dp.toPx() }
                        for (st in strokes.toList() + listOf(current)) {
                            if (st.size == 1) drawCircle(Color(penColor), wPx / 2f, st[0])
                            for (q in 0 until st.size - 1) {
                                drawLine(Color(penColor), st[q], st[q + 1], strokeWidth = wPx, cap = StrokeCap.Round)
                            }
                        }
                    }
                    if (strokes.isEmpty() && current.isEmpty()) {
                        Text(
                            I18n.get("sign_here", lang),
                            color = Color.LightGray,
                            style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }

                // Pen settings
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(I18n.get("pen_width", lang), style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(80.dp))
                    Slider(value = penWidth, onValueChange = { penWidth = it }, valueRange = 1.5f..14f, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf(android.graphics.Color.BLACK, 0xFF1E3A8A.toInt(), 0xFFDC2626.toInt()).forEach { c ->
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .border(if (penColor == c) 3.dp else 1.dp, if (penColor == c) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                                .clickable { penColor = c }
                        )
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1) }, enabled = strokes.isNotEmpty()) {
                        Icon(Icons.Default.Undo, contentDescription = I18n.get("undo", lang))
                    }
                    TextButton(onClick = { strokes.clear() }) { Text(I18n.get("clear_signature", lang)) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = saveForLater, onCheckedChange = { saveForLater = it })
                    Text(I18n.get("save_signature", lang), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(I18n.get("delete_signature_q", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        f.delete()
                        toDelete = null
                        coroutineScope.launch { reload() }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(I18n.get("delete", lang)) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text(I18n.get("cancel", lang)) } }
        )
    }
}

/** Turns the pad strokes into a tightly cropped, transparent, 3x-resolution picture (sharp when enlarged). */
private fun renderSignature(strokes: List<List<Offset>>, widthPx: Float, color: Int): Bitmap? {
    val pts = strokes.flatten()
    if (pts.isEmpty()) return null
    val pad = widthPx * 1.5f
    val minX = pts.minOf { it.x } - pad
    val minY = pts.minOf { it.y } - pad
    val maxX = pts.maxOf { it.x } + pad
    val maxY = pts.maxOf { it.y } + pad
    val scale = 3f
    val w = ((maxX - minX) * scale).toInt().coerceIn(1, 4000)
    val h = ((maxY - minY) * scale).toInt().coerceIn(1, 4000)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = widthPx * scale
        strokeCap = android.graphics.Paint.Cap.ROUND
        strokeJoin = android.graphics.Paint.Join.ROUND
    }
    for (st in strokes) {
        if (st.isEmpty()) continue
        val path = android.graphics.Path()
        path.moveTo((st[0].x - minX) * scale, (st[0].y - minY) * scale)
        if (st.size == 1) path.lineTo((st[0].x - minX) * scale + 0.1f, (st[0].y - minY) * scale)
        for (q in 1 until st.size) path.lineTo((st[q].x - minX) * scale, (st[q].y - minY) * scale)
        canvas.drawPath(path, paint)
    }
    return bmp
}
