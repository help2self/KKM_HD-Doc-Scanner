package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.core.content.FileProvider
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.PassportConfig
import com.example.data.model.PassportSheetPreset
import com.example.data.model.PassportSizePreset
import com.example.data.model.SizeUnit
import com.example.processing.GallerySaver
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PassportSheetScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val config by viewModel.passportConfig.collectAsState()

    var sourceBitmap by remember { mutableStateOf(viewModel.passportSourceBitmap) }
    var generatedSheetBitmap by remember { mutableStateOf(viewModel.passportGeneratedSheet) }
    var isGenerating by remember { mutableStateOf(false) }

    // Upright (EXIF-corrected) photo becomes the source of the sheet
    suspend fun useNewPhoto(file: File) {
        val bmp = ImageProcessor.importPhoto(file, previewEdge = 2000)
        if (bmp != null) {
            sourceBitmap = bmp
            viewModel.passportSourceBitmap = bmp
            viewModel.passportConfig.value = viewModel.passportConfig.value.copy(photoPath = file.absolutePath)
        }
    }

    val pickPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val file = File(context.filesDir, "passport_src_${UUID.randomUUID()}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    file.outputStream().use { output -> input.copyTo(output) }
                }
                useNewPhoto(file)
            }
        }
    }

    // Take a fresh photo with the phone camera
    var cameraFile by remember { mutableStateOf<File?>(null) }
    val takePhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val f = cameraFile
        if (success && f != null && f.exists()) {
            coroutineScope.launch { useNewPhoto(f) }
        }
    }
    fun launchCameraNow() {
        val f = File(context.filesDir, "passport_cam_${UUID.randomUUID()}.jpg")
        cameraFile = f
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
        takePhotoLauncher.launch(uri)
    }
    // The app declares CAMERA, so Android requires it to be granted before the camera app opens
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) launchCameraNow() }
    fun openCamera() {
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) launchCameraNow() else cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
    }
    fun openGallery() {
        pickPhotoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    fun triggerGenerateSheet() {
        val src = sourceBitmap ?: return
        isGenerating = true
        coroutineScope.launch {
            val sheet = ImageProcessor.renderPassportSheet(config, src)
            generatedSheetBitmap = sheet
            viewModel.passportGeneratedSheet = sheet
            isGenerating = false
        }
    }

    // Auto generate sheet when config or bitmap changes
    LaunchedEffect(config, sourceBitmap) {
        if (sourceBitmap != null) {
            triggerGenerateSheet()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("passport_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    if (generatedSheetBitmap != null) {
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    val targetDocId = UUID.randomUUID().toString()
                                    val timestamp = System.currentTimeMillis()
                                    val doc = com.example.data.local.DocumentEntity(
                                        id = targetDocId,
                                        name = "Passport Sheet " + I18n.defaultScanName(timestamp),
                                        createdAt = timestamp,
                                        updatedAt = timestamp
                                    )
                                    viewModel.repository.saveDocument(doc)

                                    val pageId = UUID.randomUUID().toString()
                                    val file = File(context.filesDir, "passport_${pageId}.jpg")
                                    val thumb = File(context.filesDir, "thumb_${pageId}.jpg")
                                    ImageProcessor.saveBitmapToFile(generatedSheetBitmap!!, file, dpi = config.dpi)
                                    val tBmp = Bitmap.createScaledBitmap(generatedSheetBitmap!!, 300, (300f * generatedSheetBitmap!!.height / generatedSheetBitmap!!.width).toInt(), true)
                                    ImageProcessor.saveBitmapToFile(tBmp, thumb, quality = 80)

                                    viewModel.repository.savePage(
                                        com.example.data.local.PageEntity(
                                            id = pageId,
                                            documentId = targetDocId,
                                            pageOrder = 0,
                                            pageType = "scan",
                                            originalImagePath = file.absolutePath,
                                            thumbnailImagePath = thumb.absolutePath
                                        )
                                    )
                                    viewModel.refreshStorageInfo()
                                    viewModel.activeDocumentId.value = targetDocId
                                    viewModel.navigateTo(Screen.DocumentDetail)
                                }
                            },
                            modifier = Modifier.testTag("save_passport_doc_btn")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save Document")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mandatory Disclaimer Label
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = I18n.get("passport_disclaimer", lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Photo Selector / Capture
            if (sourceBitmap == null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("passport_photo_picker_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddAPhoto,
                            contentDescription = null,
                            modifier = Modifier.size(44.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = I18n.get("select_photo", lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { openCamera() },
                                modifier = Modifier.weight(1f).height(52.dp).testTag("passport_camera_btn")
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(I18n.get("take_photo", lang))
                            }
                            OutlinedButton(
                                onClick = { openGallery() },
                                modifier = Modifier.weight(1f).height(52.dp).testTag("passport_gallery_btn")
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(I18n.get("from_gallery", lang))
                            }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        bitmap = sourceBitmap!!.asImageBitmap(),
                        contentDescription = "Selected Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(70.dp, 90.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = I18n.get("photo_selected", lang),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                            OutlinedButton(onClick = { openCamera() }) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(I18n.get("take_photo", lang), style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(onClick = { openGallery() }) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(I18n.get("from_gallery", lang), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            // Photo size: one dropdown (+ custom size in in / cm / px)
            SizeDropdownBlock(
                title = I18n.get("photo_size", lang),
                lang = lang,
                dpi = config.dpi,
                unit = config.photoUnit,
                widthMm = config.customPhotoWidthMm,
                heightMm = config.customPhotoHeightMm,
                isCustom = config.photoPreset == PassportSizePreset.CUSTOM,
                options = PassportSizePreset.values().filter { it != PassportSizePreset.CUSTOM }
                    .map { Triple(I18n.get(it.labelKey, lang), it.widthMm, it.heightMm) },
                selectedLabel = if (config.photoPreset == PassportSizePreset.CUSTOM) null
                    else I18n.get(config.photoPreset.labelKey, lang),
                onPick = { _, w, h ->
                    val preset = PassportSizePreset.values().firstOrNull { it != PassportSizePreset.CUSTOM && it.widthMm == w && it.heightMm == h }
                        ?: PassportSizePreset.CUSTOM
                    viewModel.passportConfig.value = config.copy(photoPreset = preset, customPhotoWidthMm = w, customPhotoHeightMm = h)
                },
                onCustom = { viewModel.passportConfig.value = config.copy(photoPreset = PassportSizePreset.CUSTOM) },
                onUnit = { viewModel.passportConfig.value = config.copy(photoUnit = it) },
                onSize = { w, h -> viewModel.passportConfig.value = config.copy(photoPreset = PassportSizePreset.CUSTOM, customPhotoWidthMm = w, customPhotoHeightMm = h) },
                tag = "photo_size"
            )

            // Sheet size: one dropdown (+ custom size in in / cm / px)
            SizeDropdownBlock(
                title = I18n.get("sheet_size", lang),
                lang = lang,
                dpi = config.dpi,
                unit = config.sheetUnit,
                widthMm = config.customSheetWidthMm,
                heightMm = config.customSheetHeightMm,
                isCustom = config.sheetPreset == PassportSheetPreset.SHEET_CUSTOM,
                options = PassportSheetPreset.values().filter { it != PassportSheetPreset.SHEET_CUSTOM }
                    .map { Triple(I18n.get(it.labelKey, lang), it.widthMm, it.heightMm) },
                selectedLabel = if (config.sheetPreset == PassportSheetPreset.SHEET_CUSTOM) null
                    else I18n.get(config.sheetPreset.labelKey, lang),
                onPick = { _, w, h ->
                    val preset = PassportSheetPreset.values().firstOrNull { it != PassportSheetPreset.SHEET_CUSTOM && it.widthMm == w && it.heightMm == h }
                        ?: PassportSheetPreset.SHEET_CUSTOM
                    viewModel.passportConfig.value = config.copy(sheetPreset = preset, customSheetWidthMm = w, customSheetHeightMm = h)
                },
                onCustom = { viewModel.passportConfig.value = config.copy(sheetPreset = PassportSheetPreset.SHEET_CUSTOM) },
                onUnit = { viewModel.passportConfig.value = config.copy(sheetUnit = it) },
                onSize = { w, h -> viewModel.passportConfig.value = config.copy(sheetPreset = PassportSheetPreset.SHEET_CUSTOM, customSheetWidthMm = w, customSheetHeightMm = h) },
                tag = "sheet_size"
            )

            // DPI: a real setting that changes the sheet's pixel size AND is written into the file
            DpiBlock(
                lang = lang,
                dpi = config.dpi,
                sheetWidthMm = config.customSheetWidthMm,
                sheetHeightMm = config.customSheetHeightMm,
                onDpi = { viewModel.passportConfig.value = config.copy(dpi = it) }
            )

            // Copies Options: Fit maximum or Custom count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = I18n.get("copies_count", lang),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = config.isFitMaximum,
                        onCheckedChange = { viewModel.passportConfig.value = config.copy(isFitMaximum = it) },
                        modifier = Modifier.testTag("fit_maximum_checkbox")
                    )
                    Text(I18n.get("fit_maximum", lang), style = MaterialTheme.typography.bodySmall)
                }
            }

            // Cut Guidelines Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(I18n.get("cut_guidelines", lang), style = MaterialTheme.typography.bodyMedium)
                Switch(
                    checked = config.showCutLines,
                    onCheckedChange = { viewModel.passportConfig.value = config.copy(showCutLines = it) },
                    modifier = Modifier.testTag("cut_guidelines_switch")
                )
            }

            // Generated sheet live preview
            if (generatedSheetBitmap != null) {
                Text(
                    text = "Live Sheet Preview (${config.dpi} DPI · ${generatedSheetBitmap!!.width} x ${generatedSheetBitmap!!.height} px)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(config.customSheetWidthMm / config.customSheetHeightMm)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = generatedSheetBitmap!!.asImageBitmap(),
                        contentDescription = "Generated Passport Sheet",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
                var saveMsg by remember { mutableStateOf<String?>(null) }
                Text(I18n.get("save_as_image", lang), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("JPEG" to false, "PNG" to true).forEach { (label, png) ->
                        OutlinedButton(
                            modifier = Modifier.weight(1f),
                            onClick = {
                                val bmp = generatedSheetBitmap ?: return@OutlinedButton
                                coroutineScope.launch {
                                    val ext = if (png) "png" else "jpg"
                                    val f = File(context.cacheDir, "passport_sheet_${config.dpi}dpi.$ext")
                                    ImageProcessor.saveBitmapToFile(
                                        bmp, f,
                                        format = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                                        quality = 100, dpi = config.dpi
                                    )
                                    saveMsg = GallerySaver.save(context, f, f.name, if (png) "image/png" else "image/jpeg")
                                }
                            }
                        ) { Text(label) }
                    }
                }
                saveMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
            }
        }
    }
}

private fun mmTo(v: Float, unit: SizeUnit, dpi: Int): Float = when (unit) {
    SizeUnit.CM -> v / 10f
    SizeUnit.IN -> v / 25.4f
    SizeUnit.PX -> v / 25.4f * dpi
}

private fun toMm(v: Float, unit: SizeUnit, dpi: Int): Float = when (unit) {
    SizeUnit.CM -> v * 10f
    SizeUnit.IN -> v * 25.4f
    SizeUnit.PX -> v / dpi * 25.4f
}

private fun fmt(v: Float, unit: SizeUnit): String =
    if (unit == SizeUnit.PX) v.toInt().toString()
    else String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

/** Dropdown list of ready sizes plus "Custom", which reveals width / height fields with a unit chooser. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SizeDropdownBlock(
    title: String,
    lang: com.example.i18n.Language,
    dpi: Int,
    unit: SizeUnit,
    widthMm: Float,
    heightMm: Float,
    isCustom: Boolean,
    options: List<Triple<String, Float, Float>>,
    selectedLabel: String?,
    onPick: (String, Float, Float) -> Unit,
    onCustom: () -> Unit,
    onUnit: (SizeUnit) -> Unit,
    onSize: (Float, Float) -> Unit,
    tag: String
) {
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(
                value = selectedLabel ?: I18n.get("custom_size", lang),
                onValueChange = {},
                readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth().testTag("${tag}_dropdown")
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { (label, w, h) ->
                    DropdownMenuItem(text = { Text(label) }, onClick = { expanded = false; onPick(label, w, h) })
                }
                DropdownMenuItem(
                    text = { Text(I18n.get("custom_size", lang)) },
                    onClick = { expanded = false; onCustom() }
                )
            }
        }
        if (isCustom) {
            var wText by remember(unit, isCustom) { mutableStateOf(fmt(mmTo(widthMm, unit, dpi), unit)) }
            var hText by remember(unit, isCustom) { mutableStateOf(fmt(mmTo(heightMm, unit, dpi), unit)) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = wText,
                    onValueChange = { t ->
                        wText = t
                        val v = t.toFloatOrNull()
                        val hv = hText.toFloatOrNull()
                        if (v != null && v > 0f && hv != null && hv > 0f) onSize(toMm(v, unit, dpi), toMm(hv, unit, dpi))
                    },
                    label = { Text(I18n.get("width_label", lang)) },
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                    modifier = Modifier.weight(1f).testTag("${tag}_w")
                )
                OutlinedTextField(
                    value = hText,
                    onValueChange = { t ->
                        hText = t
                        val v = t.toFloatOrNull()
                        val wv = wText.toFloatOrNull()
                        if (v != null && v > 0f && wv != null && wv > 0f) onSize(toMm(wv, unit, dpi), toMm(v, unit, dpi))
                    },
                    label = { Text(I18n.get("height_label", lang)) },
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                    modifier = Modifier.weight(1f).testTag("${tag}_h")
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SizeUnit.values().forEach { u ->
                    FilterChip(selected = unit == u, onClick = { onUnit(u) }, label = { Text(u.label) })
                }
            }
        }
    }
}

@Composable
private fun DpiBlock(lang: com.example.i18n.Language, dpi: Int, sheetWidthMm: Float, sheetHeightMm: Float, onDpi: (Int) -> Unit) {
    // Keep the sheet below ~24 megapixels so the phone never runs out of memory
    val maxDpi = kotlin.math.sqrt(24_000_000.0 / ((sheetWidthMm / 25.4) * (sheetHeightMm / 25.4))).toInt().coerceIn(72, 1200)
    var text by remember(dpi) { mutableStateOf(dpi.toString()) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(I18n.get("dpi_title", lang), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(72, 96, 150, 200, 300, 600).filter { it <= maxDpi }.forEach { v ->
                FilterChip(selected = dpi == v, onClick = { onDpi(v) }, label = { Text("$v") })
            }
        }
        OutlinedTextField(
            value = text,
            onValueChange = { t ->
                text = t.filter { it.isDigit() }.take(4)
                val v = text.toIntOrNull()
                if (v != null && v in 72..maxDpi) onDpi(v)
            },
            label = { Text("DPI (72 – $maxDpi)") },
            singleLine = true,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("dpi_field")
        )
        Text(I18n.get("dpi_hint", lang), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
