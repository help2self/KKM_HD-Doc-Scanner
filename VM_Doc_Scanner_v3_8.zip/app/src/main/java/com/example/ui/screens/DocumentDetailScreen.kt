package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import com.example.processing.GallerySaver
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.PageEntity
import com.example.i18n.I18n
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun DocumentDetailScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    // Select mode: pick any pages (custom order of taps) and save / share / export / delete only those
    var selectionMode by remember { mutableStateOf(false) }
    val selectedIds = remember { mutableStateListOf<String>() }
    var isWorking by remember { mutableStateOf(false) }
    var showDeleteSelectedDialog by remember { mutableStateOf(false) }

    BackHandler {
        if (selectionMode) { selectionMode = false; selectedIds.clear() } else viewModel.navigateBack()
    }

    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val activeDocId by viewModel.activeDocumentId.collectAsState()
    val docs by viewModel.allDocuments.collectAsState()
    val pages by viewModel.activeDocumentPages.collectAsState()
    val folders by viewModel.allFolders.collectAsState()
    val tags by viewModel.allTags.collectAsState()

    val currentDoc = docs.find { it.id == activeDocId }

    var isEditingName by remember { mutableStateOf(false) }
    var editedName by remember { mutableStateOf("") }

    var isEditingNotes by remember { mutableStateOf(false) }
    var notesText by remember { mutableStateOf(currentDoc?.notes ?: "") }

    var showFolderDialog by remember { mutableStateOf(false) }
    var showTagDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var pageToDelete by remember { mutableStateOf<PageEntity?>(null) }

    LaunchedEffect(currentDoc) {
        if (currentDoc != null) {
            notesText = currentDoc.notes
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            if (selectionMode) {
                TopAppBar(
                    title = { Text(I18n.get("n_selected", lang, selectedIds.size), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { selectionMode = false; selectedIds.clear() }) {
                            Icon(Icons.Default.Close, contentDescription = I18n.get("cancel", lang))
                        }
                    },
                    actions = {
                        TextButton(onClick = {
                            if (selectedIds.size == pages.size) selectedIds.clear()
                            else { selectedIds.clear(); selectedIds.addAll(pages.map { it.id }) }
                        }) {
                            Text(I18n.get(if (selectedIds.size == pages.size && pages.isNotEmpty()) "deselect_all" else "select_all", lang))
                        }
                    }
                )
            } else
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            editedName = currentDoc?.name ?: ""
                            isEditingName = true
                        }
                    ) {
                        Text(
                            text = currentDoc?.name ?: I18n.get("document_view", lang),
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            modifier = Modifier.testTag("doc_title_text")
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Rename",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    IconButton(onClick = { selectionMode = true; selectedIds.clear() }, modifier = Modifier.testTag("select_pages_btn")) {
                        Icon(imageVector = Icons.Default.Checklist, contentDescription = I18n.get("select_pages", lang))
                    }
                    IconButton(onClick = { viewModel.navigateTo(Screen.PrintView) }) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = I18n.get("print", lang))
                    }
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.Export) },
                        modifier = Modifier.testTag("export_doc_top_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = I18n.get("export", lang))
                    }
                    IconButton(onClick = { showDeleteConfirmDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = I18n.get("delete", lang),
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                if (selectionMode) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        val chosen = pages.filter { it.id in selectedIds }
                            .sortedBy { selectedIds.indexOf(it.id) }
                        val enabled = chosen.isNotEmpty() && !isWorking
                        DetailAction(Icons.Default.Image, I18n.get("save_to_gallery", lang), enabled) {
                            isWorking = true
                            coroutineScope.launch {
                                var ok = 0
                                val base = GallerySaver.safeName(currentDoc?.name ?: "scan")
                                chosen.forEachIndexed { i, pg ->
                                    try {
                                        val f = File(pg.originalImagePath)
                                        if (f.exists()) {
                                            GallerySaver.save(context, f, "${base}_${i + 1}_${System.currentTimeMillis() % 100000}.jpg", "image/jpeg")
                                            ok++
                                        }
                                    } catch (e: Exception) { e.printStackTrace() }
                                }
                                isWorking = false
                                Toast.makeText(
                                    context,
                                    I18n.get("saved_n_to_gallery", lang, ok) + "\n" + GallerySaver.describeLocation(context, false),
                                    Toast.LENGTH_LONG
                                ).show()
                                selectionMode = false
                                selectedIds.clear()
                            }
                        }
                        DetailAction(Icons.Default.Share, I18n.get("share_action", lang), enabled) {
                            val uris = ArrayList(chosen.mapNotNull { pg ->
                                val f = File(pg.originalImagePath)
                                if (f.exists()) FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f) else null
                            })
                            if (uris.isNotEmpty()) {
                                val intent = if (uris.size == 1) {
                                    Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris.first()) }
                                } else {
                                    Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
                                }.apply {
                                    type = "image/jpeg"
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, I18n.get("share_action", lang)))
                            }
                        }
                        DetailAction(Icons.Default.PictureAsPdf, I18n.get("export", lang), enabled) {
                            viewModel.selectedExportPageIds.value = chosen.map { it.id }.toSet()
                            selectionMode = false
                            selectedIds.clear()
                            viewModel.navigateTo(Screen.Export)
                        }
                        DetailAction(Icons.Default.Delete, I18n.get("delete", lang), enabled) {
                            showDeleteSelectedDialog = true
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        DetailAction(Icons.Default.AddAPhoto, I18n.get("add_pages", lang), true) {
                            activeDocId?.let { viewModel.startAddPagesTo(it) }
                        }
                        DetailAction(Icons.Default.Checklist, I18n.get("select_pages", lang), pages.isNotEmpty()) {
                            selectionMode = true
                            selectedIds.clear()
                        }
                        DetailAction(Icons.Default.Share, I18n.get("export", lang), pages.isNotEmpty()) {
                            viewModel.navigateTo(Screen.Export)
                        }
                        DetailAction(Icons.Default.Print, I18n.get("print", lang), pages.isNotEmpty()) {
                            viewModel.navigateTo(Screen.PrintView)
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Folder and Tag Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val currentFolder = folders.find { it.id == currentDoc?.folderId }
                AssistChip(
                    onClick = { showFolderDialog = true },
                    label = { Text(currentFolder?.name ?: I18n.get("folder", lang)) },
                    leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("folder_chip")
                )

                AssistChip(
                    onClick = { showTagDialog = true },
                    label = { Text(I18n.get("tags", lang)) },
                    leadingIcon = { Icon(Icons.Default.Label, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("tag_chip")
                )

                Text(
                    text = I18n.get("pages_count", lang, pages.size),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            // Grid of Pages
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 140.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(pages, key = { _, page -> page.id }) { index, page ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.72f)
                            .combinedClickable(
                                onClick = {
                                    if (selectionMode) {
                                        if (page.id in selectedIds) selectedIds.remove(page.id) else selectedIds.add(page.id)
                                    } else {
                                        viewModel.activeEditingPage.value = page
                                        viewModel.navigateTo(Screen.PageEditor)
                                    }
                                },
                                onLongClick = {
                                    if (!selectionMode) { selectionMode = true; selectedIds.clear() }
                                    if (page.id !in selectedIds) selectedIds.add(page.id)
                                }
                            )
                            .testTag("page_card_$index"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            val imgFile = File(if (page.thumbnailImagePath.isNotBlank()) page.thumbnailImagePath else page.originalImagePath)
                            AsyncImage(
                                model = imgFile,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Page number badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(bottomEnd = 8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }

                            if (selectionMode) {
                                val pos = selectedIds.indexOf(page.id)
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .background(if (pos >= 0) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else Color.Transparent)
                                        .border(if (pos >= 0) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .size(26.dp)
                                        .background(if (pos >= 0) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.8f), RoundedCornerShape(13.dp))
                                        .border(1.dp, Color.Gray, RoundedCornerShape(13.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (pos >= 0) Text("${pos + 1}", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                }
                            } else
                            // Duplicate & Delete Actions
                            Row(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(topStart = 8.dp))
                                    .padding(2.dp)
                            ) {
                                IconButton(
                                    onClick = { viewModel.duplicatePage(page) },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = I18n.get("duplicate_page", lang),
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { pageToDelete = page },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = I18n.get("delete", lang),
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                if (!selectionMode) {
                    item(key = "add_tile") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(0.72f)
                                .clip(RoundedCornerShape(12.dp))
                                .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                                .clickable { activeDocId?.let { viewModel.startAddPagesTo(it) } }
                                .testTag("add_pages_tile"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.AddAPhoto, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(I18n.get("tap_add_pages", lang), color = MaterialTheme.colorScheme.outline, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete selected pages
    if (showDeleteSelectedDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteSelectedDialog = false },
            title = { Text(I18n.get("delete_page_title", lang)) },
            text = { Text(I18n.get("delete_selected_confirm", lang, selectedIds.size)) },
            confirmButton = {
                Button(
                    onClick = {
                        pages.filter { it.id in selectedIds }.forEach { viewModel.deletePage(it) }
                        selectedIds.clear()
                        selectionMode = false
                        showDeleteSelectedDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(I18n.get("delete", lang)) }
            },
            dismissButton = { TextButton(onClick = { showDeleteSelectedDialog = false }) { Text(I18n.get("cancel", lang)) } }
        )
    }

    // Rename Dialog
    if (isEditingName) {
        AlertDialog(
            onDismissRequest = { isEditingName = false },
            title = { Text(I18n.get("rename", lang)) },
            text = {
                OutlinedTextField(
                    value = editedName,
                    onValueChange = { editedName = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("rename_input")
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (editedName.isNotBlank() && activeDocId != null) {
                        viewModel.renameDocument(activeDocId!!, editedName)
                        isEditingName = false
                    }
                }) {
                    Text(I18n.get("save", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { isEditingName = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Delete single page confirmation
    pageToDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { pageToDelete = null },
            title = { Text(I18n.get("delete_page_title", lang)) },
            text = { Text(I18n.get("delete_page_confirm", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePage(p)
                        pageToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(I18n.get("delete", lang)) }
            },
            dismissButton = {
                TextButton(onClick = { pageToDelete = null }) { Text(I18n.get("cancel", lang)) }
            }
        )
    }

    // Delete Confirm Dialog
    if (showDeleteConfirmDialog && currentDoc != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text(I18n.get("delete_doc", lang)) },
            text = { Text(I18n.get("confirm_delete_doc", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        viewModel.deleteDocument(currentDoc)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(I18n.get("delete", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Folder Selector Dialog
    if (showFolderDialog && currentDoc != null) {
        AlertDialog(
            onDismissRequest = { showFolderDialog = false },
            title = { Text(I18n.get("folder", lang)) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text(I18n.get("no_folder", lang)) },
                        modifier = Modifier.clickable {
                            viewModel.setDocumentFolder(currentDoc.id, null)
                            showFolderDialog = false
                        }
                    )
                    folders.forEach { f ->
                        ListItem(
                            headlineContent = { Text(f.name) },
                            modifier = Modifier.clickable {
                                viewModel.setDocumentFolder(currentDoc.id, f.id)
                                showFolderDialog = false
                            }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFolderDialog = false }) {
                    Text(I18n.get("done", lang))
                }
            }
        )
    }

    // Tag Selector Dialog
    if (showTagDialog && currentDoc != null) {
        AlertDialog(
            onDismissRequest = { showTagDialog = false },
            title = { Text(I18n.get("tags", lang)) },
            text = {
                Column {
                    tags.forEach { t ->
                        val hasTag = try {
                            val arr = JSONArray(currentDoc.tagIdsJson)
                            var found = false
                            for (i in 0 until arr.length()) {
                                if (arr.optString(i) == t.id) { found = true; break }
                            }
                            found
                        } catch (e: Exception) { false }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.toggleDocumentTag(currentDoc.id, t.id) }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(checked = hasTag, onCheckedChange = { viewModel.toggleDocumentTag(currentDoc.id, t.id) })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("#${t.name}")
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showTagDialog = false }) {
                    Text(I18n.get("done", lang))
                }
            }
        )
    }
}

@Composable
private fun DetailAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val tint = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, color = tint, style = MaterialTheme.typography.labelSmall)
    }
}
