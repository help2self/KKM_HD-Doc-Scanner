package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EditParameters
import com.example.data.model.FilterType
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.Screen
import com.example.ui.viewmodel.BatchCaptureItem
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch

/**
 * Filter screen for a freshly scanned batch (OKEN style): the cropped + filtered page large in a pager,
 * a strip of filter thumbnails, "apply to all pages", and Retake / Add / Rotate / Crop / Delete.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatchReviewScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }

    val lang by viewModel.language.collectAsState()
    val batchItems by viewModel.batchItems.collectAsState()
    val appendTarget by viewModel.appendTargetDocId.collectAsState()
    val docs by viewModel.allDocuments.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var docName by remember { mutableStateOf(I18n.defaultScanName(System.currentTimeMillis())) }
    var applyToAll by remember { mutableStateOf(true) }
    var isSaving by remember { mutableStateOf(false) }

    val pagerState = rememberPagerState(pageCount = { batchItems.size })
    val currentItem = batchItems.getOrNull(pagerState.currentPage)

    // Cache of cropped (warped) previews per page + corners, so changing a filter is quick
    val warpCache = remember { mutableStateMapOf<String, Bitmap>() }
    fun warpKey(item: BatchCaptureItem) = item.id + "|" + item.corners.hashCode() + "|" + item.previewBitmap.hashCode()

    suspend fun warped(item: BatchCaptureItem): Bitmap {
        val k = warpKey(item)
        warpCache[k]?.let { return it }
        val w = ImageProcessor.warpPerspective(item.previewBitmap, item.corners, maxEdge = 1400)
        warpCache[k] = w
        return w
    }

    // Thumbnails of every filter for the current page
    val filters = listOf(
        FilterType.REMOVE_SHADOW to "filter_remove_shadow",
        FilterType.ORIGINAL to "filter_original",
        FilterType.LIGHTEN to "filter_lighten",
        FilterType.MAGIC_COLOR to "filter_magic_color",
        FilterType.GRAYSCALE to "filter_grayscale",
        FilterType.DOCUMENT_BW to "filter_doc_bw",
        FilterType.BW2 to "filter_bw2"
    )
    val filterThumbs = remember { mutableStateMapOf<FilterType, Bitmap>() }
    LaunchedEffect(currentItem?.let { warpKey(it) }) {
        filterThumbs.clear()
        val item = currentItem ?: return@LaunchedEffect
        val small = ImageProcessor.downscale(warped(item), 200)
        for ((f, _) in filters) {
            filterThumbs[f] = ImageProcessor.applyFiltersAndEdits(small, f, EditParameters())
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFF1E1E1E),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White),
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang), tint = Color.White)
                    }
                },
                title = {
                    if (appendTarget != null) {
                        Text(
                            docs.find { it.id == appendTarget }?.name ?: "",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = Color.White
                        )
                    } else {
                        BasicTextField(
                            value = docName,
                            onValueChange = { docName = it },
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                            cursorBrush = SolidColor(Color.White),
                            modifier = Modifier.fillMaxWidth().testTag("batch_doc_name_input")
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            if (isSaving) return@Button
                            isSaving = true
                            viewModel.finishBatch(docName) { docId ->
                                isSaving = false
                                viewModel.showDocumentAfterSave(docId)
                            }
                        },
                        enabled = batchItems.isNotEmpty() && !isSaving,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F9D58)),
                        modifier = Modifier.padding(end = 8.dp).testTag("finish_batch_btn")
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text(I18n.get("done", lang))
                        }
                    }
                }
            )
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth().background(Color.Black).navigationBarsPadding()) {
                // Apply to all pages
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { applyToAll = !applyToAll }
                        .height(34.dp)
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(I18n.get("apply_all_pages", lang), color = Color.White, style = MaterialTheme.typography.bodySmall)
                    Checkbox(checked = applyToAll, onCheckedChange = { applyToAll = it })
                }
                // Filter strip with real previews
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    filters.forEach { (f, key) ->
                        val selected = currentItem?.filter == f
                        Box(
                            modifier = Modifier
                                .size(width = 60.dp, height = 54.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .border(if (selected) 3.dp else 0.dp, if (selected) Color(0xFF0F9D58) else Color.Transparent, RoundedCornerShape(4.dp))
                                .background(Color.DarkGray)
                                .clickable {
                                    val item = currentItem ?: return@clickable
                                    if (applyToAll) viewModel.setFilterForAllBatchItems(f)
                                    else viewModel.setFilterForBatchItem(item.id, f)
                                }
                        ) {
                            filterThumbs[f]?.let {
                                Image(
                                    bitmap = it.asImageBitmap(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Text(
                                I18n.get(key, lang),
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .background(if (selected) Color(0xFF0F9D58) else Color.Black.copy(alpha = 0.55f))
                                    .padding(horizontal = 2.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    BatchAction(Icons.Default.Replay, I18n.get("retake", lang)) {
                        currentItem?.let { viewModel.removeBatchItem(it.id) }
                        viewModel.navigateBack()
                    }
                    BatchAction(Icons.Default.AddAPhoto, I18n.get("add", lang)) {
                        viewModel.navigateBack()
                    }
                    BatchAction(Icons.Default.RotateLeft, I18n.get("rotate_left", lang)) {
                        currentItem?.let { viewModel.rotateBatchItemLeft(it) }
                    }
                    BatchAction(Icons.Default.Crop, I18n.get("crop", lang)) {
                        currentItem?.let { viewModel.editBatchItemCorners(it) }
                    }
                    BatchAction(Icons.Default.Delete, I18n.get("delete", lang)) {
                        currentItem?.let { viewModel.removeBatchItem(it.id) }
                    }
                }
            }
        }
    ) { padding ->
        if (batchItems.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(I18n.get("no_scans_yet", lang), color = Color.LightGray)
            }
            return@Scaffold
        }
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 24.dp),
                pageSpacing = 12.dp,
                key = { idx -> batchItems.getOrNull(idx)?.id ?: idx }
            ) { idx ->
                val item = batchItems.getOrNull(idx) ?: return@HorizontalPager
                var shown by remember { mutableStateOf<Bitmap?>(null) }
                LaunchedEffect(warpKey(item), item.filter) {
                    val w = warped(item)
                    shown = ImageProcessor.applyFiltersAndEdits(w, item.filter, EditParameters())
                }
                Box(Modifier.fillMaxSize().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                    val b = shown
                    if (b != null) {
                        Image(
                            bitmap = b.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        CircularProgressIndicator(color = Color.White)
                    }
                }
            }
            // 1/2 pager control
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { coroutineScope.launch { pagerState.animateScrollToPage((pagerState.currentPage - 1).coerceAtLeast(0)) } },
                    enabled = pagerState.currentPage > 0,
                    modifier = Modifier.size(36.dp).background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) { Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Color.White) }
                Text(
                    "${pagerState.currentPage + 1}/${batchItems.size}",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                IconButton(
                    onClick = { coroutineScope.launch { pagerState.animateScrollToPage((pagerState.currentPage + 1).coerceAtMost(batchItems.size - 1)) } },
                    enabled = pagerState.currentPage < batchItems.size - 1,
                    modifier = Modifier.size(36.dp).background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.White) }
            }
        }
    }
}

@Composable
private fun BatchAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(22.dp))
        Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}
