package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.Screen
import com.example.ui.components.CameraPreview
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

@Composable
fun CameraCaptureScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()

    val batchItems by viewModel.batchItems.collectAsState()
    var isFlashOn by remember { mutableStateOf(false) }
    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var cameraControl: CameraControl? by remember { mutableStateOf(null) }

    var showLeaveConfirmDialog by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }

    // Intercept back button if batch has unsaved items
    BackHandler {
        if (batchItems.isNotEmpty()) {
            showLeaveConfirmDialog = true
        } else {
            viewModel.navigateBack()
        }
    }

    // Batch only: every photo goes into the batch; the count + last photo show on this screen
    val scanMode = 1
    val appendTarget by viewModel.appendTargetDocId.collectAsState()

    // Phone Camera App fallback launcher
    var photoUri: Uri? by remember { mutableStateOf(null) }
    var photoFile: File? by remember { mutableStateOf(null) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val f = photoFile
        if (success && f != null && f.exists()) {
            coroutineScope.launch {
                // Applies the photo's EXIF rotation so the page is upright
                val bmp = ImageProcessor.importPhoto(f)
                if (bmp != null) viewModel.addCapturedImage(f, bmp)
            }
        }
    }

    // Gallery Multi-import
    val pickMultipleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                if (false) {
                    val uri = uris.first()
                    val file = File(context.filesDir, "import_${UUID.randomUUID()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        file.outputStream().use { output -> input.copyTo(output) }
                    }
                    val bmp = ImageProcessor.importPhoto(file)
                    if (bmp != null) {
                        viewModel.startSingleCapture(file, bmp)
                    }
                } else {
                    for (uri in uris) {
                        val file = File(context.filesDir, "import_${UUID.randomUUID()}.jpg")
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            file.outputStream().use { output -> input.copyTo(output) }
                        }
                        val bmp = ImageProcessor.importPhoto(file)
                        if (bmp != null) {
                            viewModel.addCapturedImage(file, bmp)
                        }
                    }
                }
            }
        }
    }

    // Top bar | camera picture (exact 4:3, never stretched or cropped) | controls
    Column(modifier = modifier.fillMaxSize().background(Color.Black)) {
        // Top Controls Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (batchItems.isNotEmpty()) {
                        showLeaveConfirmDialog = true
                    } else {
                        viewModel.navigateBack()
                    }
                },
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .testTag("camera_back_btn")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang), tint = Color.White)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Flash toggle
                IconButton(
                    onClick = {
                        isFlashOn = !isFlashOn
                        cameraControl?.enableTorch(isFlashOn)
                    },
                    modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flash",
                        tint = if (isFlashOn) Color.Yellow else Color.White
                    )
                }

                // Switch Camera
                IconButton(
                    onClick = {
                        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                            CameraSelector.LENS_FACING_FRONT
                        } else {
                            CameraSelector.LENS_FACING_BACK
                        }
                    },
                    modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(Icons.Default.FlipCameraAndroid, contentDescription = I18n.get("switch_cam", lang), tint = Color.White)
                }
            }
        }

        // Real-Time CameraX Viewfinder with Optical Document Alignment Frame
        CameraPreview(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            lensFacing = lensFacing,
            isFlashOn = isFlashOn,
            guideText = I18n.get("align_document_hint", lang),
            foundText = I18n.get("document_found_hint", lang),
            onCameraBound = { cap, ctrl ->
                imageCapture = cap
                cameraControl = ctrl
            }
        )

        // Bottom Controls Overlay (OKEN style: gallery | shutter | last photo with count)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .navigationBarsPadding()
                .padding(bottom = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (appendTarget != null) {
                Text(
                    I18n.get("adding_to_document", lang),
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: import from gallery + phone camera app
                Row(
                    modifier = Modifier.width(110.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            pickMultipleLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }.padding(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = I18n.get("import_gallery", lang),
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                        Text(I18n.get("from_gallery", lang), color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            val f = File(context.filesDir, "phone_cam_${UUID.randomUUID()}.jpg")
                            photoFile = f
                            val u = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                            photoUri = u
                            takePictureLauncher.launch(u)
                        }.padding(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoCamera,
                            contentDescription = I18n.get("phone_camera_fallback", lang),
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                        Text(I18n.get("phone_camera_short", lang), color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                }

                // Shutter: normal size ring
                Box(
                    modifier = Modifier
                        .size(66.dp)
                        .border(3.dp, Color.White, CircleShape)
                        .padding(5.dp)
                        .clip(CircleShape)
                        .background(if (isCapturing) Color.LightGray else Color.White)
                        .clickable(enabled = !isCapturing) {
                            val cap = imageCapture ?: return@clickable
                            isCapturing = true
                            val file = File(context.filesDir, "cap_${UUID.randomUUID()}.jpg")
                            val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()

                            cap.takePicture(
                                outputOptions,
                                ContextCompat.getMainExecutor(context),
                                object : ImageCapture.OnImageSavedCallback {
                                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                        coroutineScope.launch {
                                            // Fix orientation (EXIF) before the page is shown anywhere
                                            val bmp = ImageProcessor.importPhoto(file)
                                            isCapturing = false
                                            if (bmp != null) viewModel.addCapturedImage(file, bmp)
                                        }
                                    }

                                    override fun onError(exception: ImageCaptureException) {
                                        isCapturing = false
                                        exception.printStackTrace()
                                    }
                                }
                            )
                        }
                        .testTag("camera_shutter_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCapturing) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), color = MaterialTheme.colorScheme.primary)
                    }
                }

                // Right: last photo thumbnail with the page count; tap to review the batch
                Box(
                    modifier = Modifier.width(110.dp),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    val last = batchItems.lastOrNull()
                    if (last != null) {
                        Box(
                            modifier = Modifier
                                .size(width = 54.dp, height = 66.dp)
                                .clickable { viewModel.navigateTo(Screen.BatchReview) }
                                .testTag("review_batch_btn")
                        ) {
                            androidx.compose.foundation.Image(
                                bitmap = remember(last.id, last.previewBitmap) {
                                    ImageProcessor.downscale(last.previewBitmap, 200).asImageBitmap()
                                },
                                contentDescription = I18n.get("review_batch", lang, batchItems.size),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(2.dp, Color.White, RoundedCornerShape(6.dp))
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 8.dp, y = (-8).dp)
                                    .size(24.dp)
                                    .background(MaterialTheme.colorScheme.primary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "${batchItems.size}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }
            // No separate Review button: the last-photo thumbnail with its count opens the filter screen
        }
    }

    // Leave Batch Confirmation Dialog
    if (showLeaveConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLeaveConfirmDialog = false },
            title = { Text(I18n.get("confirm", lang)) },
            text = { Text(I18n.get("confirm_leave_batch", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        showLeaveConfirmDialog = false
                        viewModel.batchItems.value = emptyList()
                        viewModel.navigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(I18n.get("leave", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showLeaveConfirmDialog = false }) {
                    Text(I18n.get("stay", lang))
                }
            }
        )
    }
}
