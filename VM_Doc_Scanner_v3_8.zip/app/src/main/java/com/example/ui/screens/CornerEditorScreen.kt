package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.data.model.CornerPoints
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch

/** Where the picture is drawn inside the canvas (pixels). */
private data class ImageGeom(val ox: Float, val oy: Float, val w: Float, val h: Float)

private val CropGreen = Color(0xFF10B981)
private val CropAmber = Color(0xFFF59E0B)

private fun mid(a: Offset, b: Offset) = Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)

/** 0..3 = TL, TR, BR, BL corners, 4..7 = Top, Right, Bottom, Left edge centres. */
private fun handlePoints(c: CornerPoints, g: ImageGeom): List<Offset> {
    val tl = Offset(g.ox + c.tlX * g.w, g.oy + c.tlY * g.h)
    val tr = Offset(g.ox + c.trX * g.w, g.oy + c.trY * g.h)
    val br = Offset(g.ox + c.brX * g.w, g.oy + c.brY * g.h)
    val bl = Offset(g.ox + c.blX * g.w, g.oy + c.blY * g.h)
    return listOf(tl, tr, br, bl, mid(tl, tr), mid(tr, br), mid(bl, br), mid(tl, bl))
}

private fun clamp01(v: Float) = v.coerceIn(0f, 1f)

/** Every corner can go anywhere inside the picture; edge handles slide two corners together. */
private fun moveHandle(c: CornerPoints, handle: Int, dx: Float, dy: Float): CornerPoints {
    return when (handle) {
        0 -> c.copy(tlX = clamp01(c.tlX + dx), tlY = clamp01(c.tlY + dy))
        1 -> c.copy(trX = clamp01(c.trX + dx), trY = clamp01(c.trY + dy))
        2 -> c.copy(brX = clamp01(c.brX + dx), brY = clamp01(c.brY + dy))
        3 -> c.copy(blX = clamp01(c.blX + dx), blY = clamp01(c.blY + dy))
        4 -> c.copy(
            tlX = clamp01(c.tlX + dx), tlY = clamp01(c.tlY + dy),
            trX = clamp01(c.trX + dx), trY = clamp01(c.trY + dy)
        )
        5 -> c.copy(
            trX = clamp01(c.trX + dx), trY = clamp01(c.trY + dy),
            brX = clamp01(c.brX + dx), brY = clamp01(c.brY + dy)
        )
        6 -> c.copy(
            blX = clamp01(c.blX + dx), blY = clamp01(c.blY + dy),
            brX = clamp01(c.brX + dx), brY = clamp01(c.brY + dy)
        )
        7 -> c.copy(
            tlX = clamp01(c.tlX + dx), tlY = clamp01(c.tlY + dy),
            blX = clamp01(c.blX + dx), blY = clamp01(c.blY + dy)
        )
        else -> c
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CornerEditorScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val corners by viewModel.cornerPoints.collectAsState()
    val autoDetectFailed by viewModel.autoDetectFailedMessage.collectAsState()

    var sourceBitmap by remember { mutableStateOf(viewModel.cornerEditingBitmap) }
    var quarterTurns by remember { mutableStateOf(0) }

    var canvasSize by remember { mutableStateOf(IntSize(1, 1)) }
    var activeHandle by remember { mutableStateOf(-1) }
    var isProcessing by remember { mutableStateOf(false) }

    fun proceed() {
        val bmp = sourceBitmap ?: return
        if (isProcessing) return
        isProcessing = true
        coroutineScope.launch {
            try {
                if (viewModel.isSingleCaptureFlow.value) {
                    // Use the full resolution file when we have it, so the scan stays sharp
                    val path = viewModel.cornerEditingPath
                    var full: Bitmap? = null
                    if (path != null) {
                        full = ImageProcessor.decodeOriented(path, 4096)
                        if (full != null && quarterTurns % 4 != 0) {
                            val m = Matrix().apply { postRotate(90f * (quarterTurns % 4)) }
                            val rotated = Bitmap.createBitmap(full, 0, 0, full.width, full.height, m, true)
                            if (rotated != full) full.recycle()
                            full = rotated
                        }
                    }
                    val warped = ImageProcessor.warpPerspective(full ?: bmp, viewModel.cornerPoints.value)
                    if (full != null && full !== bmp) full.recycle()
                    viewModel.onCropConfirmed(warped)
                } else {
                    viewModel.onCropConfirmed(bmp)
                }
            } finally {
                isProcessing = false
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        I18n.get("corner_editor_title", lang),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    Button(
                        onClick = { proceed() },
                        enabled = !isProcessing && sourceBitmap != null,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("confirm_crop_btn")
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text(I18n.get("next_step", lang), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val bmp = sourceBitmap
                            if (bmp != null) {
                                coroutineScope.launch {
                                    val (pts, success) = ImageProcessor.detectCorners(bmp)
                                    viewModel.cornerPoints.value = pts
                                    viewModel.autoDetectFailedMessage.value = !success
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("re_detect_btn")
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get("auto_crop", lang))
                    }

                    OutlinedButton(
                        onClick = {
                            val bmp = sourceBitmap
                            if (bmp != null) {
                                val mat = Matrix().apply { postRotate(90f) }
                                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mat, true)
                                sourceBitmap = rotated
                                viewModel.cornerEditingBitmap = rotated
                                quarterTurns += 1
                                coroutineScope.launch {
                                    val (pts, success) = ImageProcessor.detectCorners(rotated)
                                    viewModel.cornerPoints.value = pts
                                    viewModel.autoDetectFailedMessage.value = !success
                                    if (!viewModel.isSingleCaptureFlow.value) {
                                        val path = viewModel.cornerEditingPath
                                        if (path != null) viewModel.rotateBatchItem(path, rotated, pts)
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("rotate_corners_btn")
                    ) {
                        Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get("rotate_90", lang))
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0F172A))
                .onGloballyPositioned { coordinates -> canvasSize = coordinates.size }
        ) {
            val currentBmp = sourceBitmap
            if (currentBmp != null && canvasSize.width > 1 && canvasSize.height > 1) {
                val cw = canvasSize.width.toFloat()
                val ch = canvasSize.height.toFloat()
                val bmpW = currentBmp.width.toFloat()
                val bmpH = currentBmp.height.toFloat()

                // Use nearly the whole area; a small gutter keeps edge handles reachable
                val gutter = with(LocalDensity.current) { 16.dp.toPx() }
                val availW = cw - gutter * 2f
                val availH = ch - gutter * 2f
                val scale = minOf(availW / bmpW, availH / bmpH)
                val drawW = bmpW * scale
                val drawH = bmpH * scale
                val geom = ImageGeom((cw - drawW) / 2f, (ch - drawH) / 2f, drawW, drawH)

                // Always read the newest values inside the gesture block
                val geomState = rememberUpdatedState(geom)

                val points = handlePoints(corners, geom)

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(currentBmp) {
                            val hitRadius = 60.dp.toPx()
                            detectDragGestures(
                                onDragStart = { start ->
                                    val g = geomState.value
                                    val pts = handlePoints(viewModel.cornerPoints.value, g)
                                    var best = -1
                                    var bestDist = hitRadius
                                    pts.forEachIndexed { idx, p ->
                                        val d = (p - start).getDistance()
                                        if (d < bestDist) {
                                            bestDist = d
                                            best = idx
                                        }
                                    }
                                    activeHandle = best
                                },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    val handle = activeHandle
                                    if (handle < 0) return@detectDragGestures
                                    val g = geomState.value
                                    viewModel.cornerPoints.value = moveHandle(
                                        viewModel.cornerPoints.value,
                                        handle,
                                        dragAmount.x / g.w,
                                        dragAmount.y / g.h
                                    )
                                },
                                onDragEnd = { activeHandle = -1 },
                                onDragCancel = { activeHandle = -1 }
                            )
                        }
                ) {
                    drawImage(
                        image = currentBmp.asImageBitmap(),
                        dstOffset = IntOffset(geom.ox.toInt(), geom.oy.toInt()),
                        dstSize = IntSize(geom.w.toInt(), geom.h.toInt())
                    )

                    val pTL = points[0]
                    val pTR = points[1]
                    val pBR = points[2]
                    val pBL = points[3]

                    val fullPath = Path().apply {
                        addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height))
                    }
                    val cropPath = Path().apply {
                        moveTo(pTL.x, pTL.y)
                        lineTo(pTR.x, pTR.y)
                        lineTo(pBR.x, pBR.y)
                        lineTo(pBL.x, pBL.y)
                        close()
                    }
                    val outsidePath = Path.combine(PathOperation.Difference, fullPath, cropPath)
                    drawPath(outsidePath, Color.Black.copy(alpha = 0.55f))
                    drawPath(path = cropPath, color = CropGreen, style = Stroke(width = 2.5.dp.toPx()))

                    // Edge centre pills
                    for (idx in 0 until 4) {
                        val pt = points[idx + 4]
                        val focused = activeHandle == idx + 4
                        val horizontal = idx == 0 || idx == 2
                        val pillW = if (horizontal) 26.dp.toPx() else 10.dp.toPx()
                        val pillH = if (horizontal) 10.dp.toPx() else 26.dp.toPx()
                        drawRoundRect(
                            color = if (focused) CropAmber else CropGreen,
                            topLeft = Offset(pt.x - pillW / 2f, pt.y - pillH / 2f),
                            size = Size(pillW, pillH),
                            cornerRadius = CornerRadius(5.dp.toPx(), 5.dp.toPx())
                        )
                        drawRoundRect(
                            color = Color.White,
                            topLeft = Offset(pt.x - (pillW - 4.dp.toPx()) / 2f, pt.y - (pillH - 4.dp.toPx()) / 2f),
                            size = Size(pillW - 4.dp.toPx(), pillH - 4.dp.toPx()),
                            cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                        )
                    }

                    // Corner circles
                    for (idx in 0 until 4) {
                        val pt = points[idx]
                        val focused = activeHandle == idx
                        drawCircle(
                            color = if (focused) CropAmber else CropGreen,
                            radius = if (focused) 15.dp.toPx() else 12.dp.toPx(),
                            center = pt
                        )
                        drawCircle(color = Color.White, radius = 5.dp.toPx(), center = pt)
                    }
                }

                // Hint when automatic detection could not find the paper
                if (autoDetectFailed) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp),
                        color = Color.Black.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = I18n.get("auto_detect_failed", lang),
                            color = Color.White,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }

                // Magnifier: parked in a top corner on the side away from the finger,
                // so the corner being moved is always visible.
                if (activeHandle in 0..7) {
                    val focus = points[activeHandle]
                    val loupeAlign = if (focus.x < cw / 2f) Alignment.TopEnd else Alignment.TopStart
                    val zoom = 3.5f
                    Box(
                        modifier = Modifier
                            .align(loupeAlign)
                            .padding(10.dp)
                            .size(124.dp)
                            .clip(CircleShape)
                            .background(Color.Black)
                            .border(3.dp, CropGreen, CircleShape)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val centre = Offset(size.width / 2f, size.height / 2f)
                            fun map(p: Offset) = Offset(
                                centre.x + (p.x - focus.x) * zoom,
                                centre.y + (p.y - focus.y) * zoom
                            )

                            val imgTopLeft = map(Offset(geom.ox, geom.oy))
                            drawImage(
                                image = currentBmp.asImageBitmap(),
                                dstOffset = IntOffset(imgTopLeft.x.toInt(), imgTopLeft.y.toInt()),
                                dstSize = IntSize((geom.w * zoom).toInt(), (geom.h * zoom).toInt())
                            )

                            // Crop outline inside the magnifier
                            val q = Path().apply {
                                val a = map(points[0]); val b = map(points[1])
                                val c = map(points[2]); val d = map(points[3])
                                moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(c.x, c.y); lineTo(d.x, d.y); close()
                            }
                            drawPath(q, CropGreen, style = Stroke(width = 2.dp.toPx()))

                            // Target marker in the centre
                            drawCircle(Color.White, radius = 7.dp.toPx(), center = centre, style = Stroke(width = 2.dp.toPx()))
                            drawCircle(CropAmber, radius = 2.5.dp.toPx(), center = centre)
                        }
                    }
                }
            }
        }
    }
}
