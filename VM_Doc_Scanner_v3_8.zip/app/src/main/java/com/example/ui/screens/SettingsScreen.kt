package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.processing.GallerySaver
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.I18n
import com.example.i18n.Language
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import com.example.ui.viewmodel.ThemeMode
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    var showEraseConfirmDialog by remember { mutableStateOf(false) }

    // Where exported files are saved
    var saveLocationText by remember { mutableStateOf(GallerySaver.describeLocation(context)) }
    var hasCustomFolder by remember { mutableStateOf(GallerySaver.customTreeUri(context) != null) }
    var showRenameAlbumDialog by remember { mutableStateOf(false) }
    var albumNameInput by remember { mutableStateOf(GallerySaver.folderName(context)) }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
            GallerySaver.setCustomTreeUri(context, uri)
            hasCustomFolder = true
            saveLocationText = GallerySaver.describeLocation(context)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("settings_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Language Switcher Section
            Text(
                text = I18n.get("interface_language", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilterChip(
                    selected = lang == Language.HINDI,
                    onClick = { viewModel.setLanguage(Language.HINDI) },
                    label = { Text("हिन्दी", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.weight(1f).testTag("lang_hindi_chip")
                )
                FilterChip(
                    selected = lang == Language.ENGLISH,
                    onClick = { viewModel.setLanguage(Language.ENGLISH) },
                    label = { Text("English", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.weight(1f).testTag("lang_english_chip")
                )
            }

            Divider()

            // Theme Setting
            Text(
                text = I18n.get("theme", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = themeMode == ThemeMode.SYSTEM,
                    onClick = { viewModel.setThemeMode(ThemeMode.SYSTEM) },
                    label = { Text(I18n.get("theme_system", lang)) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = themeMode == ThemeMode.LIGHT,
                    onClick = { viewModel.setThemeMode(ThemeMode.LIGHT) },
                    label = { Text(I18n.get("theme_light", lang)) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = themeMode == ThemeMode.DARK,
                    onClick = { viewModel.setThemeMode(ThemeMode.DARK) },
                    label = { Text(I18n.get("theme_dark", lang)) },
                    modifier = Modifier.weight(1f)
                )
            }

            Divider()

            // Save location (path) section
            Text(
                text = I18n.get("save_location", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = saveLocationText,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.testTag("save_location_text")
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { folderPicker.launch(null) },
                            modifier = Modifier.weight(1f).testTag("change_save_folder_btn")
                        ) {
                            Text(I18n.get("change_folder", lang), style = MaterialTheme.typography.bodySmall)
                        }
                        if (hasCustomFolder) {
                            OutlinedButton(
                                onClick = {
                                    GallerySaver.setCustomTreeUri(context, null)
                                    hasCustomFolder = false
                                    saveLocationText = GallerySaver.describeLocation(context)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(I18n.get("reset_default", lang), style = MaterialTheme.typography.bodySmall)
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    albumNameInput = GallerySaver.folderName(context)
                                    showRenameAlbumDialog = true
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(I18n.get("rename_album", lang), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            Divider()

            // Storage Meter Quick Jump
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(Screen.Storage) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(I18n.get("storage_title", lang), fontWeight = FontWeight.SemiBold)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }

            Divider()

            // Privacy Notice Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = I18n.get("privacy_notice", lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // About the app
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("about_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(I18n.get("about_title", lang), fontWeight = FontWeight.SemiBold)
                    }
                    Text("VM Doc Scanner", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        I18n.get("app_version", lang) + ": " + com.example.BuildConfig.VERSION_NAME +
                            " (" + com.example.BuildConfig.VERSION_CODE + ")",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(I18n.get("about_desc", lang), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Erase All Data Section
            OutlinedButton(
                onClick = { showEraseConfirmDialog = true },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth().testTag("erase_all_data_btn")
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(I18n.get("erase_all_data", lang))
            }
        }
    }

    if (showRenameAlbumDialog) {
        AlertDialog(
            onDismissRequest = { showRenameAlbumDialog = false },
            title = { Text(I18n.get("rename_album", lang)) },
            text = {
                OutlinedTextField(
                    value = albumNameInput,
                    onValueChange = { albumNameInput = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    GallerySaver.setFolderName(context, albumNameInput)
                    saveLocationText = GallerySaver.describeLocation(context)
                    showRenameAlbumDialog = false
                }) { Text(I18n.get("save", lang)) }
            },
            dismissButton = {
                TextButton(onClick = { showRenameAlbumDialog = false }) { Text(I18n.get("cancel", lang)) }
            }
        )
    }

    // Erase Confirmation Dialog
    if (showEraseConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showEraseConfirmDialog = false },
            title = { Text(I18n.get("confirm_erase_title", lang)) },
            text = { Text(I18n.get("confirm_erase_desc", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        showEraseConfirmDialog = false
                        coroutineScope.launch {
                            viewModel.repository.eraseAllData()
                            viewModel.refreshStorageInfo()
                            viewModel.navigateTo(Screen.Home)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_erase_button")
                ) {
                    Text(I18n.get("confirm_erase_btn", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEraseConfirmDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }
}
