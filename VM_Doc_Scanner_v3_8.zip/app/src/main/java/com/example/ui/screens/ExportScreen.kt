package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.processing.GallerySaver
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.data.model.ExportFormat
import com.example.data.model.ExportQuality
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val pages by viewModel.activeDocumentPages.collectAsState()
    val docs by viewModel.allDocuments.collectAsState()
    val activeDocId by viewModel.activeDocumentId.collectAsState()
    val currentDoc = docs.find { it.id == activeDocId }

    var format by remember { mutableStateOf(ExportFormat.PDF) }
    var quality by remember { mutableStateOf(ExportQuality.HIGH) }
    val selectedPageIds = remember { mutableStateMapOf<String, Boolean>() }

    var isExporting by remember { mutableStateOf(false) }
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }
    val executeExportRef = remember { mutableStateOf<((Boolean) -> Unit)?>(null) }

    LaunchedEffect(pages) {
        // Pages picked on the document screen (select mode) come pre-selected; otherwise all pages
        val preset = viewModel.selectedExportPageIds.value
        pages.forEach { selectedPageIds[it.id] = preset.isEmpty() || it.id in preset }
    }
    DisposableEffect(Unit) { onDispose { viewModel.selectedExportPageIds.value = emptySet() } }

    val activeCount = selectedPageIds.values.count { it }

    // Honest approximate file size calculation
    val estimatedSizeText = remember(format, quality, activeCount) {
        val baseBytesPerPage = when (quality) {
            ExportQuality.ORIGINAL -> 2_500_000L
            ExportQuality.HIGH -> 1_200_000L
            ExportQuality.MEDIUM -> 500_000L
            ExportQuality.SMALL -> 180_000L
        }
        val total = baseBytesPerPage * activeCount.coerceAtLeast(1)
        val mb = total / (1024.0 * 1024.0)
        String.format("%.1f MB", mb)
    }

    // Android 9 and older need storage permission to write into Pictures / Documents
    var pendingSave by remember { mutableStateOf(false) }
    val storagePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (pendingSave) {
            pendingSave = false
            if (granted) executeExportRef.value?.invoke(false)
            else exportStatusMessage = I18n.get("storage_permission_needed", lang)
        }
    }

    fun executeExport(isShare: Boolean) {
        if (activeCount == 0) return
        if (!isShare && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            GallerySaver.customTreeUri(context) == null &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = true
            storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        isExporting = true
        coroutineScope.launch {
            try {
                val pagesToExport = pages.filter { selectedPageIds[it.id] == true }
                val bitmaps = mutableListOf<Bitmap>()
                for (p in pagesToExport) {
                    val bmp = ImageProcessor.loadBitmapFromFile(
                        if (p.originalImagePath.isNotBlank()) p.originalImagePath else p.thumbnailImagePath,
                        maxDimension = when (quality) {
                            ExportQuality.ORIGINAL -> 4096
                            ExportQuality.HIGH -> 2400
                            ExportQuality.MEDIUM -> 1600
                            ExportQuality.SMALL -> 1000
                        }
                    )
                    if (bmp != null) bitmaps.add(bmp)
                }
                val baseName = GallerySaver.safeName(currentDoc?.name ?: "scan")

                if (format == ExportFormat.PDF) {
                    val pdfFile = File(context.cacheDir, "$baseName.pdf")
                    val success = ImageProcessor.generatePdf(bitmaps, pdfFile)
                    if (!success) throw IllegalStateException("PDF")
                    if (isShare) {
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdfFile)
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, I18n.get("share_action", lang)))
                        exportStatusMessage = null
                    } else {
                        val where = GallerySaver.save(context, pdfFile, "$baseName.pdf", "application/pdf")
                        exportStatusMessage = I18n.get("saved_to", lang, where)
                    }
                } else {
                    val isPng = format == ExportFormat.PNG
                    val ext = if (isPng) "png" else "jpg"
                    val mime = if (isPng) "image/png" else "image/jpeg"
                    val exportFiles = mutableListOf<File>()
                    for ((idx, bmp) in bitmaps.withIndex()) {
                        val imgFile = File(context.cacheDir, "${baseName}_p${idx + 1}.$ext")
                        ImageProcessor.saveBitmapToFile(
                            bmp,
                            imgFile,
                            format = if (isPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                            quality = quality.jpegQuality,
                            dpi = quality.dpi
                        )
                        exportFiles.add(imgFile)
                    }

                    if (isShare && exportFiles.isNotEmpty()) {
                        val uris = ArrayList(exportFiles.map {
                            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it)
                        })
                        val shareIntent = if (uris.size == 1) {
                            Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris.first()) }
                        } else {
                            Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
                        }.apply {
                            type = mime
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, I18n.get("share_action", lang)))
                        exportStatusMessage = null
                    } else {
                        var where = ""
                        for (f in exportFiles) {
                            where = GallerySaver.save(context, f, f.name, mime)
                        }
                        exportStatusMessage = I18n.get("saved_images_to", lang, exportFiles.size, GallerySaver.describeLocation(context, false))
                    }
                }
            } catch (e: Exception) {
                exportStatusMessage = I18n.get("export_failed", lang) + " " + (e.message ?: "")
            } finally {
                isExporting = false
            }
        }
    }
    executeExportRef.value = { share -> executeExport(share) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("export_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { executeExport(isShare = false) },
                        enabled = !isExporting && activeCount > 0,
                        modifier = Modifier.weight(1f).testTag("save_to_device_btn")
                    ) {
                        // PDF is a document: it goes to Documents/<album> (or the chosen folder), never the gallery
                        val isPdf = format == ExportFormat.PDF
                        Icon(if (isPdf) Icons.Default.Folder else Icons.Default.Collections, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get(if (isPdf) "save_to_files" else "save_to_gallery", lang), style = MaterialTheme.typography.bodySmall)
                    }

                    Button(
                        onClick = { executeExport(isShare = true) },
                        enabled = !isExporting && activeCount > 0,
                        modifier = Modifier.weight(1f).testTag("share_with_apps_btn")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get("share_action", lang), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Status banner if export completed
            if (exportStatusMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = exportStatusMessage!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Export Format selection
            Text(
                text = I18n.get("format", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = format == ExportFormat.PDF,
                    onClick = { format = ExportFormat.PDF },
                    label = { Text(I18n.get("format_pdf", lang)) },
                    modifier = Modifier.weight(1f).testTag("format_pdf_chip")
                )
                FilterChip(
                    selected = format == ExportFormat.JPG,
                    onClick = { format = ExportFormat.JPG },
                    label = { Text(I18n.get("format_jpg", lang)) },
                    modifier = Modifier.weight(1f).testTag("format_jpg_chip")
                )
                FilterChip(
                    selected = format == ExportFormat.PNG,
                    onClick = { format = ExportFormat.PNG },
                    label = { Text(I18n.get("format_png", lang)) },
                    modifier = Modifier.weight(1f).testTag("format_png_chip")
                )
            }

            // Quality Selection
            Text(
                text = I18n.get("quality", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ExportQuality.values().forEach { q ->
                    val label = when (q) {
                        ExportQuality.ORIGINAL -> I18n.get("quality_original", lang)
                        ExportQuality.HIGH -> I18n.get("quality_high", lang)
                        ExportQuality.MEDIUM -> I18n.get("quality_medium", lang)
                        ExportQuality.SMALL -> I18n.get("quality_small", lang)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { quality = q }
                            .padding(vertical = 4.dp)
                    ) {
                        RadioButton(
                            selected = quality == q,
                            onClick = { quality = q },
                            modifier = Modifier.testTag("quality_radio_${q.name}")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            // Honest Estimated File Size Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = I18n.get("estimated_size", lang, estimatedSizeText),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("estimated_size_label")
                    )
                    Text(
                        text = "$activeCount pages",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Page Selection Checkboxes
            Text(
                text = I18n.get("select_pages", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            pages.forEachIndexed { index, page ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val curr = selectedPageIds[page.id] ?: true
                            selectedPageIds[page.id] = !curr
                        }
                        .padding(vertical = 4.dp)
                ) {
                    Checkbox(
                        checked = selectedPageIds[page.id] ?: true,
                        onCheckedChange = { selectedPageIds[page.id] = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Page ${index + 1} (${page.pageType.capitalize()})", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
