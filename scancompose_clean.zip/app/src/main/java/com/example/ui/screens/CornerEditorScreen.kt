package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.data.model.CornerPoints
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CornerEditorScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val corners by viewModel.cornerPoints.collectAsState()
    val autoDetectFailed by viewModel.autoDetectFailedMessage.collectAsState()

    var sourceBitmap by remember { mutableStateOf(viewModel.cornerEditingBitmap) }

    // Canvas display bounds
    var canvasSize by remember { mutableStateOf(IntSize(1, 1)) }
    var activeHandleIndex by remember { mutableStateOf<Int?>(null) } // 0: TL, 1: TR, 2: BR, 3: BL, 4: Top, 5: Right, 6: Bottom, 7: Left
    var isProcessingWarp by remember { mutableStateOf(false) }

    val handleRadiusPx = 36f

    fun proceedToFilter() {
        val bmp = sourceBitmap ?: return
        if (isProcessingWarp) return
        isProcessingWarp = true
        coroutineScope.launch {
            try {
                val warped = ImageProcessor.warpPerspective(bmp, corners)
                viewModel.onCropConfirmed(warped)
            } finally {
                isProcessingWarp = false
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("corner_editor_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    Button(
                        onClick = { proceedToFilter() },
                        enabled = !isProcessingWarp && sourceBitmap != null,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("confirm_crop_btn")
                    ) {
                        if (isProcessingWarp) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                        } else {
                            Text(I18n.get("next_step", lang), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Actions row: Auto Detect, Full Page, Rotate 90°
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (sourceBitmap != null) {
                                    coroutineScope.launch {
                                        val (pts, success) = ImageProcessor.detectCorners(sourceBitmap!!)
                                        viewModel.cornerPoints.value = pts
                                        viewModel.autoDetectFailedMessage.value = !success
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("re_detect_btn")
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(I18n.get("auto_crop", lang), style = MaterialTheme.typography.bodySmall)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.cornerPoints.value = CornerPoints.defaultFull()
                            },
                            modifier = Modifier.weight(1f).testTag("select_whole_page_btn")
                        ) {
                            Icon(Icons.Default.CropFree, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(I18n.get("select_whole_page", lang), style = MaterialTheme.typography.bodySmall)
                        }

                        OutlinedButton(
                            onClick = {
                                val bmp = sourceBitmap
                                if (bmp != null) {
                                    val mat = Matrix().apply { postRotate(90f) }
                                    val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mat, true)
                                    sourceBitmap = rotated
                                    viewModel.cornerEditingBitmap = rotated
                                    coroutineScope.launch {
                                        val (pts, success) = ImageProcessor.detectCorners(rotated)
                                        viewModel.cornerPoints.value = pts
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("rotate_corners_btn")
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(I18n.get("rotate_90", lang), style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Prominent Next Button
                    Button(
                        onClick = { proceedToFilter() },
                        enabled = !isProcessingWarp && sourceBitmap != null,
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("next_step_bottom_btn")
                    ) {
                        Icon(Icons.Default.ArrowForward, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(I18n.get("next_step", lang), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A))
                    .onGloballyPositioned { coordinates ->
                        canvasSize = coordinates.size
                    }
            ) {
                val currentBmp = sourceBitmap
                if (currentBmp != null && canvasSize.width > 1 && canvasSize.height > 1) {
                    val cw = canvasSize.width.toFloat()
                    val ch = canvasSize.height.toFloat()

                    val bmpW = currentBmp.width.toFloat()
                    val bmpH = currentBmp.height.toFloat()
                    val scale = minOf(cw / bmpW, ch / bmpH) * 0.94f

                    val drawW = bmpW * scale
                    val drawH = bmpH * scale
                    val offsetX = (cw - drawW) / 2f
                    val offsetY = (ch - drawH) / 2f

                    // 4 Corner points in canvas pixels
                    val pTL = Offset(offsetX + corners.tlX * drawW, offsetY + corners.tlY * drawH)
                    val pTR = Offset(offsetX + corners.trX * drawW, offsetY + corners.trY * drawH)
                    val pBR = Offset(offsetX + corners.brX * drawW, offsetY + corners.brY * drawH)
                    val pBL = Offset(offsetX + corners.blX * drawW, offsetY + corners.blY * drawH)

                    // 4 Edge midpoints in canvas pixels
                    val pTop = Offset((pTL.x + pTR.x) / 2f, (pTL.y + pTR.y) / 2f)
                    val pRight = Offset((pTR.x + pBR.x) / 2f, (pTR.y + pBR.y) / 2f)
                    val pBottom = Offset((pBL.x + pBR.x) / 2f, (pBL.y + pBR.y) / 2f)
                    val pLeft = Offset((pTL.x + pBL.x) / 2f, (pTL.y + pBL.y) / 2f)

                    // Total 8 handles (0-3: corners, 4-7: edge midpoints)
                    val allHandles = listOf(pTL, pTR, pBR, pBL, pTop, pRight, pBottom, pLeft)

                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(currentBmp) {
                                detectDragGestures(
                                    onDragStart = { startPos ->
                                        val dists = allHandles.mapIndexed { idx, pt ->
                                            idx to (pt - startPos).getDistance()
                                        }
                                        val closest = dists.minByOrNull { it.second }
                                        if (closest != null && closest.second < 180f) {
                                            activeHandleIndex = closest.first
                                        }
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val handle = activeHandleIndex ?: return@detectDragGestures
                                        val normDx = dragAmount.x / drawW
                                        val normDy = dragAmount.y / drawH

                                        viewModel.cornerPoints.value = when (handle) {
                                            0 -> corners.copy(
                                                tlX = (corners.tlX + normDx).coerceIn(0f, corners.trX - 0.05f),
                                                tlY = (corners.tlY + normDy).coerceIn(0f, corners.blY - 0.05f)
                                            )
                                            1 -> corners.copy(
                                                trX = (corners.trX + normDx).coerceIn(corners.tlX + 0.05f, 1f),
                                                trY = (corners.trY + normDy).coerceIn(0f, corners.brY - 0.05f)
                                            )
                                            2 -> corners.copy(
                                                brX = (corners.brX + normDx).coerceIn(corners.blX + 0.05f, 1f),
                                                brY = (corners.brY + normDy).coerceIn(corners.trY + 0.05f, 1f)
                                            )
                                            3 -> corners.copy(
                                                blX = (corners.blX + normDx).coerceIn(0f, corners.brX - 0.05f),
                                                blY = (corners.blY + normDy).coerceIn(corners.tlY + 0.05f, 1f)
                                            )
                                            4 -> { // Top Edge: moves TL and TR vertically
                                                corners.copy(
                                                    tlY = (corners.tlY + normDy).coerceIn(0f, corners.blY - 0.05f),
                                                    trY = (corners.trY + normDy).coerceIn(0f, corners.brY - 0.05f)
                                                )
                                            }
                                            5 -> { // Right Edge: moves TR and BR horizontally
                                                corners.copy(
                                                    trX = (corners.trX + normDx).coerceIn(corners.tlX + 0.05f, 1f),
                                                    brX = (corners.brX + normDx).coerceIn(corners.blX + 0.05f, 1f)
                                                )
                                            }
                                            6 -> { // Bottom Edge: moves BL and BR vertically
                                                corners.copy(
                                                    blY = (corners.blY + normDy).coerceIn(corners.tlY + 0.05f, 1f),
                                                    brY = (corners.brY + normDy).coerceIn(corners.trY + 0.05f, 1f)
                                                )
                                            }
                                            7 -> { // Left Edge: moves TL and BL horizontally
                                                corners.copy(
                                                    tlX = (corners.tlX + normDx).coerceIn(0f, corners.trX - 0.05f),
                                                    blX = (corners.blX + normDx).coerceIn(0f, corners.brX - 0.05f)
                                                )
                                            }
                                            else -> corners
                                        }
                                    },
                                    onDragEnd = {
                                        activeHandleIndex = null
                                    },
                                    onDragCancel = {
                                        activeHandleIndex = null
                                    }
                                )
                            }
                    ) {
                        // Draw image
                        drawImage(
                            image = currentBmp.asImageBitmap(),
                            dstOffset = IntOffset(offsetX.toInt(), offsetY.toInt()),
                            dstSize = IntSize(drawW.toInt(), drawH.toInt())
                        )

                        // Draw darkened overlay outside crop quadrilateral
                        val fullPath = Path().apply {
                            addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height))
                        }
                        val cropPath = Path().apply {
                            moveTo(pTL.x, pTL.y)
                            lineTo(pTR.x, pTR.y)
                            lineTo(pBR.x, pBR.y)
                            lineTo(pBL.x, pBL.y)
                            close()
                        }
                        val outsidePath = Path.combine(PathOperation.Difference, fullPath, cropPath)
                        drawPath(outsidePath, Color.Black.copy(alpha = 0.55f))

                        // Draw crop boundary lines
                        drawPath(
                            path = cropPath,
                            color = Color(0xFF10B981), // CamScanner emerald green
                            style = Stroke(width = 5f)
                        )

                        // Draw 4 Edge Midpoint Handles (Pill handles)
                        val edgeHandles = listOf(pTop, pRight, pBottom, pLeft)
                        edgeHandles.forEachIndexed { idx, pt ->
                            val handleIdx = idx + 4
                            val isFocused = activeHandleIndex == handleIdx
                            val isHorizontal = idx == 0 || idx == 2
                            val pillW = if (isHorizontal) 44f else 18f
                            val pillH = if (isHorizontal) 18f else 44f

                            drawRoundRect(
                                color = if (isFocused) Color(0xFFF59E0B) else Color(0xFF10B981),
                                topLeft = Offset(pt.x - pillW / 2f, pt.y - pillH / 2f),
                                size = Size(pillW, pillH),
                                cornerRadius = CornerRadius(8f, 8f)
                            )
                            drawRoundRect(
                                color = Color.White,
                                topLeft = Offset(pt.x - (pillW - 8f) / 2f, pt.y - (pillH - 8f) / 2f),
                                size = Size(pillW - 8f, pillH - 8f),
                                cornerRadius = CornerRadius(4f, 4f)
                            )
                        }

                        // Draw 4 Corner Handles
                        val cornerHandles = listOf(pTL, pTR, pBR, pBL)
                        cornerHandles.forEachIndexed { idx, pt ->
                            val isFocused = activeHandleIndex == idx
                            drawCircle(
                                color = if (isFocused) Color(0xFFF59E0B) else Color(0xFF10B981),
                                radius = if (isFocused) handleRadiusPx * 1.3f else handleRadiusPx,
                                center = pt
                            )
                            drawCircle(
                                color = Color.White,
                                radius = handleRadiusPx * 0.45f,
                                center = pt
                            )
                        }
                    }

                    // Loupe Magnifier overlay when dragging any handle
                    if (activeHandleIndex != null) {
                        val activePt = allHandles[activeHandleIndex!!]
                        Box(
                            modifier = Modifier
                                .offset {
                                    IntOffset(
                                        x = (activePt.x - 90f).toInt().coerceIn(16, (cw - 180).toInt()),
                                        y = (activePt.y - 200f).toInt().coerceIn(16, (ch - 200).toInt())
                                    )
                                }
                                .size(130.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .border(3.dp, Color(0xFF10B981), CircleShape)
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val normX = ((activePt.x - offsetX) / drawW).coerceIn(0f, 1f)
                                val normY = ((activePt.y - offsetY) / drawH).coerceIn(0f, 1f)
                                val srcX = (normX * bmpW).toInt()
                                val srcY = (normY * bmpH).toInt()

                                val sampleRadius = 45
                                val srcRect = android.graphics.Rect(
                                    (srcX - sampleRadius).coerceAtLeast(0),
                                    (srcY - sampleRadius).coerceAtLeast(0),
                                    (srcX + sampleRadius).coerceAtMost(currentBmp.width),
                                    (srcY + sampleRadius).coerceAtMost(currentBmp.height)
                                )

                                drawImage(
                                    image = currentBmp.asImageBitmap(),
                                    srcOffset = IntOffset(srcRect.left, srcRect.top),
                                    srcSize = IntSize(srcRect.width(), srcRect.height()),
                                    dstOffset = IntOffset.Zero,
                                    dstSize = IntSize(size.width.toInt(), size.height.toInt())
                                )

                                // Crosshairs
                                drawLine(
                                    color = Color(0xFF10B981),
                                    start = Offset(size.width / 2f, 0f),
                                    end = Offset(size.width / 2f, size.height),
                                    strokeWidth = 2.5f
                                )
                                drawLine(
                                    color = Color(0xFF10B981),
                                    start = Offset(0f, size.height / 2f),
                                    end = Offset(size.width, size.height / 2f),
                                    strokeWidth = 2.5f
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
