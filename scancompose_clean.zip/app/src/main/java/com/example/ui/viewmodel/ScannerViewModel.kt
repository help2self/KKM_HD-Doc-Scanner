package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.DocumentEntity
import com.example.data.local.FolderEntity
import com.example.data.local.PageEntity
import com.example.data.local.TagEntity
import com.example.data.model.*
import com.example.data.repository.DocumentRepository
import com.example.i18n.I18n
import com.example.i18n.Language
import com.example.processing.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class SortOption { DATE, NAME, SIZE }
enum class DateFilterOption { ALL_TIME, TODAY, THIS_WEEK, THIS_MONTH }

data class BatchCaptureItem(
    val id: String = UUID.randomUUID().toString(),
    val originalFile: File,
    val previewBitmap: Bitmap,
    var corners: CornerPoints,
    var autoCropSuccess: Boolean,
    var filter: FilterType = FilterType.ORIGINAL
)

class ScannerViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    val repository = DocumentRepository(context)
    private val prefs = context.getSharedPreferences("scanner_prefs", Context.MODE_PRIVATE)

    // Language & Theme state
    private val _language = MutableStateFlow(
        if (prefs.getString("lang", "hi") == "en") Language.ENGLISH else Language.HINDI
    )
    val language: StateFlow<Language> = _language.asStateFlow()

    private val _themeMode = MutableStateFlow(
        ThemeMode.valueOf(prefs.getString("theme", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Navigation state
    private val _navigationStack = MutableStateFlow<List<com.example.ui.Screen>>(listOf(com.example.ui.Screen.Home))
    val currentScreen: StateFlow<com.example.ui.Screen> = _navigationStack.map { it.last() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, com.example.ui.Screen.Home)

    // Data streams from repository
    val allDocuments: StateFlow<List<DocumentEntity>> = repository.getAllDocuments()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allFolders: StateFlow<List<FolderEntity>> = repository.getAllFolders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allTags: StateFlow<List<TagEntity>> = repository.getAllTags()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val totalPagesCount: StateFlow<Int> = repository.getTotalPagesCount()
        .stateIn(viewModelScope, SharingStarted.Lazily, 0)

    // Library Filter & Search state
    val searchQuery = MutableStateFlow("")
    val selectedFolderId = MutableStateFlow<String?>(null) // null = all
    val selectedTagId = MutableStateFlow<String?>(null)
    val dateFilter = MutableStateFlow(DateFilterOption.ALL_TIME)
    val sortOption = MutableStateFlow(SortOption.DATE)

    // Storage info
    private val _storageInfo = MutableStateFlow(StorageInfo())
    val storageInfo: StateFlow<StorageInfo> = _storageInfo.asStateFlow()

    // Active document in DocumentDetailScreen
    val activeDocumentId = MutableStateFlow<String?>(null)
    val activeDocumentPages = MutableStateFlow<List<PageEntity>>(emptyList())

    // Capture & Batch scanning state
    val batchItems = MutableStateFlow<List<BatchCaptureItem>>(emptyList())
    val isAutoCropEnabled = MutableStateFlow(true)
    val autoApplyDefaultFilter = MutableStateFlow(false)
    val isSingleCaptureFlow = MutableStateFlow(true)
    var capturedTempFile: File? = null

    // Corner Editor state
    var cornerEditingBitmap: Bitmap? = null
    var cornerEditingPath: String? = null
    val cornerPoints = MutableStateFlow(CornerPoints.defaultFull())
    val autoDetectFailedMessage = MutableStateFlow(false)

    // Page Editor state
    val activeEditingPage = MutableStateFlow<PageEntity?>(null)
    var editorWorkingBitmap: Bitmap? = null
    val currentFilter = MutableStateFlow(FilterType.ORIGINAL)
    val editParameters = MutableStateFlow(EditParameters())
    val rotationAngle = MutableStateFlow(0)
    val editorHistory = MutableStateFlow<List<Pair<FilterType, EditParameters>>>(emptyList())
    val editorRedoStack = MutableStateFlow<List<Pair<FilterType, EditParameters>>>(emptyList())

    // Composer state
    val composerConfig = MutableStateFlow(ComposedPageConfig())
    val composerObjects = MutableStateFlow<List<ComposedObject>>(emptyList())
    val selectedObjectId = MutableStateFlow<String?>(null)
    val composerHistory = MutableStateFlow<List<List<ComposedObject>>>(emptyList())
    val composerRedoStack = MutableStateFlow<List<List<ComposedObject>>>(emptyList())

    // Passport Sheet state
    val passportConfig = MutableStateFlow(PassportConfig())
    var passportSourceBitmap: Bitmap? = null
    var passportGeneratedSheet: Bitmap? = null

    // Export state
    val exportFormat = MutableStateFlow(ExportFormat.PDF)
    val exportQuality = MutableStateFlow(ExportQuality.HIGH)
    val selectedExportPageIds = MutableStateFlow<Set<String>>(emptySet())

    // Feedback message
    val userNotification = MutableStateFlow<String?>(null)

    init {
        refreshStorageInfo()
        viewModelScope.launch {
            activeDocumentId.collectLatest { docId ->
                if (docId != null) {
                    repository.getPagesForDocument(docId).collectLatest { pages ->
                        activeDocumentPages.value = pages
                    }
                } else {
                    activeDocumentPages.value = emptyList()
                }
            }
        }
    }

    fun navigateTo(screen: com.example.ui.Screen) {
        _navigationStack.value = _navigationStack.value + screen
    }

    fun navigateBack(): Boolean {
        if (_navigationStack.value.size > 1) {
            _navigationStack.value = _navigationStack.value.dropLast(1)
            return true
        }
        return false
    }

    fun setLanguage(lang: Language) {
        _language.value = lang
        prefs.edit().putString("lang", lang.code).apply()
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString("theme", mode.name).apply()
    }

    fun refreshStorageInfo() {
        viewModelScope.launch {
            _storageInfo.value = repository.calculateStorageInfo()
        }
    }

    fun simulateStorage(percentage: Int) {
        when (percentage) {
            80 -> {
                repository.isSimulated80 = true
                repository.isSimulated95 = false
                repository.isSimulatedQuotaError = false
            }
            95 -> {
                repository.isSimulated80 = false
                repository.isSimulated95 = true
                repository.isSimulatedQuotaError = false
            }
            100 -> { // Quota error simulation
                repository.isSimulated80 = false
                repository.isSimulated95 = true
                repository.isSimulatedQuotaError = true
            }
            else -> {
                repository.isSimulated80 = false
                repository.isSimulated95 = false
                repository.isSimulatedQuotaError = false
            }
        }
        refreshStorageInfo()
    }

    // Capture & Batch actions
    fun addCapturedImage(imageFile: File, bitmap: Bitmap) {
        viewModelScope.launch {
            val (corners, success) = if (isAutoCropEnabled.value) {
                ImageProcessor.detectCorners(bitmap)
            } else {
                Pair(CornerPoints.defaultFull(), true)
            }

            val filter = if (autoApplyDefaultFilter.value) FilterType.AUTO_ENHANCE else FilterType.ORIGINAL
            val newItem = BatchCaptureItem(
                originalFile = imageFile,
                previewBitmap = bitmap,
                corners = corners,
                autoCropSuccess = success,
                filter = filter
            )
            batchItems.value = batchItems.value + newItem
        }
    }

    fun startSingleCapture(imageFile: File, bitmap: Bitmap) {
        viewModelScope.launch {
            val (corners, success) = ImageProcessor.detectCorners(bitmap)
            cornerEditingBitmap = bitmap
            cornerEditingPath = imageFile.absolutePath
            capturedTempFile = imageFile
            cornerPoints.value = corners
            autoDetectFailedMessage.value = !success
            isSingleCaptureFlow.value = true
            navigateTo(com.example.ui.Screen.CornerEditor)
        }
    }

    fun onCropConfirmed(warpedBitmap: Bitmap) {
        if (isSingleCaptureFlow.value) {
            editorWorkingBitmap = warpedBitmap
            currentFilter.value = FilterType.MAGIC_COLOR
            activeEditingPage.value = null
            navigateTo(com.example.ui.Screen.PageEditor)
        } else {
            batchItems.value = batchItems.value.map { item ->
                if (item.originalFile.absolutePath == cornerEditingPath) {
                    item.copy(corners = cornerPoints.value, autoCropSuccess = true)
                } else item
            }
            navigateBack()
        }
    }

    fun saveNewCapturedPage(
        bitmap: Bitmap,
        filter: FilterType,
        editParams: EditParameters,
        rotationDeg: Int,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            try {
                val timestamp = System.currentTimeMillis()
                var docId = activeDocumentId.value
                if (docId == null) {
                    docId = UUID.randomUUID().toString()
                    val doc = DocumentEntity(
                        id = docId,
                        name = I18n.defaultScanName(timestamp),
                        folderId = selectedFolderId.value,
                        createdAt = timestamp,
                        updatedAt = timestamp
                    )
                    repository.saveDocument(doc)
                    activeDocumentId.value = docId
                }

                val existingPages = repository.getPagesForDocumentSync(docId)
                val pageOrder = existingPages.size

                val pageId = UUID.randomUUID().toString()
                val origFile = File(context.filesDir, "scan_${pageId}.jpg")
                val thumbFile = File(context.filesDir, "thumb_${pageId}.jpg")

                ImageProcessor.saveBitmapToFile(bitmap, origFile)
                val thumbBmp = Bitmap.createScaledBitmap(
                    bitmap,
                    300,
                    (300f * bitmap.height / bitmap.width).toInt().coerceAtLeast(50),
                    true
                )
                ImageProcessor.saveBitmapToFile(thumbBmp, thumbFile, quality = 80)

                val newPage = PageEntity(
                    id = pageId,
                    documentId = docId,
                    pageOrder = pageOrder,
                    pageType = "scan",
                    originalImagePath = origFile.absolutePath,
                    thumbnailImagePath = thumbFile.absolutePath,
                    cropCornersJson = JSONObject().apply {
                        put("tlX", cornerPoints.value.tlX)
                        put("tlY", cornerPoints.value.tlY)
                        put("trX", cornerPoints.value.trX)
                        put("trY", cornerPoints.value.trY)
                        put("brX", cornerPoints.value.brX)
                        put("brY", cornerPoints.value.brY)
                        put("blX", cornerPoints.value.blX)
                        put("blY", cornerPoints.value.blY)
                    }.toString(),
                    filterType = filter.name,
                    rotationDeg = rotationDeg
                )
                repository.savePage(newPage)
                refreshStorageInfo()

                capturedTempFile = null
                cornerEditingBitmap = null
                editorWorkingBitmap = null

                // Replace stack so user is at DocumentDetail
                _navigationStack.value = listOf(com.example.ui.Screen.Home, com.example.ui.Screen.DocumentDetail)
                onComplete()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun removeBatchItem(id: String) {
        batchItems.value = batchItems.value.filter { it.id != id }
    }

    fun finishBatch(documentName: String? = null, onComplete: (String) -> Unit) {
        viewModelScope.launch {
            if (batchItems.value.isEmpty()) return@launch
            try {
                val docId = UUID.randomUUID().toString()
                val timestamp = System.currentTimeMillis()
                val finalName = documentName?.ifBlank { null } ?: I18n.defaultScanName(timestamp)

                val doc = DocumentEntity(
                    id = docId,
                    name = finalName,
                    folderId = selectedFolderId.value,
                    createdAt = timestamp,
                    updatedAt = timestamp
                )
                repository.saveDocument(doc)

                val pages = mutableListOf<PageEntity>()
                for ((index, item) in batchItems.value.withIndex()) {
                    val pageId = UUID.randomUUID().toString()
                    val warped = ImageProcessor.warpPerspective(item.previewBitmap, item.corners)
                    val filtered = ImageProcessor.applyFiltersAndEdits(warped, item.filter, EditParameters())

                    val origFile = File(context.filesDir, "scan_${pageId}.jpg")
                    val thumbFile = File(context.filesDir, "thumb_${pageId}.jpg")
                    ImageProcessor.saveBitmapToFile(filtered, origFile)

                    val thumbBmp = Bitmap.createScaledBitmap(filtered, 300, (300f * filtered.height / filtered.width).toInt(), true)
                    ImageProcessor.saveBitmapToFile(thumbBmp, thumbFile, quality = 80)

                    pages.add(
                        PageEntity(
                            id = pageId,
                            documentId = docId,
                            pageOrder = index,
                            pageType = "scan",
                            originalImagePath = origFile.absolutePath,
                            thumbnailImagePath = thumbFile.absolutePath,
                            cropCornersJson = JSONObject().apply {
                                put("tlX", item.corners.tlX)
                                put("tlY", item.corners.tlY)
                                put("trX", item.corners.trX)
                                put("trY", item.corners.trY)
                                put("brX", item.corners.brX)
                                put("brY", item.corners.brY)
                                put("blX", item.corners.blX)
                                put("blY", item.corners.blY)
                            }.toString(),
                            filterType = item.filter.name
                        )
                    )
                }

                repository.savePages(pages)
                batchItems.value = emptyList()
                refreshStorageInfo()
                activeDocumentId.value = docId
                onComplete(docId)
            } catch (e: Exception) {
                userNotification.value = "Storage error: ${e.message}"
            }
        }
    }

    // Document actions
    fun renameDocument(docId: String, newName: String) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId) ?: return@launch
            repository.saveDocument(doc.copy(name = newName.trim(), updatedAt = System.currentTimeMillis()))
        }
    }

    fun updateNotes(docId: String, notes: String) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId) ?: return@launch
            repository.saveDocument(doc.copy(notes = notes, updatedAt = System.currentTimeMillis()))
        }
    }

    fun setDocumentFolder(docId: String, folderId: String?) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId) ?: return@launch
            repository.saveDocument(doc.copy(folderId = folderId, updatedAt = System.currentTimeMillis()))
        }
    }

    fun toggleDocumentTag(docId: String, tagId: String) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId) ?: return@launch
            val arr = try { JSONArray(doc.tagIdsJson) } catch (e: Exception) { JSONArray() }
            val newArr = JSONArray()
            var found = false
            for (i in 0 until arr.length()) {
                val tid = arr.optString(i)
                if (tid == tagId) {
                    found = true
                } else {
                    newArr.put(tid)
                }
            }
            if (!found) {
                newArr.put(tagId)
            }
            repository.saveDocument(doc.copy(tagIdsJson = newArr.toString(), updatedAt = System.currentTimeMillis()))
        }
    }

    fun duplicatePage(page: PageEntity) {
        viewModelScope.launch {
            repository.duplicatePage(page)
            refreshStorageInfo()
        }
    }

    fun deletePage(page: PageEntity) {
        viewModelScope.launch {
            repository.deletePage(page)
            refreshStorageInfo()
        }
    }

    fun deleteDocument(doc: DocumentEntity) {
        viewModelScope.launch {
            repository.deleteDocument(doc)
            refreshStorageInfo()
            if (activeDocumentId.value == doc.id) {
                activeDocumentId.value = null
                navigateBack()
            }
        }
    }

    // Composer Undo/Redo & Tools
    fun updateComposerObjects(newObjects: List<ComposedObject>) {
        composerHistory.value = (composerHistory.value + listOf(composerObjects.value)).takeLast(50)
        composerRedoStack.value = emptyList()
        composerObjects.value = newObjects
    }

    fun undoComposer() {
        if (composerHistory.value.isNotEmpty()) {
            val prev = composerHistory.value.last()
            composerHistory.value = composerHistory.value.dropLast(1)
            composerRedoStack.value = composerRedoStack.value + listOf(composerObjects.value)
            composerObjects.value = prev
        }
    }

    fun redoComposer() {
        if (composerRedoStack.value.isNotEmpty()) {
            val next = composerRedoStack.value.last()
            composerRedoStack.value = composerRedoStack.value.dropLast(1)
            composerHistory.value = composerHistory.value + listOf(composerObjects.value)
            composerObjects.value = next
        }
    }

    fun applyReadyLayout(layoutType: String, importedPaths: List<String>) {
        if (importedPaths.isEmpty()) return
        val w = composerConfig.value.widthMm
        val h = composerConfig.value.heightMm
        val margin = composerConfig.value.marginMm

        val availW = w - 2 * margin
        val availH = h - 2 * margin

        val newObjs = mutableListOf<ComposedObject>()
        when (layoutType) {
            "1" -> {
                newObjs.add(
                    ComposedObject(
                        id = UUID.randomUUID().toString(),
                        type = ObjectType.IMAGE,
                        imagePath = importedPaths.first(),
                        xMm = margin,
                        yMm = margin,
                        widthMm = availW,
                        heightMm = availH
                    )
                )
            }
            "2" -> {
                val itemH = (availH - 5f) / 2f
                for (i in 0 until minOf(2, importedPaths.size)) {
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = importedPaths[i],
                            xMm = margin,
                            yMm = margin + i * (itemH + 5f),
                            widthMm = availW,
                            heightMm = itemH
                        )
                    )
                }
            }
            "4" -> {
                val itemW = (availW - 5f) / 2f
                val itemH = (availH - 5f) / 2f
                for (i in 0 until minOf(4, importedPaths.size)) {
                    val col = i % 2
                    val row = i / 2
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = importedPaths[i],
                            xMm = margin + col * (itemW + 5f),
                            yMm = margin + row * (itemH + 5f),
                            widthMm = itemW,
                            heightMm = itemH
                        )
                    )
                }
            }
            "6" -> {
                val itemW = (availW - 5f) / 2f
                val itemH = (availH - 10f) / 3f
                for (i in 0 until minOf(6, importedPaths.size)) {
                    val col = i % 2
                    val row = i / 2
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = importedPaths[i],
                            xMm = margin + col * (itemW + 5f),
                            yMm = margin + row * (itemH + 5f),
                            widthMm = itemW,
                            heightMm = itemH
                        )
                    )
                }
            }
            "id_card" -> {
                // Exact Indian/Standard ID Card size: 85.6 mm x 54.0 mm
                val cardW = 85.6f
                val cardH = 54.0f
                val centerX = (w - cardW) / 2f
                val gap = 20f
                val startY = (h - (cardH * 2 + gap)) / 2f

                for (i in 0 until minOf(2, importedPaths.size)) {
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = importedPaths[i],
                            xMm = centerX,
                            yMm = startY + i * (cardH + gap),
                            widthMm = cardW,
                            heightMm = cardH,
                            borderWidthMm = 0.3f,
                            borderColor = 0xFFCCCCCC.toInt()
                        )
                    )
                }
            }
        }
        updateComposerObjects(newObjs)
    }

    // Save composed page into active document or new document
    fun saveComposedPage(documentId: String?, onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                val targetDocId = documentId ?: run {
                    val newId = UUID.randomUUID().toString()
                    val timestamp = System.currentTimeMillis()
                    val newDoc = DocumentEntity(
                        id = newId,
                        name = "Composed " + I18n.defaultScanName(timestamp),
                        createdAt = timestamp,
                        updatedAt = timestamp
                    )
                    repository.saveDocument(newDoc)
                    newId
                }

                val pageId = UUID.randomUUID().toString()
                val renderedBmp = ImageProcessor.renderComposedPage(composerConfig.value, composerObjects.value, dpi = 300)
                val origFile = File(context.filesDir, "composed_${pageId}.jpg")
                val thumbFile = File(context.filesDir, "thumb_${pageId}.jpg")
                ImageProcessor.saveBitmapToFile(renderedBmp, origFile)

                val thumb = Bitmap.createScaledBitmap(renderedBmp, 300, (300f * renderedBmp.height / renderedBmp.width).toInt(), true)
                ImageProcessor.saveBitmapToFile(thumb, thumbFile, quality = 80)

                val currentPages = repository.getPagesForDocumentSync(targetDocId)
                val newPage = PageEntity(
                    id = pageId,
                    documentId = targetDocId,
                    pageOrder = currentPages.size,
                    pageType = "composed",
                    originalImagePath = origFile.absolutePath,
                    thumbnailImagePath = thumbFile.absolutePath
                )
                repository.savePage(newPage)
                refreshStorageInfo()
                activeDocumentId.value = targetDocId
                onComplete()
            } catch (e: Exception) {
                userNotification.value = "Failed to save composed page: ${e.message}"
            }
        }
    }
}
