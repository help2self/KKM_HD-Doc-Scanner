package com.example.processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.example.data.model.ComposedObject
import com.example.data.model.ComposedPageConfig
import com.example.data.model.CornerPoints
import com.example.data.model.EditParameters
import com.example.data.model.FilterType
import com.example.data.model.ObjectType
import com.example.data.model.PageOrientation
import com.example.data.model.PassportConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object ImageProcessor {

    suspend fun loadBitmapFromFile(path: String, maxDimension: Int? = null): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            if (!file.exists()) return@withContext null

            if (maxDimension == null) {
                return@withContext BitmapFactory.decodeFile(path)
            }

            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, options)

            var sampleSize = 1
            val maxEdge = max(options.outWidth, options.outHeight)
            while (maxEdge / (sampleSize * 2) >= maxDimension) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(path, decodeOptions)
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    suspend fun saveBitmapToFile(bitmap: Bitmap, file: File, format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG, quality: Int = 92): Boolean = withContext(Dispatchers.IO) {
        try {
            file.parentFile?.mkdirs()
            FileOutputStream(file).use { out ->
                bitmap.compress(format, quality, out)
            }
            true
        } catch (e: Throwable) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Loads a JPEG/PNG from disk with its EXIF orientation applied, so a photo taken in portrait
     * looks portrait (BitmapFactory ignores EXIF by itself, which made captured pages appear rotated).
     * The longest edge is limited to [maxEdge] to keep memory use safe.
     */
    fun decodeOriented(path: String, maxEdge: Int = 3200): Bitmap? {
        return try {
            val file = File(path)
            if (!file.exists()) return null

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            val longest = max(bounds.outWidth, bounds.outHeight)
            if (longest <= 0) return null

            var sample = 1
            while (longest / (sample * 2) >= maxEdge) sample *= 2

            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            var bmp = BitmapFactory.decodeFile(path, opts) ?: return null

            // Exact downscale to maxEdge if still larger
            val curLongest = max(bmp.width, bmp.height)
            if (curLongest > maxEdge) {
                val s = maxEdge.toFloat() / curLongest
                val scaled = Bitmap.createScaledBitmap(
                    bmp,
                    (bmp.width * s).toInt().coerceAtLeast(1),
                    (bmp.height * s).toInt().coerceAtLeast(1),
                    true
                )
                if (scaled != bmp) bmp.recycle()
                bmp = scaled
            }

            val orientation = try {
                android.media.ExifInterface(path).getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION,
                    android.media.ExifInterface.ORIENTATION_NORMAL
                )
            } catch (e: Throwable) {
                android.media.ExifInterface.ORIENTATION_NORMAL
            }

            val m = Matrix()
            when (orientation) {
                android.media.ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                android.media.ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                android.media.ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                android.media.ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
                android.media.ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
                else -> {}
            }
            if (m.isIdentity) {
                bmp
            } else {
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (rotated != bmp) bmp.recycle()
                rotated
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Makes a freshly captured / imported photo "upright" on disk: applies EXIF rotation, rewrites
     * the file without needing EXIF afterwards, and returns a bitmap limited to [previewEdge].
     */
    suspend fun importPhoto(file: File, previewEdge: Int = 2400): Bitmap? = withContext(Dispatchers.IO) {
        val upright = decodeOriented(file.absolutePath, 4096) ?: return@withContext null
        try {
            FileOutputStream(file).use { out -> upright.compress(Bitmap.CompressFormat.JPEG, 95, out) }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
        val longest = max(upright.width, upright.height)
        if (longest <= previewEdge) {
            upright
        } else {
            val s = previewEdge.toFloat() / longest
            val small = Bitmap.createScaledBitmap(
                upright,
                (upright.width * s).toInt().coerceAtLeast(1),
                (upright.height * s).toInt().coerceAtLeast(1),
                true
            )
            if (small != upright) upright.recycle()
            small
        }
    }

    /** Returns a copy limited to [maxEdge] on its longest side (or the same bitmap if already small). */
    fun downscale(src: Bitmap, maxEdge: Int): Bitmap {
        val longest = max(src.width, src.height)
        if (longest <= maxEdge) return src
        val s = maxEdge.toFloat() / longest
        return Bitmap.createScaledBitmap(
            src,
            (src.width * s).toInt().coerceAtLeast(1),
            (src.height * s).toInt().coerceAtLeast(1),
            true
        )
    }

    /** Paints white circles (whiten brush). Points are normalised 0..1 positions on the bitmap. */
    fun paintWhiteSpots(src: Bitmap, points: List<Pair<Float, Float>>, radiusFraction: Float = 0.03f): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val paint = Paint().apply {
            color = Color.WHITE
            isAntiAlias = true
            style = Paint.Style.FILL
        }
        val r = out.width * radiusFraction
        for ((nx, ny) in points) {
            canvas.drawCircle(nx * out.width, ny * out.height, r, paint)
        }
        return out
    }

    suspend fun detectCorners(bitmap: Bitmap): Pair<CornerPoints, Boolean> = withContext(Dispatchers.Default) {
        detectCornersSync(bitmap, 320)
    }

    /**
     * Finds the paper (a large bright region against a darker background) and returns its four
     * corners as normalised coordinates. Steps: downscale -> blur -> Otsu threshold -> erode ->
     * biggest connected region -> extreme points give TL/TR/BR/BL.
     * Returns (corners, true) when a believable document was found, else an inset full-frame and false.
     */
    fun detectCornersSync(bitmap: Bitmap, maxDim: Int = 320): Pair<CornerPoints, Boolean> {
        val fallback = Pair(CornerPoints(0.04f, 0.04f, 0.96f, 0.04f, 0.96f, 0.96f, 0.04f, 0.96f), false)
        try {
            val w = bitmap.width
            val h = bitmap.height
            if (w < 16 || h < 16) return fallback

            val scale = min(1f, maxDim.toFloat() / max(w, h))
            val sw = (w * scale).toInt().coerceAtLeast(24)
            val sh = (h * scale).toInt().coerceAtLeast(24)
            val small = Bitmap.createScaledBitmap(bitmap, sw, sh, true)
            val px = IntArray(sw * sh)
            small.getPixels(px, 0, sw, 0, 0, sw, sh)
            if (small != bitmap) small.recycle()

            var luma = IntArray(sw * sh)
            for (i in px.indices) {
                val c = px[i]
                luma[i] = (((c shr 16) and 0xFF) * 77 + ((c shr 8) and 0xFF) * 150 + (c and 0xFF) * 29) shr 8
            }

            // Blur twice (3x3 box) so printed text melts into the paper tone
            repeat(2) { luma = boxBlur3(luma, sw, sh) }

            // Otsu threshold
            val hist = IntArray(256)
            for (v in luma) hist[v.coerceIn(0, 255)]++
            val total = luma.size
            var sumAll = 0L
            for (i in 0..255) sumAll += i.toLong() * hist[i]
            var sumB = 0L
            var wB = 0
            var bestVar = -1.0
            var otsu = 128
            for (t in 0..255) {
                wB += hist[t]
                if (wB == 0) continue
                val wF = total - wB
                if (wF == 0) break
                sumB += t.toLong() * hist[t]
                val mB = sumB.toDouble() / wB
                val mF = (sumAll - sumB).toDouble() / wF
                val between = wB.toDouble() * wF * (mB - mF) * (mB - mF)
                if (between > bestVar) {
                    bestVar = between
                    otsu = t
                }
            }
            // Slightly favour including shaded paper: move the threshold towards the dark class mean
            var darkSum = 0L
            var darkCnt = 0
            for (i in 0..otsu) { darkSum += i.toLong() * hist[i]; darkCnt += hist[i] }
            val darkMean = if (darkCnt > 0) (darkSum / darkCnt).toInt() else otsu / 2
            val threshold = darkMean + ((otsu - darkMean) * 0.8f).toInt()

            // Try bright-paper-on-dark first, then dark-paper-on-bright as a second chance
            for (invert in booleanArrayOf(false, true)) {
                var mask = BooleanArray(sw * sh) { if (invert) luma[it] < threshold else luma[it] >= threshold }
                mask = erode3(mask, sw, sh)

                val region = largestRegion(mask, sw, sh) ?: continue
                val areaFrac = region.count.toFloat() / (sw * sh)
                if (areaFrac < 0.10f || areaFrac > 0.985f) continue

                // Extreme points (average the few best pixels so a stray pixel cannot win)
                val corners = extremeCorners(region.pixels, sw, sh) ?: continue
                val cp = CornerPoints(
                    corners[0], corners[1], corners[2], corners[3],
                    corners[4], corners[5], corners[6], corners[7]
                )
                if (isSensibleQuad(cp, sw, sh)) return Pair(cp, true)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
        return fallback
    }

    private class Region(val pixels: IntArray, val count: Int)

    private fun boxBlur3(src: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(src.size)
        for (y in 0 until h) {
            val y0 = max(0, y - 1)
            val y1 = min(h - 1, y + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - 1)
                val x1 = min(w - 1, x + 1)
                var s = 0
                var n = 0
                for (yy in y0..y1) {
                    val row = yy * w
                    for (xx in x0..x1) { s += src[row + xx]; n++ }
                }
                out[y * w + x] = s / n
            }
        }
        return out
    }

    private fun erode3(mask: BooleanArray, w: Int, h: Int): BooleanArray {
        val out = BooleanArray(mask.size)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                var all = true
                loop@ for (yy in y - 1..y + 1) {
                    for (xx in x - 1..x + 1) {
                        if (!mask[yy * w + xx]) { all = false; break@loop }
                    }
                }
                out[y * w + x] = all
            }
        }
        // Keep pixels on the image border if their inner neighbour is set (paper touching the frame)
        for (x in 0 until w) {
            out[x] = mask[x] && mask[w + x]
            out[(h - 1) * w + x] = mask[(h - 1) * w + x] && mask[(h - 2) * w + x]
        }
        for (y in 0 until h) {
            out[y * w] = mask[y * w] && mask[y * w + 1]
            out[y * w + w - 1] = mask[y * w + w - 1] && mask[y * w + w - 2]
        }
        return out
    }

    private fun largestRegion(mask: BooleanArray, w: Int, h: Int): Region? {
        val visited = BooleanArray(mask.size)
        val queue = IntArray(mask.size)
        var bestPixels: IntArray? = null
        var bestCount = 0
        for (start in mask.indices) {
            if (!mask[start] || visited[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = true
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                if (x > 0) { val q = p - 1; if (mask[q] && !visited[q]) { visited[q] = true; queue[tail++] = q } }
                if (x < w - 1) { val q = p + 1; if (mask[q] && !visited[q]) { visited[q] = true; queue[tail++] = q } }
                if (y > 0) { val q = p - w; if (mask[q] && !visited[q]) { visited[q] = true; queue[tail++] = q } }
                if (y < h - 1) { val q = p + w; if (mask[q] && !visited[q]) { visited[q] = true; queue[tail++] = q } }
            }
            if (tail > bestCount) {
                bestCount = tail
                bestPixels = queue.copyOf(tail)
            }
        }
        return bestPixels?.let { Region(it, bestCount) }
    }

    /** Returns [tlX,tlY,trX,trY,brX,brY,blX,blY] normalised, or null. */
    private fun extremeCorners(pixels: IntArray, w: Int, h: Int): FloatArray? {
        if (pixels.isEmpty()) return null
        var minSum = Int.MAX_VALUE
        var maxSum = Int.MIN_VALUE
        var minDiff = Int.MAX_VALUE
        var maxDiff = Int.MIN_VALUE
        for (p in pixels) {
            val x = p % w
            val y = p / w
            val s = x + y
            val d = x - y
            if (s < minSum) minSum = s
            if (s > maxSum) maxSum = s
            if (d < minDiff) minDiff = d
            if (d > maxDiff) maxDiff = d
        }
        val tol = 1
        var tlx = 0f; var tly = 0f; var tln = 0
        var trx = 0f; var try_ = 0f; var trn = 0
        var brx = 0f; var bry = 0f; var brn = 0
        var blx = 0f; var bly = 0f; var bln = 0
        for (p in pixels) {
            val x = p % w
            val y = p / w
            val s = x + y
            val d = x - y
            if (s <= minSum + tol) { tlx += x; tly += y; tln++ }
            if (d >= maxDiff - tol) { trx += x; try_ += y; trn++ }
            if (s >= maxSum - tol) { brx += x; bry += y; brn++ }
            if (d <= minDiff + tol) { blx += x; bly += y; bln++ }
        }
        if (tln == 0 || trn == 0 || brn == 0 || bln == 0) return null
        fun nx(v: Float, n: Int) = ((v / n + 0.5f) / w).coerceIn(0f, 1f)
        fun ny(v: Float, n: Int) = ((v / n + 0.5f) / h).coerceIn(0f, 1f)
        return floatArrayOf(
            nx(tlx, tln), ny(tly, tln),
            nx(trx, trn), ny(try_, trn),
            nx(brx, brn), ny(bry, brn),
            nx(blx, bln), ny(bly, bln)
        )
    }

    private fun isSensibleQuad(c: CornerPoints, sw: Int, sh: Int): Boolean {
        val xs = floatArrayOf(c.tlX * sw, c.trX * sw, c.brX * sw, c.blX * sw)
        val ys = floatArrayOf(c.tlY * sh, c.trY * sh, c.brY * sh, c.blY * sh)
        var area2 = 0f
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            area2 += xs[i] * ys[j] - xs[j] * ys[i]
        }
        val area = kotlin.math.abs(area2) / 2f
        if (area < 0.10f * sw * sh) return false
        val minSide = 0.12f * min(sw, sh)
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            if (hypot(xs[i] - xs[j], ys[i] - ys[j]) < minSide) return false
        }
        // Convexity check: all cross products have the same sign
        var sign = 0
        for (i in 0 until 4) {
            val a = i
            val b = (i + 1) % 4
            val c2 = (i + 2) % 4
            val cross = (xs[b] - xs[a]) * (ys[c2] - ys[b]) - (ys[b] - ys[a]) * (xs[c2] - xs[b])
            val s = if (cross > 0) 1 else if (cross < 0) -1 else 0
            if (s != 0) {
                if (sign == 0) sign = s else if (sign != s) return false
            }
        }
        return true
    }

    /**
     * Warps a quadrilateral region defined by normalized corners to a flattened rectangular bitmap.
     * Uses Android's native Matrix.setPolyToPoly for high quality projective transformation.
     */
    suspend fun warpPerspective(original: Bitmap, corners: CornerPoints, maxEdge: Int? = 3000): Bitmap = withContext(Dispatchers.Default) {
        val ow = original.width.toFloat()
        val oh = original.height.toFloat()

        val srcPoints = floatArrayOf(
            corners.tlX * ow, corners.tlY * oh,
            corners.trX * ow, corners.trY * oh,
            corners.brX * ow, corners.brY * oh,
            corners.blX * ow, corners.blY * oh
        )

        // Output dimensions from corner distances
        val topWidth = hypot(srcPoints[2] - srcPoints[0], srcPoints[3] - srcPoints[1])
        val bottomWidth = hypot(srcPoints[4] - srcPoints[6], srcPoints[5] - srcPoints[7])
        val leftHeight = hypot(srcPoints[6] - srcPoints[0], srcPoints[7] - srcPoints[1])
        val rightHeight = hypot(srcPoints[4] - srcPoints[2], srcPoints[5] - srcPoints[3])

        var dstW = max(topWidth, bottomWidth).toInt().coerceAtLeast(100)
        var dstH = max(leftHeight, rightHeight).toInt().coerceAtLeast(100)

        if (maxEdge != null && max(dstW, dstH) > maxEdge) {
            val scale = maxEdge.toFloat() / max(dstW, dstH)
            dstW = (dstW * scale).toInt().coerceAtLeast(100)
            dstH = (dstH * scale).toInt().coerceAtLeast(100)
        }

        val dstPoints = floatArrayOf(
            0f, 0f,
            dstW.toFloat(), 0f,
            dstW.toFloat(), dstH.toFloat(),
            0f, dstH.toFloat()
        )

        val matrix = Matrix()
        matrix.setPolyToPoly(srcPoints, 0, dstPoints, 0, 4)

        val outBitmap = Bitmap.createBitmap(dstW, dstH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            isDither = true
        }

        canvas.drawBitmap(original, matrix, paint)
        outBitmap
    }

    /**
     * Applies filters, adjustments (brightness, contrast), rotation, flip and straighten.
     * "Scanner style" filters first flatten the paper's lighting (removes shadows / yellow cast),
     * then tune contrast, which gives the white-paper / dark-text look of CamScanner.
     */
    suspend fun applyFiltersAndEdits(
        bitmap: Bitmap,
        filter: FilterType,
        params: EditParameters,
        rotationDeg: Int = 0
    ): Bitmap = withContext(Dispatchers.Default) {
        // Step 1: geometry (flip, rotate, straighten)
        val matrix = Matrix()
        if (params.flipH || params.flipV) {
            matrix.postScale(
                if (params.flipH) -1f else 1f,
                if (params.flipV) -1f else 1f,
                bitmap.width / 2f,
                bitmap.height / 2f
            )
        }
        val totalRotation = (rotationDeg.toFloat() + params.straightenAngle)
        if (totalRotation != 0f) {
            matrix.postRotate(totalRotation, bitmap.width / 2f, bitmap.height / 2f)
        }

        var geometry: Bitmap = if (!matrix.isIdentity) {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else {
            bitmap
        }
        var ownsGeometry = geometry !== bitmap

        // Straightening leaves transparent corners: put the page on white paper
        if (params.straightenAngle != 0f && geometry.hasAlpha()) {
            val flat = Bitmap.createBitmap(geometry.width, geometry.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(flat)
            c.drawColor(Color.WHITE)
            c.drawBitmap(geometry, 0f, 0f, null)
            if (ownsGeometry) geometry.recycle()
            geometry = flat
            ownsGeometry = true
        }

        // Step 2: lighting normalisation for scanner style filters
        val normStrength = when (filter) {
            FilterType.MAGIC_COLOR -> 1.0f
            FilterType.DOCUMENT_BW -> 1.0f
            FilterType.BW2 -> 1.0f
            FilterType.REMOVE_SHADOW -> 1.0f
            FilterType.AUTO_ENHANCE -> 0.7f
            else -> 0f
        }
        var source: Bitmap = geometry
        var ownsSource = false
        if (normStrength > 0f) {
            source = normalizeBackground(geometry, normStrength)
            ownsSource = true
        }

        // Step 3: colour matrix per filter
        val colorMatrix = ColorMatrix()
        when (filter) {
            FilterType.ORIGINAL -> { }
            FilterType.MAGIC_COLOR -> {
                val sat = ColorMatrix(); sat.setSaturation(1.25f); colorMatrix.postConcat(sat)
                adjustContrast(colorMatrix, 1.30f)
            }
            FilterType.DOCUMENT_BW -> {
                val gray = ColorMatrix(); gray.setSaturation(0f); colorMatrix.postConcat(gray)
                adjustContrast(colorMatrix, 2.0f)
                adjustBrightness(colorMatrix, 10f)
            }
            FilterType.BW2 -> {
                val gray = ColorMatrix(); gray.setSaturation(0f); colorMatrix.postConcat(gray)
                adjustContrast(colorMatrix, 3.4f)
                adjustBrightness(colorMatrix, 20f)
            }
            FilterType.GRAYSCALE -> {
                val gray = ColorMatrix(); gray.setSaturation(0f); colorMatrix.postConcat(gray)
                adjustContrast(colorMatrix, 1.10f)
                adjustBrightness(colorMatrix, 6f)
            }
            FilterType.LIGHTEN -> {
                adjustBrightness(colorMatrix, 38f)
                adjustContrast(colorMatrix, 0.96f)
            }
            FilterType.AUTO_ENHANCE -> {
                val sat = ColorMatrix(); sat.setSaturation(1.10f); colorMatrix.postConcat(sat)
                adjustContrast(colorMatrix, 1.15f)
                adjustBrightness(colorMatrix, 6f)
            }
            FilterType.REMOVE_SHADOW -> {
                adjustContrast(colorMatrix, 1.08f)
            }
        }

        if (params.brightness != 0f) adjustBrightness(colorMatrix, params.brightness * 80f)
        if (params.contrast != 1f) adjustContrast(colorMatrix, params.contrast)

        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }
        canvas.drawBitmap(source, 0f, 0f, paint)

        if (ownsSource) source.recycle()
        if (ownsGeometry && geometry !== source && !geometry.isRecycled) geometry.recycle()

        result
    }

    /**
     * Estimates the paper's own brightness (a heavily smoothed, text-free copy of the page) and
     * divides it out. Shadows, uneven light and a yellow tint disappear; ink stays dark.
     */
    private fun normalizeBackground(src: Bitmap, strength: Float): Bitmap {
        val w = src.width
        val h = src.height
        val sw = max(8, w / 16)
        val sh = max(8, h / 16)

        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val sp = IntArray(sw * sh)
        small.getPixels(sp, 0, sw, 0, 0, sw, sh)
        if (small != src) small.recycle()

        var lum = IntArray(sw * sh)
        for (i in sp.indices) {
            val c = sp[i]
            lum[i] = (((c shr 16) and 0xFF) * 77 + ((c shr 8) and 0xFF) * 150 + (c and 0xFF) * 29) shr 8
        }
        // Max filter removes text strokes, box blur makes the estimate smooth
        repeat(2) { lum = maxFilter3(lum, sw, sh) }
        repeat(2) { lum = boxBlur3(lum, sw, sh) }

        val bgSmall = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val bp = IntArray(sw * sh)
        for (i in bp.indices) {
            val v = lum[i].coerceIn(0, 255)
            bp[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        bgSmall.setPixels(bp, 0, sw, 0, 0, sw, sh)
        val bg = Bitmap.createScaledBitmap(bgSmall, w, h, true)
        if (bg != bgSmall) bgSmall.recycle()
        val bgPx = IntArray(w * h)
        bg.getPixels(bgPx, 0, w, 0, 0, w, h)
        bg.recycle()

        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val b = (bgPx[i] and 0xFF).coerceAtLeast(100)
            val gain = 1f + (255f / b - 1f) * strength
            val r = (((c shr 16) and 0xFF) * gain).toInt().coerceAtMost(255)
            val g = (((c shr 8) and 0xFF) * gain).toInt().coerceAtMost(255)
            val bl = ((c and 0xFF) * gain).toInt().coerceAtMost(255)
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private fun maxFilter3(src: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(src.size)
        for (y in 0 until h) {
            val y0 = max(0, y - 1)
            val y1 = min(h - 1, y + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - 1)
                val x1 = min(w - 1, x + 1)
                var m = 0
                for (yy in y0..y1) {
                    val row = yy * w
                    for (xx in x0..x1) { if (src[row + xx] > m) m = src[row + xx] }
                }
                out[y * w + x] = m
            }
        }
        return out
    }

    private fun adjustBrightness(cm: ColorMatrix, value: Float) {
        val brightnessMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, value,
                0f, 1f, 0f, 0f, value,
                0f, 0f, 1f, 0f, value,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(brightnessMatrix)
    }

    private fun adjustContrast(cm: ColorMatrix, contrast: Float) {
        val scale = contrast
        val translate = (-0.5f * scale + 0.5f) * 255f
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(contrastMatrix)
    }

    /**
     * Renders a 300 DPI Passport Photo Sheet with neat grid and optional cut guidelines.
     */
    suspend fun renderPassportSheet(config: PassportConfig, photoBitmap: Bitmap): Bitmap = withContext(Dispatchers.Default) {
        val dpi = 300f
        val mmToPx = dpi / 25.4f

        val sheetW = (config.customSheetWidthMm * mmToPx).toInt().coerceAtLeast(300)
        val sheetH = (config.customSheetHeightMm * mmToPx).toInt().coerceAtLeast(300)

        val photoW = (config.customPhotoWidthMm * mmToPx).toInt().coerceAtLeast(100)
        val photoH = (config.customPhotoHeightMm * mmToPx).toInt().coerceAtLeast(100)

        val gapPx = (config.gapMm * mmToPx).toInt()
        val marginPx = (config.marginMm * mmToPx).toInt()

        val sheetBitmap = Bitmap.createBitmap(sheetW, sheetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheetBitmap)
        canvas.drawColor(Color.WHITE)

        val cols = ((sheetW - 2 * marginPx + gapPx) / (photoW + gapPx)).coerceAtLeast(1)
        val rows = ((sheetH - 2 * marginPx + gapPx) / (photoH + gapPx)).coerceAtLeast(1)

        val maxPossible = cols * rows
        val totalToDraw = if (config.isFitMaximum) maxPossible else config.copiesCount.coerceIn(1, maxPossible)

        val photoPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        val cutLinePaint = Paint().apply {
            color = 0xFFCCCCCC.toInt()
            strokeWidth = 2f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
        }

        var count = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (count >= totalToDraw) break
                val x = marginPx + c * (photoW + gapPx)
                val y = marginPx + r * (photoH + gapPx)

                val dstRect = Rect(x, y, x + photoW, y + photoH)
                canvas.drawBitmap(photoBitmap, null, dstRect, photoPaint)

                if (config.showCutLines) {
                    canvas.drawRect(
                        (x - 1).toFloat(),
                        (y - 1).toFloat(),
                        (x + photoW + 1).toFloat(),
                        (y + photoH + 1).toFloat(),
                        cutLinePaint
                    )
                }
                count++
            }
        }

        sheetBitmap
    }

    /**
     * Renders a blank composed page with multiple images and text objects in exact millimeter measurements.
     */
    suspend fun renderComposedPage(
        config: ComposedPageConfig,
        objects: List<ComposedObject>,
        dpi: Int = 300
    ): Bitmap = withContext(Dispatchers.Default) {
        val mmToPx = dpi / 25.4f

        val effectiveW = if (config.orientation == PageOrientation.PORTRAIT) config.widthMm else config.heightMm
        val effectiveH = if (config.orientation == PageOrientation.PORTRAIT) config.heightMm else config.widthMm

        val pageW = (effectiveW * mmToPx).toInt().coerceAtLeast(200)
        val pageH = (effectiveH * mmToPx).toInt().coerceAtLeast(200)

        val outBitmap = Bitmap.createBitmap(pageW, pageH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)
        canvas.drawColor(config.backgroundColor)

        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        val textPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        // Render objects in layer order
        val sortedObjects = objects.sortedBy { it.layer }

        for (obj in sortedObjects) {
            val ox = obj.xMm * mmToPx
            val oy = obj.yMm * mmToPx
            val ow = obj.widthMm * mmToPx
            val oh = obj.heightMm * mmToPx

            canvas.save()
            if (obj.rotationDeg != 0f) {
                canvas.rotate(obj.rotationDeg, ox + ow / 2f, oy + oh / 2f)
            }

            if (obj.type == ObjectType.IMAGE && obj.imagePath != null) {
                val img = loadBitmapFromFile(obj.imagePath)
                if (img != null) {
                    val dst = RectF(ox, oy, ox + ow, oy + oh)
                    canvas.drawBitmap(img, null, dst, paint)
                    img.recycle()
                }
            } else if (obj.type == ObjectType.TEXT && obj.text != null) {
                textPaint.color = obj.fontColor
                textPaint.textSize = obj.fontSizeSp * (dpi / 160f)
                canvas.drawText(obj.text, ox + 8f, oy + textPaint.textSize + 8f, textPaint)
            }

            if (obj.borderWidthMm > 0f) {
                borderPaint.color = obj.borderColor
                borderPaint.strokeWidth = obj.borderWidthMm * mmToPx
                canvas.drawRect(ox, oy, ox + ow, oy + oh, borderPaint)
            }

            canvas.restore()
        }

        outBitmap
    }

    /**
     * Generates a multi-page PDF document on the device using standard Android PdfDocument.
     */
    suspend fun generatePdf(bitmaps: List<Bitmap>, outputFile: File): Boolean = withContext(Dispatchers.IO) {
        try {
            outputFile.parentFile?.mkdirs()
            val pdfDocument = PdfDocument()

            for ((index, bmp) in bitmaps.withIndex()) {
                val pageInfo = PdfDocument.PageInfo.Builder(bmp.width, bmp.height, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas
                val paint = Paint().apply {
                    isAntiAlias = true
                    isFilterBitmap = true
                }
                canvas.drawBitmap(bmp, 0f, 0f, paint)
                pdfDocument.finishPage(page)
            }

            FileOutputStream(outputFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()
            true
        } catch (e: Throwable) {
            e.printStackTrace()
            false
        }
    }
}
