package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.view.WindowManager
import androidx.camera.core.AspectRatio
import androidx.camera.core.ImageAnalysis
import com.example.data.model.CornerPoints
import com.example.processing.ImageProcessor
import java.util.concurrent.Executors
import androidx.compose.runtime.key
import androidx.compose.runtime.rememberUpdatedState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.MeteringPointFactory
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat

/**
 * CameraPreview component using CameraX to display a real-time viewfinder in the UI.
 * Provides an optical document alignment viewfinder overlay, corner brackets, animated scan line,
 * tap-to-focus, pinch-to-zoom, and lifecycle-safe camera binding.
 */
@Composable
fun CameraPreview(
    modifier: Modifier = Modifier,
    lensFacing: Int = CameraSelector.LENS_FACING_BACK,
    isFlashOn: Boolean = false,
    guideText: String = "Align document within frame",
    foundText: String = "Document found — tap to capture",
    onCameraBound: (ImageCapture, CameraControl) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Check runtime camera permission
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    if (!hasCameraPermission) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Camera Permission Required",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Camera access is needed to scan documents in HD quality.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.testTag("request_camera_perm_btn")
                ) {
                    Text("Grant Permission")
                }
            }
        }
        return
    }

    var cameraControlRef by remember { mutableStateOf<CameraControl?>(null) }
    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }
    var tapFocusPoint by remember { mutableStateOf<Offset?>(null) }
    var currentZoomRatio by remember { mutableFloatStateOf(1f) }

    // Live document outline found by the analyser (normalised to the camera frame)
    var liveQuad by remember { mutableStateOf<LiveQuad?>(null) }

    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) {
        onDispose { analysisExecutor.shutdown() }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {

        key(lensFacing) {
            // CameraX Viewfinder Surface
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }
                    previewViewRef = previewView

                    @Suppress("DEPRECATION")
                    val displayRotation = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager)
                        .defaultDisplay.rotation

                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder()
                            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                            .setTargetRotation(displayRotation)
                            .build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }

                        val imageCapture = ImageCapture.Builder()
                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                            .setTargetRotation(displayRotation)
                            .setFlashMode(if (isFlashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
                            .build()

                        val analysis = ImageAnalysis.Builder()
                            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                            .setTargetRotation(displayRotation)
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                            .build()

                        val lastRun = longArrayOf(0L)
                        val misses = intArrayOf(0)
                        var previous: CornerPoints? = null
                        val mainExecutor = ContextCompat.getMainExecutor(ctx)

                        analysis.setAnalyzer(analysisExecutor) { proxy ->
                            try {
                                val now = SystemClock.elapsedRealtime()
                                if (now - lastRun[0] >= 160L) {
                                    lastRun[0] = now
                                    val raw = proxy.toBitmap()
                                    val rot = proxy.imageInfo.rotationDegrees
                                    val frame: Bitmap = if (rot != 0) {
                                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                                        Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                                    } else raw
                                    val fw = frame.width
                                    val fh = frame.height
                                    val (found, ok) = ImageProcessor.detectCornersSync(frame, 200)
                                    if (frame !== raw) frame.recycle()
                                    raw.recycle()

                                    if (ok) {
                                        misses[0] = 0
                                        val prev = previous
                                        val smooth = if (prev != null && cornerDistance(prev, found) < 0.18f) {
                                            blendCorners(prev, found, 0.5f)
                                        } else found
                                        previous = smooth
                                        mainExecutor.execute { liveQuad = LiveQuad(smooth, fw, fh) }
                                    } else {
                                        misses[0]++
                                        if (misses[0] >= 3) {
                                            previous = null
                                            mainExecutor.execute { liveQuad = null }
                                        }
                                    }
                                }
                            } catch (e: Throwable) {
                                e.printStackTrace()
                            } finally {
                                proxy.close()
                            }
                        }

                        val cameraSelector = CameraSelector.Builder()
                            .requireLensFacing(lensFacing)
                            .build()

                        try {
                            cameraProvider.unbindAll()
                            val camera: Camera = cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview,
                                imageCapture,
                                analysis
                            )
                            cameraControlRef = camera.cameraControl
                            onCameraBound(imageCapture, camera.cameraControl)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        // Tap to Focus gesture
                        detectTapGestures { offset ->
                            tapFocusPoint = offset
                            val pView = previewViewRef ?: return@detectTapGestures
                            val factory: MeteringPointFactory = pView.meteringPointFactory
                            val point = factory.createPoint(offset.x, offset.y)
                            val action = FocusMeteringAction.Builder(point).build()
                            cameraControlRef?.startFocusAndMetering(action)
                        }
                    }
                    .pointerInput(Unit) {
                        // Pinch to Zoom gesture
                        detectTransformGestures { _, _, zoom, _ ->
                            val newZoom = (currentZoomRatio * zoom).coerceIn(1f, 5f)
                            currentZoomRatio = newZoom
                            cameraControlRef?.setZoomRatio(newZoom)
                        }
                    }
                    .testTag("camerax_viewfinder_surface")
            )
        }

        // Live outline that follows the paper's real edges (no fixed frame)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height
            val quad = liveQuad

            if (quad != null) {
                // PreviewView uses FILL_CENTER: scale to cover, crop the overflow
                val s = maxOf(canvasW / quad.frameW, canvasH / quad.frameH)
                val dx = (canvasW - quad.frameW * s) / 2f
                val dy = (canvasH - quad.frameH * s) / 2f
                fun px(nx: Float) = dx + nx * quad.frameW * s
                fun py(ny: Float) = dy + ny * quad.frameH * s

                val c = quad.corners
                val pts = listOf(
                    Offset(px(c.tlX), py(c.tlY)),
                    Offset(px(c.trX), py(c.trY)),
                    Offset(px(c.brX), py(c.brY)),
                    Offset(px(c.blX), py(c.blY))
                )
                val path = Path().apply {
                    moveTo(pts[0].x, pts[0].y)
                    lineTo(pts[1].x, pts[1].y)
                    lineTo(pts[2].x, pts[2].y)
                    lineTo(pts[3].x, pts[3].y)
                    close()
                }
                drawPath(path, Color(0xFF10B981).copy(alpha = 0.18f))
                drawPath(path, Color(0xFF10B981), style = Stroke(width = 3.dp.toPx()))
                pts.forEach { p ->
                    drawCircle(Color(0xFF10B981), radius = 7.dp.toPx(), center = p)
                    drawCircle(Color.White, radius = 3.dp.toPx(), center = p)
                }
            }

            // Tap-to-focus ring indicator
            tapFocusPoint?.let { pt ->
                drawCircle(
                    color = Color(0xFFF59E0B),
                    radius = 28.dp.toPx(),
                    center = pt,
                    style = Stroke(width = 2.dp.toPx())
                )
                drawCircle(
                    color = Color.White,
                    radius = 4.dp.toPx(),
                    center = pt
                )
            }
        }

        // Guide text pill at the top
        Surface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 70.dp)
                .testTag("viewfinder_guide_pill"),
            color = Color.Black.copy(alpha = 0.65f),
            shape = CircleShape
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CropFree,
                    contentDescription = null,
                    tint = if (liveQuad != null) Color(0xFF10B981) else Color(0xFF38BDF8),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (liveQuad != null) foundText else guideText,
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

/** Document outline found in a camera frame of size frameW x frameH. */
private class LiveQuad(val corners: CornerPoints, val frameW: Int, val frameH: Int)

private fun cornerDistance(a: CornerPoints, b: CornerPoints): Float {
    val x = a.toNormalizedArray()
    val y = b.toNormalizedArray()
    var m = 0f
    for (i in x.indices) {
        val d = kotlin.math.abs(x[i] - y[i])
        if (d > m) m = d
    }
    return m
}

private fun blendCorners(old: CornerPoints, new: CornerPoints, newWeight: Float): CornerPoints {
    val o = old.toNormalizedArray()
    val n = new.toNormalizedArray()
    val r = FloatArray(8) { o[it] * (1f - newWeight) + n[it] * newWeight }
    return CornerPoints(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7])
}
