package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.data.model.EditParameters
import com.example.data.model.FilterType
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageEditorScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val activePage by viewModel.activeEditingPage.collectAsState()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }   // preview-size base
    var fullBitmap by remember { mutableStateOf<Bitmap?>(null) }       // full-size base used when saving
    var currentDisplayBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var recomputeJob by remember { mutableStateOf<Job?>(null) }
    var hasSignature by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    val filterThumbs = remember { mutableStateMapOf<FilterType, ImageBitmap>() }

    var filter by remember { mutableStateOf(FilterType.ORIGINAL) }
    var editParams by remember { mutableStateOf(EditParameters()) }
    var rotationDeg by remember { mutableStateOf(0) }

    var isHoldingCompare by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf(0) } // 0: Filters, 1: Adjust, 2: Transform, 3: Tools

    // History stack (at least 30 steps)
    val undoStack = remember { mutableStateListOf<Triple<FilterType, EditParameters, Int>>() }
    val redoStack = remember { mutableStateListOf<Triple<FilterType, EditParameters, Int>>() }

    // Whiten brush strokes
    // Brush points are stored as 0..1 positions on the picture, so they survive any screen size
    val whitenPoints = remember { mutableStateListOf<Offset>() }
    var isWhitenMode by remember { mutableStateOf(false) }

    // Signature dialog
    var showSignatureDialog by remember { mutableStateOf(false) }
    val signaturePoints = remember { mutableStateListOf<Offset>() }

    // Apply to all pages toggle
    var applyToAllPages by remember { mutableStateOf(false) }

    // Load initial page bitmap or working bitmap from crop
    LaunchedEffect(activePage, viewModel.editorWorkingBitmap) {
        val page = activePage
        if (page != null && page.originalImagePath.isNotBlank()) {
            val bmp = ImageProcessor.loadBitmapFromFile(page.originalImagePath, maxDimension = 2048)
            fullBitmap = bmp
            originalBitmap = bmp
            currentDisplayBitmap = bmp
            filter = try { FilterType.valueOf(page.filterType) } catch (e: Exception) { FilterType.ORIGINAL }
            rotationDeg = page.rotationDeg
        } else if (viewModel.editorWorkingBitmap != null) {
            val full = viewModel.editorWorkingBitmap!!
            // Work on a screen-sized copy so every filter tap is instant; the full copy is used on save
            val preview = ImageProcessor.downscale(full, 1500)
            fullBitmap = full
            originalBitmap = preview
            filter = FilterType.MAGIC_COLOR // CamScanner signature default
            rotationDeg = 0
            currentDisplayBitmap = ImageProcessor.applyFiltersAndEdits(preview, FilterType.MAGIC_COLOR, editParams, 0)
        }
    }

    // Small preview picture for every filter button
    LaunchedEffect(originalBitmap) {
        val base = originalBitmap ?: return@LaunchedEffect
        val small = ImageProcessor.downscale(base, 180)
        for (f in FilterType.values()) {
            val t = ImageProcessor.applyFiltersAndEdits(small, f, EditParameters(), 0)
            filterThumbs[f] = t.asImageBitmap()
        }
    }

    // Live update rendered preview (latest request wins)
    fun recomputePreview() {
        val base = originalBitmap ?: return
        recomputeJob?.cancel()
        hasSignature = false
        recomputeJob = coroutineScope.launch {
            val processed = ImageProcessor.applyFiltersAndEdits(base, filter, editParams, rotationDeg)
            currentDisplayBitmap = processed
        }
    }

    fun pushHistory() {
        if (undoStack.size >= 40) undoStack.removeAt(0)
        undoStack.add(Triple(filter, editParams, rotationDeg))
        redoStack.clear()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("page_editor_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    // Undo
                    IconButton(
                        onClick = {
                            if (undoStack.isNotEmpty()) {
                                redoStack.add(Triple(filter, editParams, rotationDeg))
                                val state = undoStack.removeLast()
                                filter = state.first
                                editParams = state.second
                                rotationDeg = state.third
                                recomputePreview()
                            }
                        },
                        enabled = undoStack.isNotEmpty(),
                        modifier = Modifier.testTag("editor_undo_btn")
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = I18n.get("undo", lang))
                    }

                    // Redo
                    IconButton(
                        onClick = {
                            if (redoStack.isNotEmpty()) {
                                undoStack.add(Triple(filter, editParams, rotationDeg))
                                val state = redoStack.removeLast()
                                filter = state.first
                                editParams = state.second
                                rotationDeg = state.third
                                recomputePreview()
                            }
                        },
                        enabled = redoStack.isNotEmpty(),
                        modifier = Modifier.testTag("editor_redo_btn")
                    ) {
                        Icon(Icons.Default.Redo, contentDescription = I18n.get("redo", lang))
                    }

                    // Save
                    TextButton(
                        enabled = !isSaving,
                        onClick = {
                            isSaving = true
                            coroutineScope.launch {
                                try {
                                    // Re-render from the full-size picture so the saved page stays sharp
                                    val src = fullBitmap ?: originalBitmap
                                    var bmpToSave: Bitmap? = if (hasSignature) {
                                        currentDisplayBitmap
                                    } else if (src != null) {
                                        ImageProcessor.applyFiltersAndEdits(src, filter, editParams, rotationDeg)
                                    } else {
                                        currentDisplayBitmap
                                    }
                                    if (bmpToSave == null) return@launch
                                    if (whitenPoints.isNotEmpty()) {
                                        bmpToSave = ImageProcessor.paintWhiteSpots(
                                            bmpToSave,
                                            whitenPoints.map { Pair(it.x, it.y) }
                                        )
                                    }

                                    val page = activePage
                                    if (page != null) {
                                        // Existing page update
                                        val origFile = File(page.originalImagePath)
                                        val thumbFile = File(page.thumbnailImagePath)
                                        ImageProcessor.saveBitmapToFile(bmpToSave, origFile)

                                        val thumb = Bitmap.createScaledBitmap(
                                            bmpToSave, 300,
                                            (300f * bmpToSave.height / bmpToSave.width).toInt().coerceAtLeast(50), true
                                        )
                                        ImageProcessor.saveBitmapToFile(thumb, thumbFile, quality = 80)

                                        val updatedPage = page.copy(
                                            filterType = filter.name,
                                            rotationDeg = rotationDeg
                                        )
                                        viewModel.repository.savePage(updatedPage)

                                        if (applyToAllPages) {
                                            val allDocPages = viewModel.repository.getPagesForDocumentSync(page.documentId)
                                            for (other in allDocPages) {
                                                if (other.id != page.id) {
                                                    viewModel.repository.savePage(other.copy(filterType = filter.name))
                                                }
                                            }
                                        }
                                        viewModel.refreshStorageInfo()
                                        viewModel.navigateBack()
                                    } else {
                                        // New capture flow
                                        viewModel.saveNewCapturedPage(
                                            bitmap = bmpToSave,
                                            filter = filter,
                                            editParams = editParams,
                                            rotationDeg = rotationDeg
                                        ) {
                                            // navigated to DocumentDetail
                                        }
                                    }
                                } finally {
                                    isSaving = false
                                }
                            }
                        },
                        modifier = Modifier.testTag("save_edits_btn")
                    ) {
                        Text(I18n.get("save", lang), fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(bottom = 8.dp)
                ) {
                    // Tab Row: Filters, Adjust, Transform, Tools
                    TabRow(selectedTabIndex = activeTab) {
                        Tab(
                            selected = activeTab == 0,
                            onClick = { activeTab = 0 },
                            text = { Text("Filters") }
                        )
                        Tab(
                            selected = activeTab == 1,
                            onClick = { activeTab = 1 },
                            text = { Text("Adjust") }
                        )
                        Tab(
                            selected = activeTab == 2,
                            onClick = { activeTab = 2 },
                            text = { Text("Transform") }
                        )
                        Tab(
                            selected = activeTab == 3,
                            onClick = { activeTab = 3 },
                            text = { Text("Tools") }
                        )
                    }

                    when (activeTab) {
                        0 -> {
                            // Filters List
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    val camFilters = listOf(
                                        FilterType.MAGIC_COLOR,
                                        FilterType.ORIGINAL,
                                        FilterType.DOCUMENT_BW,
                                        FilterType.BW2,
                                        FilterType.GRAYSCALE,
                                        FilterType.LIGHTEN,
                                        FilterType.AUTO_ENHANCE,
                                        FilterType.REMOVE_SHADOW
                                    )
                                    camFilters.forEach { f ->
                                        val labelKey = when (f) {
                                            FilterType.ORIGINAL -> "filter_original"
                                            FilterType.MAGIC_COLOR -> "filter_magic_color"
                                            FilterType.DOCUMENT_BW -> "filter_doc_bw"
                                            FilterType.BW2 -> "filter_bw2"
                                            FilterType.GRAYSCALE -> "filter_grayscale"
                                            FilterType.LIGHTEN -> "filter_lighten"
                                            FilterType.AUTO_ENHANCE -> "filter_auto_enhance"
                                            FilterType.REMOVE_SHADOW -> "filter_remove_shadow"
                                        }
                                        val selected = filter == f
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier
                                                .width(72.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .clickable {
                                                    pushHistory()
                                                    filter = f
                                                    recomputePreview()
                                                }
                                                .testTag("filter_chip_${f.name}")
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(68.dp, 88.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color.White)
                                                    .border(
                                                        if (selected) 3.dp else 1.dp,
                                                        if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                                        RoundedCornerShape(8.dp)
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                val thumb = filterThumbs[f]
                                                if (thumb != null) {
                                                    Image(
                                                        bitmap = thumb,
                                                        contentDescription = null,
                                                        contentScale = ContentScale.Fit,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                } else {
                                                    CircularProgressIndicator(
                                                        modifier = Modifier.size(20.dp),
                                                        strokeWidth = 2.dp
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = I18n.get(labelKey, lang),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(
                                            checked = applyToAllPages,
                                            onCheckedChange = { applyToAllPages = it }
                                        )
                                        Text(I18n.get("apply_all_pages", lang), style = MaterialTheme.typography.bodySmall)
                                    }

                                    // Reset to original button
                                    TextButton(onClick = {
                                        pushHistory()
                                        filter = FilterType.ORIGINAL
                                        editParams = EditParameters()
                                        rotationDeg = 0
                                        whitenPoints.clear()
                                        recomputePreview()
                                    }) {
                                        Text(I18n.get("reset_original", lang))
                                    }
                                }
                            }
                        }
                        1 -> {
                            // Adjust: Brightness, Contrast, Sharpness
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    "${I18n.get("brightness", lang)}: ${(editParams.brightness * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Slider(
                                    value = editParams.brightness,
                                    onValueChange = {
                                        editParams = editParams.copy(brightness = it)
                                        recomputePreview()
                                    },
                                    onValueChangeFinished = { pushHistory() },
                                    valueRange = -1f..1f,
                                    modifier = Modifier.testTag("brightness_slider")
                                )

                                Text(
                                    "${I18n.get("contrast", lang)}: ${(editParams.contrast * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Slider(
                                    value = editParams.contrast,
                                    onValueChange = {
                                        editParams = editParams.copy(contrast = it)
                                        recomputePreview()
                                    },
                                    onValueChangeFinished = { pushHistory() },
                                    valueRange = 0.5f..2.5f,
                                    modifier = Modifier.testTag("contrast_slider")
                                )
                            }
                        }
                        2 -> {
                            // Transform: Rotate 90, Straighten, Flip H, Flip V
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            pushHistory()
                                            rotationDeg = (rotationDeg + 90) % 360
                                            whitenPoints.clear()
                                            recomputePreview()
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.RotateRight, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(I18n.get("rotate_90", lang), style = MaterialTheme.typography.bodySmall)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            pushHistory()
                                            editParams = editParams.copy(flipH = !editParams.flipH)
                                            whitenPoints.clear()
                                            recomputePreview()
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(I18n.get("flip_h", lang), style = MaterialTheme.typography.bodySmall)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            pushHistory()
                                            editParams = editParams.copy(flipV = !editParams.flipV)
                                            whitenPoints.clear()
                                            recomputePreview()
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(I18n.get("flip_v", lang), style = MaterialTheme.typography.bodySmall)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    "${I18n.get("straighten", lang)}: ${editParams.straightenAngle.toInt()}°",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Slider(
                                    value = editParams.straightenAngle,
                                    onValueChange = {
                                        editParams = editParams.copy(straightenAngle = it)
                                        whitenPoints.clear()
                                        recomputePreview()
                                    },
                                    onValueChangeFinished = { pushHistory() },
                                    valueRange = -45f..45f
                                )
                            }
                        }
                        3 -> {
                            // Tools: Whiten Area (Eraser), Signature, Add Text
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = isWhitenMode,
                                    onClick = { isWhitenMode = !isWhitenMode },
                                    label = { Text(I18n.get("whiten_brush", lang)) },
                                    leadingIcon = { Icon(Icons.Default.AutoFixHigh, contentDescription = null) },
                                    modifier = Modifier.weight(1f)
                                )

                                if (whitenPoints.isNotEmpty()) {
                                    TextButton(onClick = { whitenPoints.clear() }) {
                                        Text(I18n.get("reset", lang))
                                    }
                                }

                                Button(
                                    onClick = { showSignatureDialog = true },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Draw, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(I18n.get("signature_tool", lang), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            val bmpToDisplay = if (isHoldingCompare) originalBitmap else currentDisplayBitmap
            val displayState = rememberUpdatedState(bmpToDisplay)
            // The brush only paints while the Tools tab is open and the brush is switched on,
            // so ordinary touches on the picture never leave marks.
            val brushActive = isWhitenMode && activeTab == 3 && !isHoldingCompare

            if (bmpToDisplay != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(brushActive) {
                                if (brushActive) {
                                    detectDragGestures { change, _ ->
                                        change.consume()
                                        val b = displayState.value ?: return@detectDragGestures
                                        val sc = minOf(size.width.toFloat() / b.width, size.height.toFloat() / b.height)
                                        val dw = b.width * sc
                                        val dh = b.height * sc
                                        val ox = (size.width - dw) / 2f
                                        val oy = (size.height - dh) / 2f
                                        val nx = (change.position.x - ox) / dw
                                        val ny = (change.position.y - oy) / dh
                                        if (nx in 0f..1f && ny in 0f..1f) {
                                            whitenPoints.add(Offset(nx, ny))
                                        }
                                    }
                                }
                            }
                    ) {
                        val scale = minOf(size.width / bmpToDisplay.width, size.height / bmpToDisplay.height)
                        val dw = bmpToDisplay.width * scale
                        val dh = bmpToDisplay.height * scale
                        val ox = (size.width - dw) / 2f
                        val oy = (size.height - dh) / 2f

                        drawImage(
                            image = bmpToDisplay.asImageBitmap(),
                            dstOffset = IntOffset(ox.toInt(), oy.toInt()),
                            dstSize = IntSize(dw.toInt(), dh.toInt())
                        )

                        // Whiten brush marks (same size/position as they will be saved)
                        if (!isHoldingCompare) {
                            for (p in whitenPoints) {
                                drawCircle(
                                    color = Color.White,
                                    radius = dw * 0.03f,
                                    center = Offset(ox + p.x * dw, oy + p.y * dh)
                                )
                            }
                        }
                    }
                }
            }

            // Hold-to-compare Floating Pill
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                isHoldingCompare = event.changes.any { it.pressed }
                            }
                        }
                    }
                    .testTag("hold_to_compare_btn"),
                color = if (isHoldingCompare) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.6f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Compare,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isHoldingCompare) "Showing Original" else I18n.get("hold_to_compare", lang),
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
    }

    // Drawn Signature Dialog
    if (showSignatureDialog) {
        AlertDialog(
            onDismissRequest = { showSignatureDialog = false },
            title = { Text(I18n.get("signature_tool", lang)) },
            text = {
                Column {
                    Text("Sign your name below:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .pointerInput(Unit) {
                                detectDragGestures { change, _ ->
                                    change.consume()
                                    signaturePoints.add(change.position)
                                }
                            }
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            for (i in 0 until signaturePoints.size - 1) {
                                val p1 = signaturePoints[i]
                                val p2 = signaturePoints[i + 1]
                                if ((p2 - p1).getDistance() < 80f) {
                                    drawLine(
                                        color = Color.Black,
                                        start = p1,
                                        end = p2,
                                        strokeWidth = 6f
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(onClick = { signaturePoints.clear() }) {
                        Text(I18n.get("clear_signature", lang))
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    showSignatureDialog = false
                    // Apply signature into working bitmap
                    val base = currentDisplayBitmap
                    if (base != null && signaturePoints.isNotEmpty()) {
                        val signedBmp = base.copy(Bitmap.Config.ARGB_8888, true)
                        val canvas = android.graphics.Canvas(signedBmp)
                        val paint = android.graphics.Paint().apply {
                            color = android.graphics.Color.BLACK
                            strokeWidth = 10f
                            isAntiAlias = true
                        }
                        val scaleX = base.width / 400f
                        val scaleY = base.height / 300f
                        val startOffsetY = base.height - 250f
                        for (i in 0 until signaturePoints.size - 1) {
                            val p1 = signaturePoints[i]
                            val p2 = signaturePoints[i + 1]
                            if ((p2 - p1).getDistance() < 80f) {
                                canvas.drawLine(
                                    p1.x * scaleX, startOffsetY + p1.y * 0.4f,
                                    p2.x * scaleX, startOffsetY + p2.y * 0.4f,
                                    paint
                                )
                            }
                        }
                        currentDisplayBitmap = signedBmp
                        hasSignature = true
                        pushHistory()
                    }
                }) {
                    Text(I18n.get("done", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignatureDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }
}
