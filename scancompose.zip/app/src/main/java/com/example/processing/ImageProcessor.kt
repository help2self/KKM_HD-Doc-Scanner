package com.example.processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.example.data.model.ComposedObject
import com.example.data.model.ComposedPageConfig
import com.example.data.model.CornerPoints
import com.example.data.model.EditParameters
import com.example.data.model.FilterType
import com.example.data.model.ObjectType
import com.example.data.model.PageOrientation
import com.example.data.model.PassportConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object ImageProcessor {

    suspend fun loadBitmapFromFile(path: String, maxDimension: Int? = null): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            if (!file.exists()) return@withContext null

            if (maxDimension == null) {
                return@withContext BitmapFactory.decodeFile(path)
            }

            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, options)

            var sampleSize = 1
            val maxEdge = max(options.outWidth, options.outHeight)
            while (maxEdge / (sampleSize * 2) >= maxDimension) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(path, decodeOptions)
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    suspend fun saveBitmapToFile(bitmap: Bitmap, file: File, format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG, quality: Int = 92): Boolean = withContext(Dispatchers.IO) {
        try {
            file.parentFile?.mkdirs()
            FileOutputStream(file).use { out ->
                bitmap.compress(format, quality, out)
            }
            true
        } catch (e: Throwable) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Auto-crops document corners using fast contrast & edge analysis on a downscaled copy.
     * Returns Pair<CornerPoints, Boolean> where boolean is true if document was detected,
     * or false if detection failed (which triggers the manual corner editor fallback).
     */
    suspend fun detectCorners(bitmap: Bitmap): Pair<CornerPoints, Boolean> = withContext(Dispatchers.Default) {
        val w = bitmap.width
        val h = bitmap.height

        // Downscale to max 320 for rapid analysis
        val scale = 320f / max(w, h).toFloat()
        val sw = (w * scale).toInt().coerceAtLeast(32)
        val sh = (h * scale).toInt().coerceAtLeast(32)

        val small = Bitmap.createScaledBitmap(bitmap, sw, sh, false)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        if (small != bitmap) small.recycle()

        // Grayscale & Sobel-like edge energy
        val luma = FloatArray(sw * sh)
        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            luma[i] = 0.299f * r + 0.587f * g + 0.114f * b
        }

        // Find edge bounding region by scanning inward from borders
        var left = 0
        var top = 0
        var right = sw - 1
        var bottom = sh - 1

        val threshold = 18f
        var foundTop = false
        for (y in 2 until sh / 3) {
            var diff = 0f
            for (x in sw / 4 until 3 * sw / 4) {
                diff += kotlin.math.abs(luma[y * sw + x] - luma[(y - 2) * sw + x])
            }
            if (diff / (sw / 2) > threshold) {
                top = y
                foundTop = true
                break
            }
        }

        var foundBottom = false
        for (y in sh - 3 downTo 2 * sh / 3) {
            var diff = 0f
            for (x in sw / 4 until 3 * sw / 4) {
                diff += kotlin.math.abs(luma[y * sw + x] - luma[(y + 2) * sw + x])
            }
            if (diff / (sw / 2) > threshold) {
                bottom = y
                foundBottom = true
                break
            }
        }

        var foundLeft = false
        for (x in 2 until sw / 3) {
            var diff = 0f
            for (y in sh / 4 until 3 * sh / 4) {
                diff += kotlin.math.abs(luma[y * sw + x] - luma[y * sw + (x - 2)])
            }
            if (diff / (sh / 2) > threshold) {
                left = x
                foundLeft = true
                break
            }
        }

        var foundRight = false
        for (x in sw - 3 downTo 2 * sw / 3) {
            var diff = 0f
            for (y in sh / 4 until 3 * sh / 4) {
                diff += kotlin.math.abs(luma[y * sw + x] - luma[y * sw + (x + 2)])
            }
            if (diff / (sh / 2) > threshold) {
                right = x
                foundRight = true
                break
            }
        }

        val areaFraction = ((right - left).toFloat() * (bottom - top).toFloat()) / (sw * sh)

        // Check if confidence is sufficient and area >= 20%
        val success = (foundTop || foundBottom || foundLeft || foundRight) && areaFraction >= 0.22f

        if (!success) {
            // Graceful fallback to whole page
            return@withContext Pair(CornerPoints.defaultFull(), false)
        }

        // Return detected corners with subtle inset
        val tlX = (left.toFloat() / sw).coerceIn(0.02f, 0.4f)
        val tlY = (top.toFloat() / sh).coerceIn(0.02f, 0.4f)
        val trX = (right.toFloat() / sw).coerceIn(0.6f, 0.98f)
        val trY = (top.toFloat() / sh).coerceIn(0.02f, 0.4f)
        val brX = (right.toFloat() / sw).coerceIn(0.6f, 0.98f)
        val brY = (bottom.toFloat() / sh).coerceIn(0.6f, 0.98f)
        val blX = (left.toFloat() / sw).coerceIn(0.02f, 0.4f)
        val blY = (bottom.toFloat() / sh).coerceIn(0.6f, 0.98f)

        Pair(
            CornerPoints(tlX, tlY, trX, trY, brX, brY, blX, blY),
            true
        )
    }

    /**
     * Warps a quadrilateral region defined by normalized corners to a flattened rectangular bitmap.
     * Uses Android's native Matrix.setPolyToPoly for high quality projective transformation.
     */
    suspend fun warpPerspective(original: Bitmap, corners: CornerPoints, maxEdge: Int? = null): Bitmap = withContext(Dispatchers.Default) {
        val ow = original.width.toFloat()
        val oh = original.height.toFloat()

        val srcPoints = floatArrayOf(
            corners.tlX * ow, corners.tlY * oh,
            corners.trX * ow, corners.trY * oh,
            corners.brX * ow, corners.brY * oh,
            corners.blX * ow, corners.blY * oh
        )

        // Output dimensions from corner distances
        val topWidth = hypot(srcPoints[2] - srcPoints[0], srcPoints[3] - srcPoints[1])
        val bottomWidth = hypot(srcPoints[4] - srcPoints[6], srcPoints[5] - srcPoints[7])
        val leftHeight = hypot(srcPoints[6] - srcPoints[0], srcPoints[7] - srcPoints[1])
        val rightHeight = hypot(srcPoints[4] - srcPoints[2], srcPoints[5] - srcPoints[3])

        var dstW = max(topWidth, bottomWidth).toInt().coerceAtLeast(100)
        var dstH = max(leftHeight, rightHeight).toInt().coerceAtLeast(100)

        if (maxEdge != null && max(dstW, dstH) > maxEdge) {
            val scale = maxEdge.toFloat() / max(dstW, dstH)
            dstW = (dstW * scale).toInt().coerceAtLeast(100)
            dstH = (dstH * scale).toInt().coerceAtLeast(100)
        }

        val dstPoints = floatArrayOf(
            0f, 0f,
            dstW.toFloat(), 0f,
            dstW.toFloat(), dstH.toFloat(),
            0f, dstH.toFloat()
        )

        val matrix = Matrix()
        matrix.setPolyToPoly(srcPoints, 0, dstPoints, 0, 4)

        val outBitmap = Bitmap.createBitmap(dstW, dstH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            isDither = true
        }

        canvas.drawBitmap(original, matrix, paint)
        outBitmap
    }

    /**
     * Applies filters, adjustments (brightness, contrast, sharpness), rotation and flip.
     */
    suspend fun applyFiltersAndEdits(
        bitmap: Bitmap,
        filter: FilterType,
        params: EditParameters,
        rotationDeg: Int = 0
    ): Bitmap = withContext(Dispatchers.Default) {
        // Step 1: Base matrix for rotation, straighten, and flip
        val matrix = Matrix()
        if (params.flipH || params.flipV) {
            matrix.postScale(
                if (params.flipH) -1f else 1f,
                if (params.flipV) -1f else 1f,
                bitmap.width / 2f,
                bitmap.height / 2f
            )
        }
        val totalRotation = (rotationDeg.toFloat() + params.straightenAngle)
        if (totalRotation != 0f) {
            matrix.postRotate(totalRotation, bitmap.width / 2f, bitmap.height / 2f)
        }

        // Apply geometric transform first if needed
        val transformed = if (!matrix.isIdentity) {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else {
            bitmap.copy(Bitmap.Config.ARGB_8888, true)
        }

        // Step 2: ColorMatrix based filtering
        val colorMatrix = ColorMatrix()

        // Filter presets
        when (filter) {
            FilterType.ORIGINAL -> {
                // Identity
            }
            FilterType.AUTO_ENHANCE -> {
                // Boost contrast and vibrant color
                val cm = ColorMatrix()
                cm.setScale(1.12f, 1.12f, 1.12f, 1f)
                colorMatrix.postConcat(cm)
                adjustContrast(colorMatrix, 1.18f)
                adjustBrightness(colorMatrix, 10f)
            }
            FilterType.DOCUMENT_BW -> {
                // High contrast document binarization style
                val gray = ColorMatrix()
                gray.setSaturation(0f)
                colorMatrix.postConcat(gray)
                adjustContrast(colorMatrix, 2.2f)
                adjustBrightness(colorMatrix, 25f)
            }
            FilterType.GRAYSCALE -> {
                val gray = ColorMatrix()
                gray.setSaturation(0f)
                colorMatrix.postConcat(gray)
                adjustContrast(colorMatrix, 1.05f)
            }
            FilterType.MAGIC_COLOR -> {
                // CamScanner Magic Color: high saturation + crisp black/white stretch
                val sat = ColorMatrix()
                sat.setSaturation(1.4f)
                colorMatrix.postConcat(sat)
                adjustContrast(colorMatrix, 1.25f)
                adjustBrightness(colorMatrix, 15f)
            }
            FilterType.LIGHTEN -> {
                adjustBrightness(colorMatrix, 40f)
                adjustContrast(colorMatrix, 0.95f)
            }
            FilterType.REMOVE_SHADOW -> {
                // Shadows lifted
                adjustBrightness(colorMatrix, 30f)
                adjustContrast(colorMatrix, 1.4f)
            }
        }

        // Additional user sliders
        if (params.brightness != 0f) {
            adjustBrightness(colorMatrix, params.brightness * 80f)
        }
        if (params.contrast != 1f) {
            adjustContrast(colorMatrix, params.contrast)
        }

        val resultBitmap = Bitmap.createBitmap(transformed.width, transformed.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(resultBitmap)
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }
        canvas.drawBitmap(transformed, 0f, 0f, paint)

        if (transformed != bitmap) {
            transformed.recycle()
        }

        resultBitmap
    }

    private fun adjustBrightness(cm: ColorMatrix, value: Float) {
        val brightnessMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, value,
                0f, 1f, 0f, 0f, value,
                0f, 0f, 1f, 0f, value,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(brightnessMatrix)
    }

    private fun adjustContrast(cm: ColorMatrix, contrast: Float) {
        val scale = contrast
        val translate = (-0.5f * scale + 0.5f) * 255f
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(contrastMatrix)
    }

    /**
     * Renders a 300 DPI Passport Photo Sheet with neat grid and optional cut guidelines.
     */
    suspend fun renderPassportSheet(config: PassportConfig, photoBitmap: Bitmap): Bitmap = withContext(Dispatchers.Default) {
        val dpi = 300f
        val mmToPx = dpi / 25.4f

        val sheetW = (config.customSheetWidthMm * mmToPx).toInt().coerceAtLeast(300)
        val sheetH = (config.customSheetHeightMm * mmToPx).toInt().coerceAtLeast(300)

        val photoW = (config.customPhotoWidthMm * mmToPx).toInt().coerceAtLeast(100)
        val photoH = (config.customPhotoHeightMm * mmToPx).toInt().coerceAtLeast(100)

        val gapPx = (config.gapMm * mmToPx).toInt()
        val marginPx = (config.marginMm * mmToPx).toInt()

        val sheetBitmap = Bitmap.createBitmap(sheetW, sheetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheetBitmap)
        canvas.drawColor(Color.WHITE)

        val cols = ((sheetW - 2 * marginPx + gapPx) / (photoW + gapPx)).coerceAtLeast(1)
        val rows = ((sheetH - 2 * marginPx + gapPx) / (photoH + gapPx)).coerceAtLeast(1)

        val maxPossible = cols * rows
        val totalToDraw = if (config.isFitMaximum) maxPossible else config.copiesCount.coerceIn(1, maxPossible)

        val photoPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        val cutLinePaint = Paint().apply {
            color = 0xFFCCCCCC.toInt()
            strokeWidth = 2f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
        }

        var count = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (count >= totalToDraw) break
                val x = marginPx + c * (photoW + gapPx)
                val y = marginPx + r * (photoH + gapPx)

                val dstRect = Rect(x, y, x + photoW, y + photoH)
                canvas.drawBitmap(photoBitmap, null, dstRect, photoPaint)

                if (config.showCutLines) {
                    canvas.drawRect(
                        (x - 1).toFloat(),
                        (y - 1).toFloat(),
                        (x + photoW + 1).toFloat(),
                        (y + photoH + 1).toFloat(),
                        cutLinePaint
                    )
                }
                count++
            }
        }

        sheetBitmap
    }

    /**
     * Renders a blank composed page with multiple images and text objects in exact millimeter measurements.
     */
    suspend fun renderComposedPage(
        config: ComposedPageConfig,
        objects: List<ComposedObject>,
        dpi: Int = 300
    ): Bitmap = withContext(Dispatchers.Default) {
        val mmToPx = dpi / 25.4f

        val effectiveW = if (config.orientation == PageOrientation.PORTRAIT) config.widthMm else config.heightMm
        val effectiveH = if (config.orientation == PageOrientation.PORTRAIT) config.heightMm else config.widthMm

        val pageW = (effectiveW * mmToPx).toInt().coerceAtLeast(200)
        val pageH = (effectiveH * mmToPx).toInt().coerceAtLeast(200)

        val outBitmap = Bitmap.createBitmap(pageW, pageH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)
        canvas.drawColor(config.backgroundColor)

        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        val textPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        // Render objects in layer order
        val sortedObjects = objects.sortedBy { it.layer }

        for (obj in sortedObjects) {
            val ox = obj.xMm * mmToPx
            val oy = obj.yMm * mmToPx
            val ow = obj.widthMm * mmToPx
            val oh = obj.heightMm * mmToPx

            canvas.save()
            if (obj.rotationDeg != 0f) {
                canvas.rotate(obj.rotationDeg, ox + ow / 2f, oy + oh / 2f)
            }

            if (obj.type == ObjectType.IMAGE && obj.imagePath != null) {
                val img = loadBitmapFromFile(obj.imagePath)
                if (img != null) {
                    val dst = RectF(ox, oy, ox + ow, oy + oh)
                    canvas.drawBitmap(img, null, dst, paint)
                    img.recycle()
                }
            } else if (obj.type == ObjectType.TEXT && obj.text != null) {
                textPaint.color = obj.fontColor
                textPaint.textSize = obj.fontSizeSp * (dpi / 160f)
                canvas.drawText(obj.text, ox + 8f, oy + textPaint.textSize + 8f, textPaint)
            }

            if (obj.borderWidthMm > 0f) {
                borderPaint.color = obj.borderColor
                borderPaint.strokeWidth = obj.borderWidthMm * mmToPx
                canvas.drawRect(ox, oy, ox + ow, oy + oh, borderPaint)
            }

            canvas.restore()
        }

        outBitmap
    }

    /**
     * Generates a multi-page PDF document on the device using standard Android PdfDocument.
     */
    suspend fun generatePdf(bitmaps: List<Bitmap>, outputFile: File): Boolean = withContext(Dispatchers.IO) {
        try {
            outputFile.parentFile?.mkdirs()
            val pdfDocument = PdfDocument()

            for ((index, bmp) in bitmaps.withIndex()) {
                val pageInfo = PdfDocument.PageInfo.Builder(bmp.width, bmp.height, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas
                val paint = Paint().apply {
                    isAntiAlias = true
                    isFilterBitmap = true
                }
                canvas.drawBitmap(bmp, 0f, 0f, paint)
                pdfDocument.finishPage(page)
            }

            FileOutputStream(outputFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()
            true
        } catch (e: Throwable) {
            e.printStackTrace()
            false
        }
    }
}
