package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.data.model.CornerPoints
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CornerEditorScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val corners by viewModel.cornerPoints.collectAsState()
    val autoDetectFailed by viewModel.autoDetectFailedMessage.collectAsState()

    val sourceBitmap = viewModel.cornerEditingBitmap

    // Canvas display bounds
    var canvasSize by remember { mutableStateOf(IntSize(1, 1)) }
    var activeHandleIndex by remember { mutableStateOf<Int?>(null) } // 0: TL, 1: TR, 2: BR, 3: BL

    // Handle touch size
    val handleRadiusPx = 36f

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("corner_editor_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            // Update corner points back to the current batch item
                            viewModel.batchItems.value = viewModel.batchItems.value.map { item ->
                                if (item.originalFile.absolutePath == viewModel.cornerEditingPath) {
                                    item.copy(corners = corners, autoCropSuccess = true)
                                } else item
                            }
                            viewModel.navigateBack()
                        },
                        modifier = Modifier.testTag("confirm_crop_btn")
                    ) {
                        Text(I18n.get("done", lang), fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    // Actions row: Select whole page, Re-detect, Reset
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.cornerPoints.value = CornerPoints.defaultFull()
                            },
                            modifier = Modifier.weight(1f).testTag("select_whole_page_btn")
                        ) {
                            Text(I18n.get("select_whole_page", lang), style = MaterialTheme.typography.bodySmall)
                        }

                        OutlinedButton(
                            onClick = {
                                if (sourceBitmap != null) {
                                    coroutineScope.launch {
                                        val (pts, success) = ImageProcessor.detectCorners(sourceBitmap)
                                        viewModel.cornerPoints.value = pts
                                        viewModel.autoDetectFailedMessage.value = !success
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("re_detect_btn")
                        ) {
                            Text(I18n.get("re_detect", lang), style = MaterialTheme.typography.bodySmall)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.cornerPoints.value = CornerPoints.defaultFull()
                            },
                            modifier = Modifier.weight(1f).testTag("reset_corners_btn")
                        ) {
                            Text(I18n.get("reset", lang), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Auto detect failed notification banner if applicable
            if (autoDetectFailed) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth().testTag("auto_detect_failed_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = I18n.get("auto_detect_failed", lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF1E293B))
                    .onGloballyPositioned { coordinates ->
                        canvasSize = coordinates.size
                    }
            ) {
                if (sourceBitmap != null && canvasSize.width > 1 && canvasSize.height > 1) {
                    val cw = canvasSize.width.toFloat()
                    val ch = canvasSize.height.toFloat()

                    // Compute aspect ratio fit
                    val bmpW = sourceBitmap.width.toFloat()
                    val bmpH = sourceBitmap.height.toFloat()
                    val scale = minOf(cw / bmpW, ch / bmpH) * 0.92f

                    val drawW = bmpW * scale
                    val drawH = bmpH * scale
                    val offsetX = (cw - drawW) / 2f
                    val offsetY = (ch - drawH) / 2f

                    // Map normalized coordinates to canvas pixels
                    val pTL = Offset(offsetX + corners.tlX * drawW, offsetY + corners.tlY * drawH)
                    val pTR = Offset(offsetX + corners.trX * drawW, offsetY + corners.trY * drawH)
                    val pBR = Offset(offsetX + corners.brX * drawW, offsetY + corners.brY * drawH)
                    val pBL = Offset(offsetX + corners.blX * drawW, offsetY + corners.blY * drawH)

                    val cornerList = listOf(pTL, pTR, pBR, pBL)

                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(sourceBitmap) {
                                detectDragGestures(
                                    onDragStart = { startPos ->
                                        // Find closest handle within 54dp
                                        val dists = cornerList.mapIndexed { idx, pt ->
                                            idx to (pt - startPos).getDistance()
                                        }
                                        val closest = dists.minByOrNull { it.second }
                                        if (closest != null && closest.second < 160f) {
                                            activeHandleIndex = closest.first
                                        }
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val handle = activeHandleIndex ?: return@detectDragGestures
                                        val curPt = cornerList[handle]
                                        val newPt = curPt + dragAmount

                                        val normX = ((newPt.x - offsetX) / drawW).coerceIn(0f, 1f)
                                        val normY = ((newPt.y - offsetY) / drawH).coerceIn(0f, 1f)

                                        viewModel.cornerPoints.value = when (handle) {
                                            0 -> corners.copy(tlX = normX, tlY = normY)
                                            1 -> corners.copy(trX = normX, trY = normY)
                                            2 -> corners.copy(brX = normX, brY = normY)
                                            3 -> corners.copy(blX = normX, blY = normY)
                                            else -> corners
                                        }
                                    },
                                    onDragEnd = {
                                        activeHandleIndex = null
                                    },
                                    onDragCancel = {
                                        activeHandleIndex = null
                                    }
                                )
                            }
                    ) {
                        // Draw image
                        drawImage(
                            image = sourceBitmap.asImageBitmap(),
                            dstOffset = IntOffset(offsetX.toInt(), offsetY.toInt()),
                            dstSize = IntSize(drawW.toInt(), drawH.toInt())
                        )

                        // Draw darkened overlay outside crop quadrilateral
                        val fullPath = Path().apply {
                            addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height))
                        }
                        val cropPath = Path().apply {
                            moveTo(pTL.x, pTL.y)
                            lineTo(pTR.x, pTR.y)
                            lineTo(pBR.x, pBR.y)
                            lineTo(pBL.x, pBL.y)
                            close()
                        }
                        val outsidePath = Path.combine(PathOperation.Difference, fullPath, cropPath)
                        drawPath(outsidePath, Color.Black.copy(alpha = 0.55f))

                        // Draw crop boundary lines
                        drawPath(
                            path = cropPath,
                            color = Color(0xFF38BDF8),
                            style = Stroke(width = 4f)
                        )

                        // Draw 4 handles (each >= 48dp touchable)
                        cornerList.forEachIndexed { idx, pt ->
                            val isFocused = activeHandleIndex == idx
                            drawCircle(
                                color = if (isFocused) Color(0xFFF59E0B) else Color(0xFF38BDF8),
                                radius = if (isFocused) handleRadiusPx * 1.3f else handleRadiusPx,
                                center = pt
                            )
                            drawCircle(
                                color = Color.White,
                                radius = handleRadiusPx * 0.5f,
                                center = pt
                            )
                        }
                    }

                    // Loupe Magnifier overlay when dragging a handle
                    if (activeHandleIndex != null) {
                        val activePt = cornerList[activeHandleIndex!!]
                        Box(
                            modifier = Modifier
                                .offset {
                                    IntOffset(
                                        x = (activePt.x - 90f).toInt().coerceIn(16, (cw - 180).toInt()),
                                        y = (activePt.y - 200f).toInt().coerceIn(16, (ch - 200).toInt())
                                    )
                                }
                                .size(130.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .border(3.dp, Color(0xFFF59E0B), CircleShape)
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val normPos = when (activeHandleIndex) {
                                    0 -> Offset(corners.tlX, corners.tlY)
                                    1 -> Offset(corners.trX, corners.trY)
                                    2 -> Offset(corners.brX, corners.brY)
                                    else -> Offset(corners.blX, corners.blY)
                                }
                                val srcX = (normPos.x * bmpW).toInt()
                                val srcY = (normPos.y * bmpH).toInt()

                                val sampleRadius = 50
                                val srcRect = android.graphics.Rect(
                                    (srcX - sampleRadius).coerceAtLeast(0),
                                    (srcY - sampleRadius).coerceAtLeast(0),
                                    (srcX + sampleRadius).coerceAtMost(sourceBitmap.width),
                                    (srcY + sampleRadius).coerceAtMost(sourceBitmap.height)
                                )

                                drawImage(
                                    image = sourceBitmap.asImageBitmap(),
                                    srcOffset = IntOffset(srcRect.left, srcRect.top),
                                    srcSize = IntSize(srcRect.width(), srcRect.height()),
                                    dstOffset = IntOffset.Zero,
                                    dstSize = IntSize(size.width.toInt(), size.height.toInt())
                                )

                                // Crosshairs
                                drawLine(
                                    color = Color(0xFFF59E0B),
                                    start = Offset(size.width / 2f, 0f),
                                    end = Offset(size.width / 2f, size.height),
                                    strokeWidth = 2f
                                )
                                drawLine(
                                    color = Color(0xFFF59E0B),
                                    start = Offset(0f, size.height / 2f),
                                    end = Offset(size.width, size.height / 2f),
                                    strokeWidth = 2f
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
