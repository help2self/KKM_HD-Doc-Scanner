package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.data.local.DocumentEntity
import com.example.data.local.FolderEntity
import com.example.data.local.TagEntity
import com.example.i18n.I18n
import com.example.i18n.Language
import com.example.ui.Screen
import com.example.ui.viewmodel.DateFilterOption
import com.example.ui.viewmodel.ScannerViewModel
import com.example.ui.viewmodel.SortOption
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val docs by viewModel.allDocuments.collectAsState()
    val folders by viewModel.allFolders.collectAsState()
    val tags by viewModel.allTags.collectAsState()

    val search by viewModel.searchQuery.collectAsState()
    val selectedFolder by viewModel.selectedFolderId.collectAsState()
    val selectedTag by viewModel.selectedTagId.collectAsState()
    val dateFilter by viewModel.dateFilter.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()

    var showNewFolderDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var showNewTagDialog by remember { mutableStateOf(false) }
    var newTagName by remember { mutableStateOf("") }

    // Filter documents
    val filteredDocs = remember(docs, search, selectedFolder, selectedTag, dateFilter, sortOption, folders, tags) {
        val now = Calendar.getInstance()
        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val startOfWeek = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }.timeInMillis

        val startOfMonth = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
        }.timeInMillis

        var list = docs.filter { doc ->
            // Search query matches name, notes, or tags
            val matchesSearch = if (search.isBlank()) true else {
                val q = search.trim().lowercase()
                doc.name.lowercase().contains(q) || doc.notes.lowercase().contains(q)
            }

            // Folder match
            val matchesFolder = when (selectedFolder) {
                null -> true
                "none" -> doc.folderId == null
                else -> doc.folderId == selectedFolder
            }

            // Tag match
            val matchesTag = when (selectedTag) {
                null -> true
                else -> {
                    try {
                        val arr = JSONArray(doc.tagIdsJson)
                        var hasTag = false
                        for (i in 0 until arr.length()) {
                            if (arr.optString(i) == selectedTag) {
                                hasTag = true
                                break
                            }
                        }
                        hasTag
                    } catch (e: Exception) {
                        false
                    }
                }
            }

            // Date match
            val matchesDate = when (dateFilter) {
                DateFilterOption.ALL_TIME -> true
                DateFilterOption.TODAY -> doc.createdAt >= startOfToday
                DateFilterOption.THIS_WEEK -> doc.createdAt >= startOfWeek
                DateFilterOption.THIS_MONTH -> doc.createdAt >= startOfMonth
            }

            matchesSearch && matchesFolder && matchesTag && matchesDate
        }

        // Sorting
        list = when (sortOption) {
            SortOption.DATE -> list.sortedByDescending { it.updatedAt }
            SortOption.NAME -> list.sortedBy { it.name.lowercase() }
            SortOption.SIZE -> list.sortedByDescending { it.updatedAt }
        }

        list
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("library", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                try {
                                    val csvFile = viewModel.repository.exportLibraryCsv(lang)
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        csvFile
                                    )
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/csv"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "Export CSV"))
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.testTag("export_csv_btn")
                    ) {
                        Icon(imageVector = Icons.Default.FileDownload, contentDescription = I18n.get("export_csv", lang))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search Input
            OutlinedTextField(
                value = search,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text(I18n.get("search_hint", lang)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (search.isNotBlank()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = null)
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("library_search_input"),
                shape = RoundedCornerShape(12.dp)
            )

            // Folders Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedFolder == null,
                    onClick = { viewModel.selectedFolderId.value = null },
                    label = { Text(I18n.get("all_folders", lang)) }
                )
                FilterChip(
                    selected = selectedFolder == "none",
                    onClick = { viewModel.selectedFolderId.value = if (selectedFolder == "none") null else "none" },
                    label = { Text(I18n.get("no_folder", lang)) }
                )
                folders.forEach { f ->
                    FilterChip(
                        selected = selectedFolder == f.id,
                        onClick = { viewModel.selectedFolderId.value = if (selectedFolder == f.id) null else f.id },
                        label = { Text(f.name) },
                        trailingIcon = {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Delete",
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable {
                                        coroutineScope.launch {
                                            viewModel.repository.deleteFolder(f)
                                            if (selectedFolder == f.id) viewModel.selectedFolderId.value = null
                                        }
                                    }
                            )
                        }
                    )
                }
                IconButton(
                    onClick = { showNewFolderDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.CreateNewFolder, contentDescription = I18n.get("create_folder", lang))
                }
            }

            // Tags Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedTag == null,
                    onClick = { viewModel.selectedTagId.value = null },
                    label = { Text(I18n.get("all_tags", lang)) }
                )
                tags.forEach { t ->
                    FilterChip(
                        selected = selectedTag == t.id,
                        onClick = { viewModel.selectedTagId.value = if (selectedTag == t.id) null else t.id },
                        label = { Text("#${t.name}") },
                        trailingIcon = {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Delete",
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable {
                                        coroutineScope.launch {
                                            viewModel.repository.deleteTag(t)
                                            if (selectedTag == t.id) viewModel.selectedTagId.value = null
                                        }
                                    }
                            )
                        }
                    )
                }
                IconButton(
                    onClick = { showNewTagDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.BookmarkAdd, contentDescription = I18n.get("create_tag", lang))
                }
            }

            // Date Filters & Sort Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Exact row count
                Text(
                    text = I18n.get("showing_count", lang, filteredDocs.size),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("matching_docs_count")
                )

                // Clear filters button if active
                if (search.isNotBlank() || selectedFolder != null || selectedTag != null || dateFilter != DateFilterOption.ALL_TIME) {
                    TextButton(
                        onClick = {
                            viewModel.searchQuery.value = ""
                            viewModel.selectedFolderId.value = null
                            viewModel.selectedTagId.value = null
                            viewModel.dateFilter.value = DateFilterOption.ALL_TIME
                        },
                        modifier = Modifier.testTag("clear_filters_btn")
                    ) {
                        Text(I18n.get("clear_filters", lang))
                    }
                }
            }

            // Document List
            if (filteredDocs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = I18n.get("no_scans_yet", lang),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 40.dp)
                ) {
                    items(filteredDocs, key = { it.id }) { doc ->
                        LibraryDocumentCard(
                            doc = doc,
                            folders = folders,
                            tags = tags,
                            lang = lang,
                            onClick = {
                                viewModel.activeDocumentId.value = doc.id
                                viewModel.navigateTo(Screen.DocumentDetail)
                            },
                            onDelete = {
                                viewModel.deleteDocument(doc)
                            }
                        )
                    }
                }
            }
        }
    }

    // New Folder Dialog
    if (showNewFolderDialog) {
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text(I18n.get("create_folder", lang)) },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text(I18n.get("folder_name", lang)) },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newFolderName.isNotBlank()) {
                        coroutineScope.launch {
                            viewModel.repository.createFolder(newFolderName)
                            newFolderName = ""
                            showNewFolderDialog = false
                        }
                    }
                }) {
                    Text(I18n.get("add", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // New Tag Dialog
    if (showNewTagDialog) {
        AlertDialog(
            onDismissRequest = { showNewTagDialog = false },
            title = { Text(I18n.get("create_tag", lang)) },
            text = {
                OutlinedTextField(
                    value = newTagName,
                    onValueChange = { newTagName = it },
                    label = { Text(I18n.get("tag_name", lang)) },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newTagName.isNotBlank()) {
                        coroutineScope.launch {
                            viewModel.repository.createTag(newTagName, "#3B82F6")
                            newTagName = ""
                            showNewTagDialog = false
                        }
                    }
                }) {
                    Text(I18n.get("add", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewTagDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }
}

@Composable
fun LibraryDocumentCard(
    doc: DocumentEntity,
    folders: List<FolderEntity>,
    tags: List<TagEntity>,
    lang: Language,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val folderName = folders.find { it.id == doc.folderId }?.name
    val docTags = remember(doc.tagIdsJson, tags) {
        try {
            val arr = JSONArray(doc.tagIdsJson)
            val list = mutableListOf<TagEntity>()
            for (i in 0 until arr.length()) {
                val tid = arr.optString(i)
                tags.find { it.id == tid }?.let { list.add(it) }
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("document_card_${doc.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Article,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = doc.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = I18n.formatDateTime(doc.createdAt, lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                // Folder and tag badges
                if (folderName != null || docTags.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (folderName != null) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Text(
                                    text = folderName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        docTags.take(2).forEach { t ->
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.tertiaryContainer
                            ) {
                                Text(
                                    text = "#${t.name}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = I18n.get("delete", lang),
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                )
            }
        }
    }
}
