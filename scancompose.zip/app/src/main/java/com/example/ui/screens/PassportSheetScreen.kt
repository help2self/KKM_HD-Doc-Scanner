package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.PassportConfig
import com.example.data.model.PassportSheetPreset
import com.example.data.model.PassportSizePreset
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PassportSheetScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val config by viewModel.passportConfig.collectAsState()

    var sourceBitmap by remember { mutableStateOf(viewModel.passportSourceBitmap) }
    var generatedSheetBitmap by remember { mutableStateOf(viewModel.passportGeneratedSheet) }
    var isGenerating by remember { mutableStateOf(false) }

    val pickPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val file = File(context.filesDir, "passport_src_${UUID.randomUUID()}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    file.outputStream().use { output -> input.copyTo(output) }
                }
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) {
                    sourceBitmap = bmp
                    viewModel.passportSourceBitmap = bmp
                    viewModel.passportConfig.value = config.copy(photoPath = file.absolutePath)
                }
            }
        }
    }

    fun triggerGenerateSheet() {
        val src = sourceBitmap ?: return
        isGenerating = true
        coroutineScope.launch {
            val sheet = ImageProcessor.renderPassportSheet(config, src)
            generatedSheetBitmap = sheet
            viewModel.passportGeneratedSheet = sheet
            isGenerating = false
        }
    }

    // Auto generate sheet when config or bitmap changes
    LaunchedEffect(config, sourceBitmap) {
        if (sourceBitmap != null) {
            triggerGenerateSheet()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("passport_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    if (generatedSheetBitmap != null) {
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    val targetDocId = UUID.randomUUID().toString()
                                    val timestamp = System.currentTimeMillis()
                                    val doc = com.example.data.local.DocumentEntity(
                                        id = targetDocId,
                                        name = "Passport Sheet " + I18n.defaultScanName(timestamp),
                                        createdAt = timestamp,
                                        updatedAt = timestamp
                                    )
                                    viewModel.repository.saveDocument(doc)

                                    val pageId = UUID.randomUUID().toString()
                                    val file = File(context.filesDir, "passport_${pageId}.jpg")
                                    val thumb = File(context.filesDir, "thumb_${pageId}.jpg")
                                    ImageProcessor.saveBitmapToFile(generatedSheetBitmap!!, file)
                                    val tBmp = Bitmap.createScaledBitmap(generatedSheetBitmap!!, 300, (300f * generatedSheetBitmap!!.height / generatedSheetBitmap!!.width).toInt(), true)
                                    ImageProcessor.saveBitmapToFile(tBmp, thumb, quality = 80)

                                    viewModel.repository.savePage(
                                        com.example.data.local.PageEntity(
                                            id = pageId,
                                            documentId = targetDocId,
                                            pageOrder = 0,
                                            pageType = "scan",
                                            originalImagePath = file.absolutePath,
                                            thumbnailImagePath = thumb.absolutePath
                                        )
                                    )
                                    viewModel.refreshStorageInfo()
                                    viewModel.activeDocumentId.value = targetDocId
                                    viewModel.navigateTo(Screen.DocumentDetail)
                                }
                            },
                            modifier = Modifier.testTag("save_passport_doc_btn")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save Document")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mandatory Disclaimer Label
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = I18n.get("passport_disclaimer", lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Photo Selector / Capture
            if (sourceBitmap == null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clickable {
                            pickPhotoLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .testTag("passport_photo_picker_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddAPhoto,
                            contentDescription = null,
                            modifier = Modifier.size(44.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = I18n.get("select_photo", lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        bitmap = sourceBitmap!!.asImageBitmap(),
                        contentDescription = "Selected Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(70.dp, 90.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Photo Selected",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedButton(
                            onClick = {
                                pickPhotoLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text("Change Photo", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            // Photo Size Presets
            Text(
                text = I18n.get("photo_size", lang),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PassportSizePreset.values().forEach { preset ->
                    FilterChip(
                        selected = config.photoPreset == preset,
                        onClick = {
                            viewModel.passportConfig.value = config.copy(
                                photoPreset = preset,
                                customPhotoWidthMm = preset.widthMm,
                                customPhotoHeightMm = preset.heightMm
                            )
                        },
                        label = { Text(I18n.get(preset.labelKey, lang)) },
                        modifier = Modifier.testTag("preset_chip_${preset.name}")
                    )
                }
            }

            // Sheet Size Presets
            Text(
                text = I18n.get("sheet_size", lang),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PassportSheetPreset.values().forEach { sheet ->
                    FilterChip(
                        selected = config.sheetPreset == sheet,
                        onClick = {
                            viewModel.passportConfig.value = config.copy(
                                sheetPreset = sheet,
                                customSheetWidthMm = sheet.widthMm,
                                customSheetHeightMm = sheet.heightMm
                            )
                        },
                        label = { Text(I18n.get(sheet.labelKey, lang)) },
                        modifier = Modifier.testTag("sheet_chip_${sheet.name}")
                    )
                }
            }

            // Copies Options: Fit maximum or Custom count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = I18n.get("copies_count", lang),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = config.isFitMaximum,
                        onCheckedChange = { viewModel.passportConfig.value = config.copy(isFitMaximum = it) },
                        modifier = Modifier.testTag("fit_maximum_checkbox")
                    )
                    Text(I18n.get("fit_maximum", lang), style = MaterialTheme.typography.bodySmall)
                }
            }

            // Cut Guidelines Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(I18n.get("cut_guidelines", lang), style = MaterialTheme.typography.bodyMedium)
                Switch(
                    checked = config.showCutLines,
                    onCheckedChange = { viewModel.passportConfig.value = config.copy(showCutLines = it) },
                    modifier = Modifier.testTag("cut_guidelines_switch")
                )
            }

            // Generated Sheet 300 DPI Live Preview
            if (generatedSheetBitmap != null) {
                Text(
                    text = "Live Sheet Preview (300 DPI)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(config.customSheetWidthMm / config.customSheetHeightMm)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = generatedSheetBitmap!!.asImageBitmap(),
                        contentDescription = "Generated Passport Sheet",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            }
        }
    }
}
