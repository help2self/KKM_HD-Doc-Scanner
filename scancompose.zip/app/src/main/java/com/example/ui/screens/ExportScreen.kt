package com.example.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.data.model.ExportFormat
import com.example.data.model.ExportQuality
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val pages by viewModel.activeDocumentPages.collectAsState()
    val docs by viewModel.allDocuments.collectAsState()
    val activeDocId by viewModel.activeDocumentId.collectAsState()
    val currentDoc = docs.find { it.id == activeDocId }

    var format by remember { mutableStateOf(ExportFormat.PDF) }
    var quality by remember { mutableStateOf(ExportQuality.HIGH) }
    val selectedPageIds = remember { mutableStateMapOf<String, Boolean>() }

    var isExporting by remember { mutableStateOf(false) }
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pages) {
        pages.forEach { selectedPageIds[it.id] = true }
    }

    val activeCount = selectedPageIds.values.count { it }

    // Honest approximate file size calculation
    val estimatedSizeText = remember(format, quality, activeCount) {
        val baseBytesPerPage = when (quality) {
            ExportQuality.ORIGINAL -> 2_500_000L
            ExportQuality.HIGH -> 1_200_000L
            ExportQuality.MEDIUM -> 500_000L
            ExportQuality.SMALL -> 180_000L
        }
        val total = baseBytesPerPage * activeCount.coerceAtLeast(1)
        val mb = total / (1024.0 * 1024.0)
        String.format("%.1f MB", mb)
    }

    fun executeExport(isShare: Boolean) {
        if (activeCount == 0) return
        isExporting = true
        coroutineScope.launch {
            try {
                val pagesToExport = pages.filter { selectedPageIds[it.id] == true }
                val bitmaps = mutableListOf<Bitmap>()
                for (p in pagesToExport) {
                    val bmp = ImageProcessor.loadBitmapFromFile(
                        if (p.originalImagePath.isNotBlank()) p.originalImagePath else p.thumbnailImagePath,
                        maxDimension = when (quality) {
                            ExportQuality.ORIGINAL -> 4096
                            ExportQuality.HIGH -> 2400
                            ExportQuality.MEDIUM -> 1600
                            ExportQuality.SMALL -> 1000
                        }
                    )
                    if (bmp != null) bitmaps.add(bmp)
                }

                if (format == ExportFormat.PDF) {
                    val pdfFile = File(context.cacheDir, "${currentDoc?.name ?: "scan"}_export.pdf")
                    val success = ImageProcessor.generatePdf(bitmaps, pdfFile)
                    if (success) {
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdfFile)
                        if (isShare) {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Document"))
                            exportStatusMessage = "Shared PDF via apps"
                        } else {
                            val dest = File(context.filesDir, pdfFile.name)
                            pdfFile.copyTo(dest, overwrite = true)
                            exportStatusMessage = "PDF saved to app files: ${pdfFile.name}"
                        }
                    }
                } else {
                    // Export images (JPG or PNG)
                    val exportFiles = mutableListOf<File>()
                    for ((idx, bmp) in bitmaps.withIndex()) {
                        val ext = if (format == ExportFormat.PNG) "png" else "jpg"
                        val imgFile = File(context.cacheDir, "${currentDoc?.name ?: "scan"}_p${idx + 1}.$ext")
                        ImageProcessor.saveBitmapToFile(
                            bmp,
                            imgFile,
                            format = if (format == ExportFormat.PNG) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                            quality = quality.jpegQuality
                        )
                        exportFiles.add(imgFile)
                    }

                    if (isShare && exportFiles.isNotEmpty()) {
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", exportFiles.first())
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = if (format == ExportFormat.PNG) "image/png" else "image/jpeg"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Image"))
                        exportStatusMessage = "Shared image via apps"
                    } else {
                        exportStatusMessage = "Saved ${exportFiles.size} images to device"
                    }
                }
            } catch (e: Exception) {
                exportStatusMessage = "Export failed: ${e.message}"
            } finally {
                isExporting = false
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("export_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { executeExport(isShare = false) },
                        enabled = !isExporting && activeCount > 0,
                        modifier = Modifier.weight(1f).testTag("save_to_device_btn")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get("download_action", lang), style = MaterialTheme.typography.bodySmall)
                    }

                    Button(
                        onClick = { executeExport(isShare = true) },
                        enabled = !isExporting && activeCount > 0,
                        modifier = Modifier.weight(1f).testTag("share_with_apps_btn")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get("share_action", lang), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Status banner if export completed
            if (exportStatusMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = exportStatusMessage!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Export Format selection
            Text(
                text = I18n.get("format", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = format == ExportFormat.PDF,
                    onClick = { format = ExportFormat.PDF },
                    label = { Text(I18n.get("format_pdf", lang)) },
                    modifier = Modifier.weight(1f).testTag("format_pdf_chip")
                )
                FilterChip(
                    selected = format == ExportFormat.JPG,
                    onClick = { format = ExportFormat.JPG },
                    label = { Text(I18n.get("format_jpg", lang)) },
                    modifier = Modifier.weight(1f).testTag("format_jpg_chip")
                )
                FilterChip(
                    selected = format == ExportFormat.PNG,
                    onClick = { format = ExportFormat.PNG },
                    label = { Text(I18n.get("format_png", lang)) },
                    modifier = Modifier.weight(1f).testTag("format_png_chip")
                )
            }

            // Quality Selection
            Text(
                text = I18n.get("quality", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ExportQuality.values().forEach { q ->
                    val label = when (q) {
                        ExportQuality.ORIGINAL -> I18n.get("quality_original", lang)
                        ExportQuality.HIGH -> I18n.get("quality_high", lang)
                        ExportQuality.MEDIUM -> I18n.get("quality_medium", lang)
                        ExportQuality.SMALL -> I18n.get("quality_small", lang)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { quality = q }
                            .padding(vertical = 4.dp)
                    ) {
                        RadioButton(
                            selected = quality == q,
                            onClick = { quality = q },
                            modifier = Modifier.testTag("quality_radio_${q.name}")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            // Honest Estimated File Size Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = I18n.get("estimated_size", lang, estimatedSizeText),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("estimated_size_label")
                    )
                    Text(
                        text = "$activeCount pages",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Page Selection Checkboxes
            Text(
                text = I18n.get("select_pages", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            pages.forEachIndexed { index, page ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val curr = selectedPageIds[page.id] ?: true
                            selectedPageIds[page.id] = !curr
                        }
                        .padding(vertical = 4.dp)
                ) {
                    Checkbox(
                        checked = selectedPageIds[page.id] ?: true,
                        onCheckedChange = { selectedPageIds[page.id] = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Page ${index + 1} (${page.pageType.capitalize()})", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
