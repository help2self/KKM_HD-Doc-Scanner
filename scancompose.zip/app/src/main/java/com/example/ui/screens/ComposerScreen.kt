package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.i18n.I18n
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposerScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()

    val config by viewModel.composerConfig.collectAsState()
    val objects by viewModel.composerObjects.collectAsState()
    val selectedId by viewModel.selectedObjectId.collectAsState()

    val composerHistory by viewModel.composerHistory.collectAsState()
    val composerRedoStack by viewModel.composerRedoStack.collectAsState()

    var showLayoutMenu by remember { mutableStateOf(false) }
    var showNumericEditor by remember { mutableStateOf(false) }
    var showPageConfigDialog by remember { mutableStateOf(false) }
    var showAddTextDialog by remember { mutableStateOf(false) }
    var newTextValue by remember { mutableStateOf("") }

    val activeObject = objects.find { it.id == selectedId }

    // Multi-image picker from Gallery
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val newObjs = objects.toMutableList()
                var currentX = config.marginMm
                var currentY = config.marginMm

                for (uri in uris) {
                    val file = File(context.filesDir, "comp_${UUID.randomUUID()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        file.outputStream().use { output -> input.copyTo(output) }
                    }
                    val itemW = 80f
                    val itemH = 60f
                    newObjs.add(
                        ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.IMAGE,
                            imagePath = file.absolutePath,
                            xMm = currentX,
                            yMm = currentY,
                            widthMm = itemW,
                            heightMm = itemH,
                            layer = newObjs.size
                        )
                    )
                    currentX += 15f
                    currentY += 15f
                }
                viewModel.updateComposerObjects(newObjs)
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("composer_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    // Undo
                    IconButton(
                        onClick = { viewModel.undoComposer() },
                        enabled = composerHistory.isNotEmpty(),
                        modifier = Modifier.testTag("composer_undo_btn")
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = I18n.get("undo", lang))
                    }

                    // Redo
                    IconButton(
                        onClick = { viewModel.redoComposer() },
                        enabled = composerRedoStack.isNotEmpty(),
                        modifier = Modifier.testTag("composer_redo_btn")
                    ) {
                        Icon(Icons.Default.Redo, contentDescription = I18n.get("redo", lang))
                    }

                    // Page setup
                    IconButton(onClick = { showPageConfigDialog = true }) {
                        Icon(Icons.Default.Tune, contentDescription = "Page Setup")
                    }

                    // Save composed page
                    TextButton(
                        onClick = {
                            viewModel.saveComposedPage(viewModel.activeDocumentId.value) {
                                viewModel.navigateTo(Screen.DocumentDetail)
                            }
                        },
                        modifier = Modifier.testTag("save_composed_btn")
                    ) {
                        Text(I18n.get("save", lang), fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Quick Action Tools: Import, Layouts, Add Text, Alignment
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                pickMultipleImagesLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("import_images_btn")
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(I18n.get("import_images", lang), style = MaterialTheme.typography.bodySmall)
                        }

                        OutlinedButton(
                            onClick = { showLayoutMenu = true },
                            modifier = Modifier.testTag("ready_layouts_btn")
                        ) {
                            Icon(Icons.Default.ViewQuilt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(I18n.get("ready_layouts", lang), style = MaterialTheme.typography.bodySmall)
                        }

                        OutlinedButton(
                            onClick = { showAddTextDialog = true },
                            modifier = Modifier.testTag("add_textbox_btn")
                        ) {
                            Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(I18n.get("add_textbox", lang), style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    // If an object is selected, show object transformation controls
                    if (activeObject != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Rotate 90
                            IconButton(onClick = {
                                val updated = objects.map {
                                    if (it.id == activeObject.id) it.copy(rotationDeg = (it.rotationDeg + 90f) % 360f) else it
                                }
                                viewModel.updateComposerObjects(updated)
                            }) {
                                Icon(Icons.Default.RotateRight, contentDescription = "Rotate")
                            }

                            // Layer Bring Forward
                            IconButton(onClick = {
                                val maxLayer = objects.maxOfOrNull { it.layer } ?: 0
                                val updated = objects.map {
                                    if (it.id == activeObject.id) it.copy(layer = maxLayer + 1) else it
                                }
                                viewModel.updateComposerObjects(updated)
                            }) {
                                Icon(Icons.Default.FlipToFront, contentDescription = "Bring Forward")
                            }

                            // Layer Send Back
                            IconButton(onClick = {
                                val minLayer = objects.minOfOrNull { it.layer } ?: 0
                                val updated = objects.map {
                                    if (it.id == activeObject.id) it.copy(layer = minLayer - 1) else it
                                }
                                viewModel.updateComposerObjects(updated)
                            }) {
                                Icon(Icons.Default.FlipToBack, contentDescription = "Send Back")
                            }

                            // Lock / Unlock
                            IconButton(onClick = {
                                val updated = objects.map {
                                    if (it.id == activeObject.id) it.copy(isLocked = !it.isLocked) else it
                                }
                                viewModel.updateComposerObjects(updated)
                            }) {
                                Icon(
                                    imageVector = if (activeObject.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                    contentDescription = "Lock"
                                )
                            }

                            // Exact size / position editor
                            OutlinedButton(onClick = { showNumericEditor = true }) {
                                Icon(Icons.Default.Straighten, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Size & Pos", style = MaterialTheme.typography.labelSmall)
                            }

                            // Duplicate
                            IconButton(onClick = {
                                val dup = activeObject.copy(
                                    id = UUID.randomUUID().toString(),
                                    xMm = activeObject.xMm + 10f,
                                    yMm = activeObject.yMm + 10f,
                                    layer = objects.size
                                )
                                viewModel.updateComposerObjects(objects + dup)
                                viewModel.selectedObjectId.value = dup.id
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate")
                            }

                            // Delete
                            IconButton(onClick = {
                                viewModel.updateComposerObjects(objects.filter { it.id != activeObject.id })
                                viewModel.selectedObjectId.value = null
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            // Page Canvas with exact proportional scaling
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                val availableW = maxWidth.value
                val availableH = maxHeight.value

                val effW = if (config.orientation == PageOrientation.PORTRAIT) config.widthMm else config.heightMm
                val effH = if (config.orientation == PageOrientation.PORTRAIT) config.heightMm else config.widthMm

                val scale = minOf(availableW / effW, availableH / effH) * 0.95f
                val canvasWidthDp = (effW * scale).dp
                val canvasHeightDp = (effH * scale).dp

                val mmToDp = scale

                Surface(
                    modifier = Modifier
                        .size(canvasWidthDp, canvasHeightDp)
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { viewModel.selectedObjectId.value = null }
                        .testTag("composed_page_canvas"),
                    color = Color(config.backgroundColor),
                    shadowElevation = 8.dp
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Draw grid if enabled
                        if (config.showGrid) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val stepPx = 10f * (size.width / effW) // 10mm grid
                                var x = 0f
                                while (x < size.width) {
                                    drawLine(
                                        color = Color(0xFFE2E8F0),
                                        start = Offset(x, 0f),
                                        end = Offset(x, size.height),
                                        strokeWidth = 1f
                                    )
                                    x += stepPx
                                }
                                var y = 0f
                                while (y < size.height) {
                                    drawLine(
                                        color = Color(0xFFE2E8F0),
                                        start = Offset(0f, y),
                                        end = Offset(size.width, y),
                                        strokeWidth = 1f
                                    )
                                    y += stepPx
                                }
                            }
                        }

                        // Render Composed Objects
                        objects.sortedBy { it.layer }.forEach { obj ->
                            val isSelected = obj.id == selectedId
                            val objXDp = (obj.xMm * mmToDp).dp
                            val objYDp = (obj.yMm * mmToDp).dp
                            val objWDp = (obj.widthMm * mmToDp).dp
                            val objHDp = (obj.heightMm * mmToDp).dp

                            Box(
                                modifier = Modifier
                                    .offset(x = objXDp, y = objYDp)
                                    .size(objWDp, objHDp)
                                    .border(
                                        width = if (isSelected) 2.dp else (obj.borderWidthMm * mmToDp).dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color(obj.borderColor)
                                    )
                                    .clickable { viewModel.selectedObjectId.value = obj.id }
                                    .pointerInput(obj.id, obj.isLocked) {
                                        if (!obj.isLocked) {
                                            detectDragGestures { change, dragAmount ->
                                                change.consume()
                                                val deltaXMm = dragAmount.x / mmToDp
                                                val deltaYMm = dragAmount.y / mmToDp

                                                val updated = objects.map {
                                                    if (it.id == obj.id) {
                                                        it.copy(
                                                            xMm = (it.xMm + deltaXMm).coerceIn(0f, effW - it.widthMm),
                                                            yMm = (it.yMm + deltaYMm).coerceIn(0f, effH - it.heightMm)
                                                        )
                                                    } else it
                                                }
                                                viewModel.composerObjects.value = updated
                                            }
                                        }
                                    }
                            ) {
                                if (obj.type == ObjectType.IMAGE && obj.imagePath != null) {
                                    AsyncImage(
                                        model = File(obj.imagePath),
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else if (obj.type == ObjectType.TEXT && obj.text != null) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(4.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Text(
                                            text = obj.text,
                                            color = Color(obj.fontColor),
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }

                                if (obj.isLocked) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .size(16.dp)
                                            .align(Alignment.TopEnd)
                                            .padding(2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Ready Layouts Bottom Sheet / Dialog
    if (showLayoutMenu) {
        val existingPaths = objects.mapNotNull { it.imagePath }
        AlertDialog(
            onDismissRequest = { showLayoutMenu = false },
            title = { Text(I18n.get("ready_layouts", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_1", lang)) },
                        modifier = Modifier.clickable {
                            showLayoutMenu = false
                            viewModel.applyReadyLayout("1", existingPaths)
                        }
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_2", lang)) },
                        modifier = Modifier.clickable {
                            showLayoutMenu = false
                            viewModel.applyReadyLayout("2", existingPaths)
                        }
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_4", lang)) },
                        modifier = Modifier.clickable {
                            showLayoutMenu = false
                            viewModel.applyReadyLayout("4", existingPaths)
                        }
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_6", lang)) },
                        modifier = Modifier.clickable {
                            showLayoutMenu = false
                            viewModel.applyReadyLayout("6", existingPaths)
                        }
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_id_card", lang)) },
                        supportingContent = { Text("A4 page • 2 cards at true size 85.6 x 54 mm") },
                        modifier = Modifier
                            .clickable {
                                showLayoutMenu = false
                                viewModel.applyReadyLayout("id_card", existingPaths)
                            }
                            .testTag("layout_id_card_item")
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showLayoutMenu = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Exact Numeric Dimensions Editor
    if (showNumericEditor && activeObject != null) {
        var xVal by remember { mutableStateOf(activeObject.xMm.toString()) }
        var yVal by remember { mutableStateOf(activeObject.yMm.toString()) }
        var wVal by remember { mutableStateOf(activeObject.widthMm.toString()) }
        var hVal by remember { mutableStateOf(activeObject.heightMm.toString()) }

        AlertDialog(
            onDismissRequest = { showNumericEditor = false },
            title = { Text(I18n.get("numeric_editor", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = xVal,
                            onValueChange = { xVal = it },
                            label = { Text(I18n.get("x_pos", lang)) },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = yVal,
                            onValueChange = { yVal = it },
                            label = { Text(I18n.get("y_pos", lang)) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = wVal,
                            onValueChange = { wVal = it },
                            label = { Text(I18n.get("width_mm", lang)) },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = hVal,
                            onValueChange = { hVal = it },
                            label = { Text(I18n.get("height_mm", lang)) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val nx = xVal.toFloatOrNull() ?: activeObject.xMm
                    val ny = yVal.toFloatOrNull() ?: activeObject.yMm
                    val nw = wVal.toFloatOrNull() ?: activeObject.widthMm
                    val nh = hVal.toFloatOrNull() ?: activeObject.heightMm

                    val updated = objects.map {
                        if (it.id == activeObject.id) it.copy(xMm = nx, yMm = ny, widthMm = nw, heightMm = nh) else it
                    }
                    viewModel.updateComposerObjects(updated)
                    showNumericEditor = false
                }) {
                    Text(I18n.get("apply", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showNumericEditor = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Add Text Dialog
    if (showAddTextDialog) {
        AlertDialog(
            onDismissRequest = { showAddTextDialog = false },
            title = { Text(I18n.get("add_textbox", lang)) },
            text = {
                OutlinedTextField(
                    value = newTextValue,
                    onValueChange = { newTextValue = it },
                    placeholder = { Text("Enter text here...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newTextValue.isNotBlank()) {
                        val txtObj = ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.TEXT,
                            text = newTextValue,
                            xMm = config.marginMm,
                            yMm = config.marginMm + 30f,
                            widthMm = 100f,
                            heightMm = 25f,
                            layer = objects.size
                        )
                        viewModel.updateComposerObjects(objects + txtObj)
                        viewModel.selectedObjectId.value = txtObj.id
                        newTextValue = ""
                        showAddTextDialog = false
                    }
                }) {
                    Text(I18n.get("add", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTextDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Page Config Dialog
    if (showPageConfigDialog) {
        AlertDialog(
            onDismissRequest = { showPageConfigDialog = false },
            title = { Text(I18n.get("page_size", lang)) },
            text = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.composerConfig.value = config.copy(orientation = PageOrientation.PORTRAIT)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(I18n.get("portrait", lang))
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel.composerConfig.value = config.copy(orientation = PageOrientation.LANDSCAPE)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(I18n.get("landscape", lang))
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    PageSizePreset.values().forEach { preset ->
                        ListItem(
                            headlineContent = { Text(preset.displayName) },
                            supportingContent = { Text("${preset.widthMm} x ${preset.heightMm} mm") },
                            modifier = Modifier.clickable {
                                viewModel.composerConfig.value = config.copy(
                                    preset = preset,
                                    widthMm = preset.widthMm,
                                    heightMm = preset.heightMm
                                )
                                showPageConfigDialog = false
                            }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPageConfigDialog = false }) {
                    Text(I18n.get("done", lang))
                }
            }
        )
    }
}
