package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.MeteringPointFactory
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat

/**
 * CameraPreview component using CameraX to display a real-time viewfinder in the UI.
 * Provides an optical document alignment viewfinder overlay, corner brackets, animated scan line,
 * tap-to-focus, pinch-to-zoom, and lifecycle-safe camera binding.
 */
@Composable
fun CameraPreview(
    modifier: Modifier = Modifier,
    lensFacing: Int = CameraSelector.LENS_FACING_BACK,
    isFlashOn: Boolean = false,
    guideText: String = "Align document within frame",
    onCameraBound: (ImageCapture, CameraControl) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Check runtime camera permission
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    if (!hasCameraPermission) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Camera Permission Required",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Camera access is needed to scan documents in HD quality.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.testTag("request_camera_perm_btn")
                ) {
                    Text("Grant Permission")
                }
            }
        }
        return
    }

    var cameraControlRef by remember { mutableStateOf<CameraControl?>(null) }
    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }
    var tapFocusPoint by remember { mutableStateOf<Offset?>(null) }
    var currentZoomRatio by remember { mutableFloatStateOf(1f) }

    // Laser beam scanning animation
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_animation")
    val scanLineFraction by infiniteTransition.animateFloat(
        initialValue = 0.05f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scan_line"
    )

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {
        val totalWidth = maxWidth
        val totalHeight = maxHeight

        // CameraX Viewfinder Surface
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                previewViewRef = previewView

                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val imageCapture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .setFlashMode(if (isFlashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
                        .build()

                    val cameraSelector = CameraSelector.Builder()
                        .requireLensFacing(lensFacing)
                        .build()

                    try {
                        cameraProvider.unbindAll()
                        val camera: Camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageCapture
                        )
                        cameraControlRef = camera.cameraControl
                        onCameraBound(imageCapture, camera.cameraControl)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            },
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    // Tap to Focus gesture
                    detectTapGestures { offset ->
                        tapFocusPoint = offset
                        val pView = previewViewRef ?: return@detectTapGestures
                        val factory: MeteringPointFactory = pView.meteringPointFactory
                        val point = factory.createPoint(offset.x, offset.y)
                        val action = FocusMeteringAction.Builder(point).build()
                        cameraControlRef?.startFocusAndMetering(action)
                    }
                }
                .pointerInput(Unit) {
                    // Pinch to Zoom gesture
                    detectTransformGestures { _, _, zoom, _ ->
                        val newZoom = (currentZoomRatio * zoom).coerceIn(1f, 5f)
                        currentZoomRatio = newZoom
                        cameraControlRef?.setZoomRatio(newZoom)
                    }
                }
                .testTag("camerax_viewfinder_surface")
        )

        // Real-Time Document Viewfinder Overlay
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height

            // Calculate standard A4 Document ratio (1 : 1.414) centered inside available area
            val frameMarginHorizontal = 32.dp.toPx()
            val frameW = (canvasW - frameMarginHorizontal * 2).coerceAtLeast(200f)
            val idealFrameH = frameW * 1.414f
            val maxFrameH = canvasH * 0.65f
            val frameH = if (idealFrameH > maxFrameH) maxFrameH else idealFrameH

            val frameLeft = (canvasW - frameW) / 2f
            val frameTop = (canvasH - frameH) / 2f - 30.dp.toPx()
            val frameRight = frameLeft + frameW
            val frameBottom = frameTop + frameH

            val fullRect = Rect(0f, 0f, canvasW, canvasH)
            val docRect = Rect(frameLeft, frameTop, frameRight, frameBottom)

            // Darken outside region to emphasize document target area
            val outerPath = Path().apply { addRect(fullRect) }
            val innerPath = Path().apply {
                addRoundRect(
                    RoundRect(
                        rect = docRect,
                        cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx())
                    )
                )
            }
            val scrimPath = Path.combine(PathOperation.Difference, outerPath, innerPath)
            drawPath(scrimPath, color = Color.Black.copy(alpha = 0.52f))

            // Viewfinder frame border
            drawRoundRect(
                color = Color.White.copy(alpha = 0.25f),
                topLeft = Offset(frameLeft, frameTop),
                size = Size(frameW, frameH),
                cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                style = Stroke(width = 2.dp.toPx())
            )

            // 4 Corner Alignment Brackets (Bright Cyan / Accent Blue)
            val cornerLen = 32.dp.toPx()
            val cornerThickness = 4.dp.toPx()
            val bracketColor = Color(0xFF38BDF8)

            // Top-Left bracket
            drawLine(bracketColor, Offset(frameLeft, frameTop), Offset(frameLeft + cornerLen, frameTop), cornerThickness)
            drawLine(bracketColor, Offset(frameLeft, frameTop), Offset(frameLeft, frameTop + cornerLen), cornerThickness)

            // Top-Right bracket
            drawLine(bracketColor, Offset(frameRight, frameTop), Offset(frameRight - cornerLen, frameTop), cornerThickness)
            drawLine(bracketColor, Offset(frameRight, frameTop), Offset(frameRight, frameTop + cornerLen), cornerThickness)

            // Bottom-Left bracket
            drawLine(bracketColor, Offset(frameLeft, frameBottom), Offset(frameLeft + cornerLen, frameBottom), cornerThickness)
            drawLine(bracketColor, Offset(frameLeft, frameBottom), Offset(frameLeft, frameBottom - cornerLen), cornerThickness)

            // Bottom-Right bracket
            drawLine(bracketColor, Offset(frameRight, frameBottom), Offset(frameRight - cornerLen, frameBottom), cornerThickness)
            drawLine(bracketColor, Offset(frameRight, frameBottom), Offset(frameRight, frameBottom - cornerLen), cornerThickness)

            // Animated Laser Beam Scanning Line
            val scanY = frameTop + frameH * scanLineFraction
            val beamBrush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    Color(0xFF38BDF8).copy(alpha = 0.8f),
                    Color(0xFF60A5FA),
                    Color(0xFF38BDF8).copy(alpha = 0.8f),
                    Color.Transparent
                ),
                startX = frameLeft,
                endX = frameRight
            )
            drawLine(
                brush = beamBrush,
                start = Offset(frameLeft + 4f, scanY),
                end = Offset(frameRight - 4f, scanY),
                strokeWidth = 3.dp.toPx()
            )

            // Tap-to-focus ring indicator
            tapFocusPoint?.let { pt ->
                drawCircle(
                    color = Color(0xFFF59E0B),
                    radius = 28.dp.toPx(),
                    center = pt,
                    style = Stroke(width = 2.dp.toPx())
                )
                drawCircle(
                    color = Color.White,
                    radius = 4.dp.toPx(),
                    center = pt
                )
            }
        }

        // Viewfinder Guide Text Pill at the top
        Surface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 70.dp)
                .testTag("viewfinder_guide_pill"),
            color = Color.Black.copy(alpha = 0.65f),
            shape = CircleShape
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CropFree,
                    contentDescription = null,
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = guideText,
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
