package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.i18n.I18n
import com.example.i18n.Language
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import com.example.ui.viewmodel.ThemeMode
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    var showEraseConfirmDialog by remember { mutableStateOf(false) }
    var restorePreviewCounts by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var restoreZipFile by remember { mutableStateOf<File?>(null) }

    // Backup ZIP creation & share launcher
    val createBackupLauncher = {
        coroutineScope.launch {
            val backupFile = File(context.cacheDir, "DocScanner_Backup_${System.currentTimeMillis()}.zip")
            val ok = viewModel.repository.createBackupZip(backupFile)
            if (ok) {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", backupFile)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/zip"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Save Backup ZIP"))
            } else {
                Toast.makeText(context, "Backup failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Restore Backup ZIP file picker
    val pickZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val tempZip = File(context.cacheDir, "restore_temp.zip")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    tempZip.outputStream().use { output -> input.copyTo(output) }
                }
                val counts = viewModel.repository.inspectBackupZip(tempZip)
                if (counts != null) {
                    restorePreviewCounts = counts
                    restoreZipFile = tempZip
                } else {
                    Toast.makeText(context, "Invalid backup ZIP file", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("settings_title", lang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Language Switcher Section
            Text(
                text = I18n.get("interface_language", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilterChip(
                    selected = lang == Language.HINDI,
                    onClick = { viewModel.setLanguage(Language.HINDI) },
                    label = { Text("हिन्दी (Devanagari)", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.weight(1f).testTag("lang_hindi_chip")
                )
                FilterChip(
                    selected = lang == Language.ENGLISH,
                    onClick = { viewModel.setLanguage(Language.ENGLISH) },
                    label = { Text("English", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.weight(1f).testTag("lang_english_chip")
                )
            }

            Divider()

            // Theme Setting
            Text(
                text = I18n.get("theme", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = themeMode == ThemeMode.SYSTEM,
                    onClick = { viewModel.setThemeMode(ThemeMode.SYSTEM) },
                    label = { Text(I18n.get("theme_system", lang)) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = themeMode == ThemeMode.LIGHT,
                    onClick = { viewModel.setThemeMode(ThemeMode.LIGHT) },
                    label = { Text(I18n.get("theme_light", lang)) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = themeMode == ThemeMode.DARK,
                    onClick = { viewModel.setThemeMode(ThemeMode.DARK) },
                    label = { Text(I18n.get("theme_dark", lang)) },
                    modifier = Modifier.weight(1f)
                )
            }

            Divider()

            // Storage Meter Quick Jump
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(Screen.Storage) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(I18n.get("storage_title", lang), fontWeight = FontWeight.SemiBold)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }

            Divider()

            // Backup & Restore Section
            Text(
                text = I18n.get("backup_restore", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = { createBackupLauncher() },
                modifier = Modifier.fillMaxWidth().testTag("backup_data_btn")
            ) {
                Icon(Icons.Default.Archive, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(I18n.get("backup_my_data", lang))
            }

            OutlinedButton(
                onClick = {
                    pickZipLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                },
                modifier = Modifier.fillMaxWidth().testTag("restore_data_btn")
            ) {
                Icon(Icons.Default.Unarchive, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(I18n.get("restore_data", lang))
            }

            Divider()

            // Privacy Notice Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = I18n.get("privacy_notice", lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // Erase All Data Section
            OutlinedButton(
                onClick = { showEraseConfirmDialog = true },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth().testTag("erase_all_data_btn")
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(I18n.get("erase_all_data", lang))
            }
        }
    }

    // Restore Confirmation Dialog
    if (restorePreviewCounts != null && restoreZipFile != null) {
        val (docsCount, pagesCount) = restorePreviewCounts!!
        AlertDialog(
            onDismissRequest = {
                restorePreviewCounts = null
                restoreZipFile = null
            },
            title = { Text(I18n.get("restore_data", lang)) },
            text = { Text(I18n.get("restore_preview", lang, docsCount, pagesCount)) },
            confirmButton = {
                Button(
                    onClick = {
                        val file = restoreZipFile!!
                        restorePreviewCounts = null
                        restoreZipFile = null
                        coroutineScope.launch {
                            val ok = viewModel.repository.restoreBackupZip(file)
                            if (ok) {
                                viewModel.refreshStorageInfo()
                                Toast.makeText(context, "Restored successfully!", Toast.LENGTH_SHORT).show()
                                viewModel.navigateTo(Screen.Library)
                            } else {
                                Toast.makeText(context, "Failed to restore backup", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier.testTag("confirm_restore_btn")
                ) {
                    Text(I18n.get("confirm_restore", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    restorePreviewCounts = null
                    restoreZipFile = null
                }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Erase Confirmation Dialog
    if (showEraseConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showEraseConfirmDialog = false },
            title = { Text(I18n.get("confirm_erase_title", lang)) },
            text = { Text(I18n.get("confirm_erase_desc", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        showEraseConfirmDialog = false
                        coroutineScope.launch {
                            viewModel.repository.eraseAllData()
                            viewModel.refreshStorageInfo()
                            viewModel.navigateTo(Screen.Home)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_erase_button")
                ) {
                    Text(I18n.get("confirm_erase_btn", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEraseConfirmDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }
}
