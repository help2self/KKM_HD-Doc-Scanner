# VM Doc Scanner – v3 changes

1. Tilted crop -> straight page: new exact perspective warp (homography + bilinear sampling) in
   ImageProcessor.warpPerspective; detected corners are refined by fitting straight lines to the
   paper edges (refineQuadByLines).
2. Filters rewritten (ImageProcessor.scannerFilter): per-channel paper colour estimate removes
   shadows and blue/yellow tint. Original = untouched. Magic Color, B&W (adaptive), B&W 2 (soft),
   Grayscale, Lighten, Auto, Remove Shadow re-tuned. Filters never stack: each page keeps an
   untouched copy (base_<pageId>.jpg); "Apply to all pages" really re-renders the other pages.
3. Export: "Save to Device" -> "Save to Gallery". Images go to Pictures/VM Doc Scanner (Gallery),
   PDF to Documents/VM Doc Scanner. (processing/GallerySaver.kt)
4. Settings: "Save location" – choose any folder (system folder picker), rename album, reset.
5. Composer: delete (X), rotate handle and resize handle directly on the picture; bottom bar
   only Copy / Layer / Lock / Keep ratio + rotate slider. Size & Pos removed. Images keep their
   shape. Composer is cleared after Save and every time it is opened.
6. Passport sheet: Camera button (with permission) + Gallery; photo centre-cropped, not stretched.
7. Library redesigned (file-manager style): folder switcher in title, folder tiles, grid/list
   toggle, sort, multi-select (move/tag/delete). Every delete asks for confirmation. No more
   accidental X on folder/tag chips.
8. BUG FIX – images vanishing after typing notes: saveDocument used INSERT OR REPLACE which
   cascade-deleted all pages. Now UPDATE for existing documents. Notes box removed.
9. Language toggle removed from Home top bar (Settings has it). App renamed "VM Doc Scanner".
10. App appears in the Share list for images (single + multiple) and "Open with".
11. Faster live edge detection (frame shrunk before rotation, 90 ms interval).
