package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.Screen
import com.example.ui.components.CameraPreview
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

@Composable
fun CameraCaptureScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()

    val batchItems by viewModel.batchItems.collectAsState()
    var isFlashOn by remember { mutableStateOf(false) }
    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var cameraControl: CameraControl? by remember { mutableStateOf(null) }

    var showLeaveConfirmDialog by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }

    // Intercept back button if batch has unsaved items
    BackHandler {
        if (batchItems.isNotEmpty()) {
            showLeaveConfirmDialog = true
        } else {
            viewModel.navigateBack()
        }
    }

    // 0: Single, 1: Batch. Home tiles choose the starting mode; an open batch always stays in batch mode.
    var scanMode by remember {
        mutableStateOf(if (viewModel.batchItems.value.isNotEmpty()) 1 else viewModel.initialScanMode)
    }

    // Phone Camera App fallback launcher
    var photoUri: Uri? by remember { mutableStateOf(null) }
    var photoFile: File? by remember { mutableStateOf(null) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val f = photoFile
        if (success && f != null && f.exists()) {
            coroutineScope.launch {
                // Applies the photo's EXIF rotation so the page is upright
                val bmp = ImageProcessor.importPhoto(f)
                if (bmp != null) {
                    if (scanMode == 0) {
                        viewModel.startSingleCapture(f, bmp)
                    } else {
                        viewModel.addCapturedImage(f, bmp)
                    }
                }
            }
        }
    }

    // Gallery Multi-import
    val pickMultipleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                if (uris.size == 1 && scanMode == 0) {
                    val uri = uris.first()
                    val file = File(context.filesDir, "import_${UUID.randomUUID()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        file.outputStream().use { output -> input.copyTo(output) }
                    }
                    val bmp = ImageProcessor.importPhoto(file)
                    if (bmp != null) {
                        viewModel.startSingleCapture(file, bmp)
                    }
                } else {
                    for (uri in uris) {
                        val file = File(context.filesDir, "import_${UUID.randomUUID()}.jpg")
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            file.outputStream().use { output -> input.copyTo(output) }
                        }
                        val bmp = ImageProcessor.importPhoto(file)
                        if (bmp != null) {
                            viewModel.addCapturedImage(file, bmp)
                        }
                    }
                }
            }
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        // Real-Time CameraX Viewfinder with Optical Document Alignment Frame
        CameraPreview(
            modifier = Modifier.fillMaxSize(),
            lensFacing = lensFacing,
            isFlashOn = isFlashOn,
            guideText = I18n.get("align_document_hint", lang),
            foundText = I18n.get("document_found_hint", lang),
            onCameraBound = { cap, ctrl ->
                imageCapture = cap
                cameraControl = ctrl
            }
        )

        // Top Controls Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (batchItems.isNotEmpty()) {
                        showLeaveConfirmDialog = true
                    } else {
                        viewModel.navigateBack()
                    }
                },
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .testTag("camera_back_btn")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang), tint = Color.White)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Flash toggle
                IconButton(
                    onClick = {
                        isFlashOn = !isFlashOn
                        cameraControl?.enableTorch(isFlashOn)
                    },
                    modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flash",
                        tint = if (isFlashOn) Color.Yellow else Color.White
                    )
                }

                // Switch Camera
                IconButton(
                    onClick = {
                        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                            CameraSelector.LENS_FACING_FRONT
                        } else {
                            CameraSelector.LENS_FACING_BACK
                        }
                    },
                    modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(Icons.Default.FlipCameraAndroid, contentDescription = I18n.get("switch_cam", lang), tint = Color.White)
                }
            }
        }

        // Bottom Controls Overlay
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.6f))
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Batch Thumbnail Strip if items exist
            if (batchItems.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    batchItems.forEachIndexed { idx, item ->
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                        ) {
                            AsyncImage(
                                model = item.originalFile,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(bottomStart = 4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("${idx + 1}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    // Button to open Batch Review
                    Button(
                        onClick = { viewModel.navigateTo(Screen.BatchReview) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("review_batch_btn")
                    ) {
                        Text(I18n.get("review_batch", lang, batchItems.size))
                    }
                }
            }

            // Mode selector (Single vs Batch)
            Row(
                modifier = Modifier
                    .padding(bottom = 6.dp)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = scanMode == 0,
                    onClick = { scanMode = 0 },
                    label = { Text(I18n.get("single_mode", lang), fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("mode_single_chip")
                )
                FilterChip(
                    selected = scanMode == 1,
                    onClick = { scanMode = 1 },
                    label = { Text(I18n.get("batch_mode", lang), fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("mode_batch_chip")
                )
            }

            // Capture action bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Import from Gallery
                IconButton(
                    onClick = {
                        pickMultipleLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.size(50.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = I18n.get("import_gallery", lang),
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Shutter Button
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(if (isCapturing) Color.LightGray else Color.White)
                        .clickable(enabled = !isCapturing) {
                            val cap = imageCapture ?: return@clickable
                            isCapturing = true
                            val file = File(context.filesDir, "cap_${UUID.randomUUID()}.jpg")
                            val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()

                            cap.takePicture(
                                outputOptions,
                                ContextCompat.getMainExecutor(context),
                                object : ImageCapture.OnImageSavedCallback {
                                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                        coroutineScope.launch {
                                            // Fix orientation (EXIF) before the page is shown anywhere
                                            val bmp = ImageProcessor.importPhoto(file)
                                            isCapturing = false
                                            if (bmp != null) {
                                                if (scanMode == 0) {
                                                    viewModel.startSingleCapture(file, bmp)
                                                } else {
                                                    viewModel.addCapturedImage(file, bmp)
                                                }
                                            }
                                        }
                                    }

                                    override fun onError(exception: ImageCaptureException) {
                                        isCapturing = false
                                        exception.printStackTrace()
                                    }
                                }
                            )
                        }
                        .testTag("camera_shutter_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCapturing) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.primary)
                    }
                }

                // Phone Camera App Fallback
                IconButton(
                    onClick = {
                        val f = File(context.filesDir, "phone_cam_${UUID.randomUUID()}.jpg")
                        photoFile = f
                        val u = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                        photoUri = u
                        takePictureLauncher.launch(u)
                    },
                    modifier = Modifier.size(50.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Camera,
                        contentDescription = I18n.get("phone_camera_fallback", lang),
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }

    // Leave Batch Confirmation Dialog
    if (showLeaveConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLeaveConfirmDialog = false },
            title = { Text(I18n.get("confirm", lang)) },
            text = { Text(I18n.get("confirm_leave_batch", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        showLeaveConfirmDialog = false
                        viewModel.batchItems.value = emptyList()
                        viewModel.navigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(I18n.get("leave", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showLeaveConfirmDialog = false }) {
                    Text(I18n.get("stay", lang))
                }
            }
        )
    }
}
