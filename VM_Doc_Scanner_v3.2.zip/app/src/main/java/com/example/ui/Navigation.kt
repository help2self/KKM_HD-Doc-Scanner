package com.example.ui

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Library : Screen("library")
    object CameraCapture : Screen("camera")
    object BatchReview : Screen("batch_review")
    object CornerEditor : Screen("corner_editor")
    object PageEditor : Screen("page_editor")
    object DocumentDetail : Screen("document_detail")
    object Composer : Screen("composer")
    object PassportSheet : Screen("passport_sheet")
    object Export : Screen("export")
    object Storage : Screen("storage")
    object Settings : Screen("settings")
    object PrintView : Screen("print_view")
}
