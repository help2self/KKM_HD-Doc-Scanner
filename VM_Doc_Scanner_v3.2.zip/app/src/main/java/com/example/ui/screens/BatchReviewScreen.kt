package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.FilterType
import com.example.i18n.I18n
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatchReviewScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val lang by viewModel.language.collectAsState()
    val batchItems by viewModel.batchItems.collectAsState()
    var showNameDialog by remember { mutableStateOf(false) }
    var docName by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = I18n.get("review_batch", lang, batchItems.size),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.initialScanMode = 1
                        viewModel.navigateTo(Screen.CameraCapture)
                    }) {
                        Icon(imageVector = Icons.Default.AddAPhoto, contentDescription = "Add page")
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            viewModel.initialScanMode = 1
                            viewModel.navigateTo(Screen.CameraCapture)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get("add", lang))
                    }

                    Button(
                        onClick = { showNameDialog = true },
                        enabled = batchItems.isNotEmpty(),
                        modifier = Modifier
                            .weight(2f)
                            .testTag("finish_batch_btn")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(I18n.get("finish_batch", lang))
                    }
                }
            }
        }
    ) { padding ->
        if (batchItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = I18n.get("no_scans_yet", lang),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
            // One tap sets the same filter on every page of the batch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = I18n.get("apply_all_pages", lang),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val batchFilters = listOf(
                    FilterType.MAGIC_COLOR to "filter_magic_color",
                    FilterType.ORIGINAL to "filter_original",
                    FilterType.DOCUMENT_BW to "filter_doc_bw",
                    FilterType.BW2 to "filter_bw2",
                    FilterType.GRAYSCALE to "filter_grayscale",
                    FilterType.REMOVE_SHADOW to "filter_remove_shadow"
                )
                batchFilters.forEach { (f, key) ->
                    FilterChip(
                        selected = batchItems.isNotEmpty() && batchItems.all { it.filter == f },
                        onClick = { viewModel.setFilterForAllBatchItems(f) },
                        label = { Text(I18n.get(key, lang)) }
                    )
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 150.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(batchItems, key = { _, item -> item.id }) { index, item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.72f),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = item.originalFile,
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Page order badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(bottomEnd = 8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }

                            // Actions row on item
                            Row(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(topStart = 8.dp))
                                    .padding(4.dp)
                            ) {
                                // Corner editor button
                                IconButton(
                                    onClick = { viewModel.editBatchItemCorners(item) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Crop,
                                        contentDescription = "Crop",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                // Delete page
                                IconButton(
                                    onClick = { viewModel.removeBatchItem(item.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            }
        }
    }

    // Finish Document Dialog with Name input
    if (showNameDialog) {
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text(I18n.get("finish_batch", lang)) },
            text = {
                OutlinedTextField(
                    value = docName,
                    onValueChange = { docName = it },
                    placeholder = { Text(I18n.defaultScanName(System.currentTimeMillis())) },
                    label = { Text(I18n.get("sort_name", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("batch_doc_name_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNameDialog = false
                        viewModel.finishBatch(docName) {
                            viewModel.navigateTo(Screen.DocumentDetail)
                        }
                    },
                    modifier = Modifier.testTag("confirm_finish_batch_btn")
                ) {
                    Text(I18n.get("save", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showNameDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }
}
