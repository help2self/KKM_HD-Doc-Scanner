package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Calm neutral palette with professional Scan Blue accent (#1D4ED8 / #3B82F6)
val BluePrimaryLight = Color(0xFF1D4ED8)
val BlueOnPrimaryLight = Color(0xFFFFFFFF)
val BluePrimaryContainerLight = Color(0xFFDBEAFE)
val BlueOnPrimaryContainerLight = Color(0xFF1E3A8A)

val BluePrimaryDark = Color(0xFF60A5FA)
val BlueOnPrimaryDark = Color(0xFF0F172A)
val BluePrimaryContainerDark = Color(0xFF1E3A8A)
val BlueOnPrimaryContainerDark = Color(0xFFDBEAFE)

val SlateSecondaryLight = Color(0xFF475569)
val SlateSecondaryDark = Color(0xFF94A3B8)

val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF8FAFC)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)

val SurfaceDark = Color(0xFF1E293B)
val BackgroundDark = Color(0xFF0F172A)
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF334155)
val OnSurfaceVariantDark = Color(0xFFCBD5E1)

val ErrorLight = Color(0xFFDC2626)
val ErrorContainerLight = Color(0xFFFEE2E2)
val OnErrorContainerLight = Color(0xFF991B1B)

val ErrorDark = Color(0xFFEF4444)
val ErrorContainerDark = Color(0xFF7F1D1D)
val OnErrorContainerDark = Color(0xFFFEE2E2)
