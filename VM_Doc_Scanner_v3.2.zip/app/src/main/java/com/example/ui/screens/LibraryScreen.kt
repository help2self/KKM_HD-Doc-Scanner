package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.data.local.DocumentEntity
import com.example.data.local.FolderEntity
import com.example.data.local.TagEntity
import com.example.i18n.I18n
import com.example.i18n.Language
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import com.example.ui.viewmodel.SortOption
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File

/** What a confirmation dialog is about to delete. */
private sealed class PendingDelete {
    data class Folder(val folder: FolderEntity) : PendingDelete()
    data class Tag(val tag: TagEntity) : PendingDelete()
    data class Docs(val docs: List<DocumentEntity>) : PendingDelete()
}

private fun docHasTag(doc: DocumentEntity, tagId: String): Boolean = try {
    val arr = JSONArray(doc.tagIdsJson)
    (0 until arr.length()).any { arr.optString(it) == tagId }
} catch (e: Exception) {
    false
}

/**
 * Library laid out like a file manager:
 *  - The title is a folder switcher ("All docs (41) ▾").
 *  - Folders appear as folder tiles at the top of the grid; long-press for Rename / Delete.
 *  - Nothing is deleted without a confirmation dialog (folders, tags and documents).
 *  - Grid / list view toggle, sort menu and a multi-select mode use the whole screen.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val docs by viewModel.allDocuments.collectAsState()
    val folders by viewModel.allFolders.collectAsState()
    val tags by viewModel.allTags.collectAsState()
    val previews by viewModel.docPreviews.collectAsState()
    val isGrid by viewModel.libraryGridView.collectAsState()

    val search by viewModel.searchQuery.collectAsState()
    val selectedFolder by viewModel.selectedFolderId.collectAsState()
    val selectedTag by viewModel.selectedTagId.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()

    var showSearch by remember { mutableStateOf(search.isNotBlank()) }
    var folderMenuOpen by remember { mutableStateOf(false) }
    var sortMenuOpen by remember { mutableStateOf(false) }
    var overflowOpen by remember { mutableStateOf(false) }

    var selectionMode by remember { mutableStateOf(false) }
    val selectedDocIds = remember { mutableStateListOf<String>() }

    // Dialogs
    var nameDialogTitle by remember { mutableStateOf<String?>(null) }
    var nameDialogValue by remember { mutableStateOf("") }
    var nameDialogAction by remember { mutableStateOf<(String) -> Unit>({}) }
    var pendingDelete by remember { mutableStateOf<PendingDelete?>(null) }
    var folderOptions by remember { mutableStateOf<FolderEntity?>(null) }
    var tagOptions by remember { mutableStateOf<TagEntity?>(null) }
    var showMoveDialog by remember { mutableStateOf(false) }
    var showTagAssignDialog by remember { mutableStateOf(false) }

    fun askName(title: String, initial: String, onOk: (String) -> Unit) {
        nameDialogTitle = title
        nameDialogValue = initial
        nameDialogAction = onOk
    }

    fun exitSelection() {
        selectionMode = false
        selectedDocIds.clear()
    }

    BackHandler {
        when {
            selectionMode -> exitSelection()
            showSearch && search.isNotBlank() -> { viewModel.searchQuery.value = ""; showSearch = false }
            selectedFolder != null -> viewModel.selectedFolderId.value = null
            else -> viewModel.navigateBack()
        }
    }

    val filteredDocs = remember(docs, search, selectedFolder, selectedTag, sortOption) {
        var list = docs.filter { doc ->
            val q = search.trim().lowercase()
            val matchesSearch = q.isEmpty() || doc.name.lowercase().contains(q)
            val matchesFolder = when (selectedFolder) {
                null -> true
                "none" -> doc.folderId == null
                else -> doc.folderId == selectedFolder
            }
            val matchesTag = selectedTag == null || docHasTag(doc, selectedTag!!)
            matchesSearch && matchesFolder && matchesTag
        }
        list = when (sortOption) {
            SortOption.DATE -> list.sortedByDescending { it.updatedAt }
            SortOption.NAME -> list.sortedBy { it.name.lowercase() }
            SortOption.SIZE -> list.sortedByDescending { previews[it.id]?.second ?: 0 }
        }
        list
    }

    // Folder tiles only on the top level ("All docs") without search/tag filter
    val showFolderTiles = selectedFolder == null && search.isBlank() && selectedTag == null
    val currentFolderName = when (selectedFolder) {
        null -> I18n.get("all_docs", lang)
        "none" -> I18n.get("no_folder", lang)
        else -> folders.find { it.id == selectedFolder }?.name ?: I18n.get("all_docs", lang)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            if (selectionMode) {
                TopAppBar(
                    title = { Text(I18n.get("n_selected", lang, selectedDocIds.size), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { exitSelection() }) { Icon(Icons.Default.Close, contentDescription = I18n.get("cancel", lang)) }
                    },
                    actions = {
                        IconButton(onClick = {
                            if (selectedDocIds.size == filteredDocs.size) selectedDocIds.clear()
                            else { selectedDocIds.clear(); selectedDocIds.addAll(filteredDocs.map { it.id }) }
                        }) { Icon(Icons.Default.SelectAll, contentDescription = I18n.get("select_all", lang)) }
                        IconButton(enabled = selectedDocIds.isNotEmpty(), onClick = { showMoveDialog = true }) {
                            Icon(Icons.Default.DriveFileMove, contentDescription = I18n.get("move_to_folder", lang))
                        }
                        IconButton(enabled = selectedDocIds.isNotEmpty() && tags.isNotEmpty(), onClick = { showTagAssignDialog = true }) {
                            Icon(Icons.Default.Label, contentDescription = I18n.get("tags", lang))
                        }
                        IconButton(enabled = selectedDocIds.isNotEmpty(), onClick = {
                            pendingDelete = PendingDelete.Docs(docs.filter { it.id in selectedDocIds })
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = I18n.get("delete", lang), tint = MaterialTheme.colorScheme.error)
                        }
                    }
                )
            } else {
                TopAppBar(
                    title = {
                        // Folder switcher
                        Box {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .combinedClickable(onClick = { folderMenuOpen = true })
                                    .padding(vertical = 4.dp)
                                    .testTag("library_folder_switcher")
                            ) {
                                if (selectedFolder != null) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(22.dp))
                                    Spacer(Modifier.width(6.dp))
                                }
                                Text(
                                    "$currentFolderName (${filteredDocs.size})",
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                            DropdownMenu(expanded = folderMenuOpen, onDismissRequest = { folderMenuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("${I18n.get("all_docs", lang)} (${docs.size})") },
                                    leadingIcon = { Icon(Icons.Default.Description, null) },
                                    onClick = { viewModel.selectedFolderId.value = null; folderMenuOpen = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("${I18n.get("no_folder", lang)} (${docs.count { it.folderId == null }})") },
                                    leadingIcon = { Icon(Icons.Default.FolderOff, null) },
                                    onClick = { viewModel.selectedFolderId.value = "none"; folderMenuOpen = false }
                                )
                                folders.forEach { f ->
                                    DropdownMenuItem(
                                        text = { Text("${f.name} (${docs.count { it.folderId == f.id }})") },
                                        leadingIcon = { Icon(Icons.Default.Folder, null, tint = Color(0xFFF59E0B)) },
                                        onClick = { viewModel.selectedFolderId.value = f.id; folderMenuOpen = false }
                                    )
                                }
                                Divider()
                                DropdownMenuItem(
                                    text = { Text(I18n.get("create_folder", lang)) },
                                    leadingIcon = { Icon(Icons.Default.CreateNewFolder, null) },
                                    onClick = {
                                        folderMenuOpen = false
                                        askName(I18n.get("create_folder", lang), "") { name ->
                                            coroutineScope.launch { viewModel.repository.createFolder(name) }
                                        }
                                    }
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        if (selectedFolder != null) {
                            IconButton(onClick = { viewModel.selectedFolderId.value = null }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            showSearch = !showSearch
                            if (!showSearch) viewModel.searchQuery.value = ""
                        }) { Icon(Icons.Default.Search, contentDescription = I18n.get("search_hint", lang)) }
                        IconButton(
                            onClick = {
                                askName(I18n.get("create_folder", lang), "") { name ->
                                    coroutineScope.launch { viewModel.repository.createFolder(name) }
                                }
                            },
                            modifier = Modifier.testTag("new_folder_btn")
                        ) { Icon(Icons.Default.CreateNewFolder, contentDescription = I18n.get("create_folder", lang)) }
                        Box {
                            IconButton(onClick = { sortMenuOpen = true }) { Icon(Icons.Default.Sort, contentDescription = I18n.get("sort", lang)) }
                            DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                                listOf(
                                    SortOption.DATE to I18n.get("sort_date", lang),
                                    SortOption.NAME to I18n.get("sort_name", lang),
                                    SortOption.SIZE to I18n.get("sort_pages", lang)
                                ).forEach { (opt, label) ->
                                    DropdownMenuItem(
                                        text = { Text(label) },
                                        trailingIcon = { if (sortOption == opt) Icon(Icons.Default.Check, null) },
                                        onClick = { viewModel.sortOption.value = opt; sortMenuOpen = false }
                                    )
                                }
                            }
                        }
                        IconButton(onClick = { viewModel.setLibraryGridView(!isGrid) }, modifier = Modifier.testTag("view_toggle_btn")) {
                            Icon(
                                if (isGrid) Icons.Default.ViewList else Icons.Default.GridView,
                                contentDescription = I18n.get("change_view", lang)
                            )
                        }
                        Box {
                            IconButton(onClick = { overflowOpen = true }) { Icon(Icons.Default.MoreVert, contentDescription = null) }
                            DropdownMenu(expanded = overflowOpen, onDismissRequest = { overflowOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text(I18n.get("select_docs", lang)) },
                                    leadingIcon = { Icon(Icons.Default.CheckCircleOutline, null) },
                                    onClick = { overflowOpen = false; selectionMode = true }
                                )
                                DropdownMenuItem(
                                    text = { Text(I18n.get("create_tag", lang)) },
                                    leadingIcon = { Icon(Icons.Default.BookmarkAdd, null) },
                                    onClick = {
                                        overflowOpen = false
                                        askName(I18n.get("create_tag", lang), "") { name ->
                                            coroutineScope.launch { viewModel.repository.createTag(name, "#3B82F6") }
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(I18n.get("export_csv", lang)) },
                                    leadingIcon = { Icon(Icons.Default.FileDownload, null) },
                                    onClick = {
                                        overflowOpen = false
                                        coroutineScope.launch {
                                            try {
                                                val csvFile = viewModel.repository.exportLibraryCsv(lang)
                                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", csvFile)
                                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/csv"
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(sendIntent, "CSV"))
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (showSearch) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { viewModel.searchQuery.value = it },
                    placeholder = { Text(I18n.get("search_hint", lang)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (search.isNotBlank()) {
                            IconButton(onClick = { viewModel.searchQuery.value = "" }) { Icon(Icons.Default.Clear, contentDescription = null) }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("library_search_input"),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Tags: small filter chips. No delete crosses here; long-press a tag for Rename / Delete.
            if (tags.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Label, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    tags.forEach { t ->
                        val sel = selectedTag == t.id
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .combinedClickable(
                                    onClick = { viewModel.selectedTagId.value = if (sel) null else t.id },
                                    onLongClick = { tagOptions = t }
                                )
                        ) {
                            Text(
                                "#${t.name}",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            val nothingToShow = filteredDocs.isEmpty() && !(showFolderTiles && folders.isNotEmpty())
            if (nothingToShow) {
                Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = I18n.get("no_scans_yet", lang),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = if (isGrid) GridCells.Adaptive(minSize = 108.dp) else GridCells.Fixed(1),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 6.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (showFolderTiles && !selectionMode) {
                        items(folders, key = { "f_" + it.id }) { f ->
                            FolderTile(
                                folder = f,
                                count = docs.count { it.folderId == f.id },
                                isGrid = isGrid,
                                onOpen = { viewModel.selectedFolderId.value = f.id },
                                onOptions = { folderOptions = f }
                            )
                        }
                    }
                    items(filteredDocs, key = { it.id }) { doc ->
                        val pv = previews[doc.id]
                        val isSel = doc.id in selectedDocIds
                        DocTile(
                            doc = doc,
                            thumbPath = pv?.first,
                            pageCount = pv?.second ?: 0,
                            lang = lang,
                            isGrid = isGrid,
                            selectionMode = selectionMode,
                            isSelected = isSel,
                            onClick = {
                                if (selectionMode) {
                                    if (isSel) selectedDocIds.remove(doc.id) else selectedDocIds.add(doc.id)
                                } else {
                                    viewModel.activeDocumentId.value = doc.id
                                    viewModel.navigateTo(Screen.DocumentDetail)
                                }
                            },
                            onLongClick = {
                                if (!selectionMode) selectionMode = true
                                if (!isSel) selectedDocIds.add(doc.id)
                            }
                        )
                    }
                }
            }
        }
    }

    // ---------- Dialogs ----------

    nameDialogTitle?.let { title ->
        AlertDialog(
            onDismissRequest = { nameDialogTitle = null },
            title = { Text(title) },
            text = {
                OutlinedTextField(
                    value = nameDialogValue,
                    onValueChange = { nameDialogValue = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (nameDialogValue.isNotBlank()) {
                        nameDialogAction(nameDialogValue.trim())
                        nameDialogTitle = null
                    }
                }) { Text(I18n.get("save", lang)) }
            },
            dismissButton = { TextButton(onClick = { nameDialogTitle = null }) { Text(I18n.get("cancel", lang)) } }
        )
    }

    folderOptions?.let { f ->
        AlertDialog(
            onDismissRequest = { folderOptions = null },
            icon = { Icon(Icons.Default.Folder, null, tint = Color(0xFFF59E0B)) },
            title = { Text(f.name) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text(I18n.get("open", lang)) },
                        leadingContent = { Icon(Icons.Default.FolderOpen, null) },
                        modifier = Modifier.combinedClickable(onClick = { viewModel.selectedFolderId.value = f.id; folderOptions = null })
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("rename", lang)) },
                        leadingContent = { Icon(Icons.Default.Edit, null) },
                        modifier = Modifier.combinedClickable(onClick = {
                            folderOptions = null
                            askName(I18n.get("rename", lang), f.name) { n -> coroutineScope.launch { viewModel.repository.renameFolder(f, n) } }
                        })
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("delete", lang), color = MaterialTheme.colorScheme.error) },
                        leadingContent = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) },
                        modifier = Modifier.combinedClickable(onClick = { folderOptions = null; pendingDelete = PendingDelete.Folder(f) })
                    )
                }
            },
            confirmButton = { TextButton(onClick = { folderOptions = null }) { Text(I18n.get("cancel", lang)) } }
        )
    }

    tagOptions?.let { t ->
        AlertDialog(
            onDismissRequest = { tagOptions = null },
            icon = { Icon(Icons.Default.Label, null) },
            title = { Text("#${t.name}") },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text(I18n.get("rename", lang)) },
                        leadingContent = { Icon(Icons.Default.Edit, null) },
                        modifier = Modifier.combinedClickable(onClick = {
                            tagOptions = null
                            askName(I18n.get("rename", lang), t.name) { n -> coroutineScope.launch { viewModel.repository.renameTag(t, n) } }
                        })
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("delete", lang), color = MaterialTheme.colorScheme.error) },
                        leadingContent = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) },
                        modifier = Modifier.combinedClickable(onClick = { tagOptions = null; pendingDelete = PendingDelete.Tag(t) })
                    )
                }
            },
            confirmButton = { TextButton(onClick = { tagOptions = null }) { Text(I18n.get("cancel", lang)) } }
        )
    }

    // Every delete is confirmed first
    pendingDelete?.let { pd ->
        val (title, message) = when (pd) {
            is PendingDelete.Folder -> I18n.get("delete_folder_title", lang) to I18n.get("delete_folder_msg", lang, pd.folder.name)
            is PendingDelete.Tag -> I18n.get("delete_tag_title", lang) to I18n.get("delete_tag_msg", lang, pd.tag.name)
            is PendingDelete.Docs -> I18n.get("delete_doc", lang) to I18n.get("delete_docs_msg", lang, pd.docs.size)
        }
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            icon = { Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error) },
            title = { Text(title) },
            text = { Text(message) },
            confirmButton = {
                Button(
                    onClick = {
                        when (pd) {
                            is PendingDelete.Folder -> coroutineScope.launch {
                                viewModel.repository.deleteFolder(pd.folder)
                                if (viewModel.selectedFolderId.value == pd.folder.id) viewModel.selectedFolderId.value = null
                            }
                            is PendingDelete.Tag -> coroutineScope.launch {
                                viewModel.repository.deleteTag(pd.tag)
                                if (viewModel.selectedTagId.value == pd.tag.id) viewModel.selectedTagId.value = null
                            }
                            is PendingDelete.Docs -> {
                                pd.docs.forEach { viewModel.deleteDocument(it) }
                                exitSelection()
                            }
                        }
                        pendingDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_btn")
                ) { Text(I18n.get("delete", lang)) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text(I18n.get("cancel", lang)) } }
        )
    }

    if (showMoveDialog) {
        AlertDialog(
            onDismissRequest = { showMoveDialog = false },
            title = { Text(I18n.get("move_to_folder", lang)) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text(I18n.get("no_folder", lang)) },
                        leadingContent = { Icon(Icons.Default.FolderOff, null) },
                        modifier = Modifier.combinedClickable(onClick = {
                            selectedDocIds.forEach { viewModel.setDocumentFolder(it, null) }
                            showMoveDialog = false
                            exitSelection()
                        })
                    )
                    folders.forEach { f ->
                        ListItem(
                            headlineContent = { Text(f.name) },
                            leadingContent = { Icon(Icons.Default.Folder, null, tint = Color(0xFFF59E0B)) },
                            modifier = Modifier.combinedClickable(onClick = {
                                selectedDocIds.forEach { viewModel.setDocumentFolder(it, f.id) }
                                showMoveDialog = false
                                exitSelection()
                            })
                        )
                    }
                    ListItem(
                        headlineContent = { Text(I18n.get("create_folder", lang)) },
                        leadingContent = { Icon(Icons.Default.CreateNewFolder, null) },
                        modifier = Modifier.combinedClickable(onClick = {
                            showMoveDialog = false
                            askName(I18n.get("create_folder", lang), "") { name ->
                                coroutineScope.launch { viewModel.repository.createFolder(name) }
                            }
                        })
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showMoveDialog = false }) { Text(I18n.get("cancel", lang)) } }
        )
    }

    if (showTagAssignDialog) {
        AlertDialog(
            onDismissRequest = { showTagAssignDialog = false },
            title = { Text(I18n.get("add_tag_to_selected", lang)) },
            text = {
                Column {
                    tags.forEach { t ->
                        ListItem(
                            headlineContent = { Text("#${t.name}") },
                            modifier = Modifier.combinedClickable(onClick = {
                                // add the tag to every selected document that does not have it yet
                                docs.filter { it.id in selectedDocIds && !docHasTag(it, t.id) }
                                    .forEach { viewModel.toggleDocumentTag(it.id, t.id) }
                                showTagAssignDialog = false
                                exitSelection()
                            })
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTagAssignDialog = false }) { Text(I18n.get("cancel", lang)) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderTile(
    folder: FolderEntity,
    count: Int,
    isGrid: Boolean,
    onOpen: () -> Unit,
    onOptions: () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    if (isGrid) {
        Card(
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7E6)),
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.78f)
                .clip(shape)
                .combinedClickable(onClick = onOpen, onLongClick = onOptions)
                .testTag("folder_tile_${folder.id}")
        ) {
            Box(Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Folder, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(56.dp))
                    Text(folder.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium, color = Color(0xFF1F2937))
                    Text("$count", style = MaterialTheme.typography.labelSmall, color = Color(0xFF6B7280))
                }
                IconButton(onClick = onOptions, modifier = Modifier.align(Alignment.TopEnd).size(32.dp)) {
                    Icon(Icons.Default.MoreVert, contentDescription = null, tint = Color(0xFF6B7280), modifier = Modifier.size(18.dp))
                }
            }
        }
    } else {
        Card(
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7E6)),
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .combinedClickable(onClick = onOpen, onLongClick = onOptions)
        ) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Folder, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(folder.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color(0xFF1F2937))
                    Text("$count", style = MaterialTheme.typography.labelSmall, color = Color(0xFF6B7280))
                }
                IconButton(onClick = onOptions) { Icon(Icons.Default.MoreVert, contentDescription = null, tint = Color(0xFF6B7280)) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DocTile(
    doc: DocumentEntity,
    thumbPath: String?,
    pageCount: Int,
    lang: Language,
    isGrid: Boolean,
    selectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val shape = RoundedCornerShape(10.dp)
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent

    @Composable
    fun Thumb(mod: Modifier) {
        Box(mod.background(Color(0xFFF1F5F9)), contentAlignment = Alignment.Center) {
            if (thumbPath != null) {
                AsyncImage(
                    model = File(thumbPath),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Default.Description, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(32.dp))
            }
        }
    }

    @Composable
    fun SelectMark(mod: Modifier) {
        if (selectionMode) {
            Box(
                mod
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.85f))
                    .border(1.5.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
            }
        }
    }

    if (isGrid) {
        Card(
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, borderColor, shape)
                .clip(shape)
                .combinedClickable(onClick = onClick, onLongClick = onLongClick)
                .testTag("document_card_${doc.id}")
        ) {
            Column {
                Box(Modifier.fillMaxWidth().aspectRatio(0.82f)) {
                    Thumb(Modifier.fillMaxSize())
                    if (pageCount > 0) {
                        Text(
                            "$pageCount",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(4.dp)
                                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                    SelectMark(Modifier.align(Alignment.TopEnd).padding(4.dp))
                }
                Column(Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
                    Text(
                        doc.name,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        I18n.formatDate(doc.updatedAt, lang),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    } else {
        Card(
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, borderColor, shape)
                .clip(shape)
                .combinedClickable(onClick = onClick, onLongClick = onLongClick)
                .testTag("document_card_${doc.id}")
        ) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Thumb(Modifier.size(52.dp, 66.dp).clip(RoundedCornerShape(6.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(doc.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        I18n.formatDateTime(doc.updatedAt, lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        I18n.get("pages_count", lang, pageCount),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                SelectMark(Modifier)
            }
        }
    }
}
