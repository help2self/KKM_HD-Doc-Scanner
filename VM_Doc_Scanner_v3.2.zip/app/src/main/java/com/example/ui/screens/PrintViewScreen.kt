package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun PrintViewScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val pages by viewModel.activeDocumentPages.collectAsState()

    fun triggerPrint() {
        coroutineScope.launch {
            if (pages.isNotEmpty()) {
                val firstFile = File(if (pages.first().originalImagePath.isNotBlank()) pages.first().originalImagePath else pages.first().thumbnailImagePath)
                if (firstFile.exists()) {
                    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", firstFile)
                    val printIntent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "image/*")
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    try {
                        context.startActivity(printIntent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.White)) {
        // Clean, chrome-free pages list
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(pages) { page ->
                val imgFile = File(if (page.originalImagePath.isNotBlank()) page.originalImagePath else page.thumbnailImagePath)
                AsyncImage(
                    model = imgFile,
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth(),
                    contentScale = ContentScale.FillWidth
                )
            }
        }

        // Floating Close and Print Actions
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FloatingActionButton(
                onClick = { triggerPrint() },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(48.dp).testTag("print_doc_btn")
            ) {
                Icon(Icons.Default.Print, contentDescription = I18n.get("print_action", lang), modifier = Modifier.size(22.dp))
            }

            FloatingActionButton(
                onClick = { viewModel.navigateBack() },
                containerColor = Color.Black.copy(alpha = 0.7f),
                contentColor = Color.White,
                modifier = Modifier.size(48.dp).testTag("close_print_view_btn")
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(22.dp))
            }
        }
    }
}
