package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.PageEntity
import com.example.i18n.I18n
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentDetailScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()
    val activeDocId by viewModel.activeDocumentId.collectAsState()
    val docs by viewModel.allDocuments.collectAsState()
    val pages by viewModel.activeDocumentPages.collectAsState()
    val folders by viewModel.allFolders.collectAsState()
    val tags by viewModel.allTags.collectAsState()

    val currentDoc = docs.find { it.id == activeDocId }

    var isEditingName by remember { mutableStateOf(false) }
    var editedName by remember { mutableStateOf("") }

    var isEditingNotes by remember { mutableStateOf(false) }
    var notesText by remember { mutableStateOf(currentDoc?.notes ?: "") }

    var showFolderDialog by remember { mutableStateOf(false) }
    var showTagDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var pageToDelete by remember { mutableStateOf<PageEntity?>(null) }

    LaunchedEffect(currentDoc) {
        if (currentDoc != null) {
            notesText = currentDoc.notes
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            editedName = currentDoc?.name ?: ""
                            isEditingName = true
                        }
                    ) {
                        Text(
                            text = currentDoc?.name ?: I18n.get("document_view", lang),
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            modifier = Modifier.testTag("doc_title_text")
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Rename",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.PrintView) }) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = I18n.get("print", lang))
                    }
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.Export) },
                        modifier = Modifier.testTag("export_doc_top_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = I18n.get("export", lang))
                    }
                    IconButton(onClick = { showDeleteConfirmDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = I18n.get("delete", lang),
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.initialScanMode = 0; viewModel.navigateTo(Screen.CameraCapture) }, // adds pages to this document
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get("scan_document", lang), style = MaterialTheme.typography.bodySmall)
                    }

                    Button(
                        onClick = { viewModel.navigateTo(Screen.Export) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("export_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(I18n.get("export", lang))
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Folder and Tag Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val currentFolder = folders.find { it.id == currentDoc?.folderId }
                AssistChip(
                    onClick = { showFolderDialog = true },
                    label = { Text(currentFolder?.name ?: I18n.get("folder", lang)) },
                    leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("folder_chip")
                )

                AssistChip(
                    onClick = { showTagDialog = true },
                    label = { Text(I18n.get("tags", lang)) },
                    leadingIcon = { Icon(Icons.Default.Label, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("tag_chip")
                )

                Text(
                    text = I18n.get("pages_count", lang, pages.size),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            // Grid of Pages
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 140.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(pages, key = { _, page -> page.id }) { index, page ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.72f)
                            .clickable {
                                viewModel.activeEditingPage.value = page
                                viewModel.navigateTo(Screen.PageEditor)
                            }
                            .testTag("page_card_$index"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            val imgFile = File(if (page.thumbnailImagePath.isNotBlank()) page.thumbnailImagePath else page.originalImagePath)
                            AsyncImage(
                                model = imgFile,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Page number badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(bottomEnd = 8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }

                            // Duplicate & Delete Actions
                            Row(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(topStart = 8.dp))
                                    .padding(2.dp)
                            ) {
                                IconButton(
                                    onClick = { viewModel.duplicatePage(page) },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = I18n.get("duplicate_page", lang),
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { pageToDelete = page },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = I18n.get("delete", lang),
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Rename Dialog
    if (isEditingName) {
        AlertDialog(
            onDismissRequest = { isEditingName = false },
            title = { Text(I18n.get("rename", lang)) },
            text = {
                OutlinedTextField(
                    value = editedName,
                    onValueChange = { editedName = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("rename_input")
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (editedName.isNotBlank() && activeDocId != null) {
                        viewModel.renameDocument(activeDocId!!, editedName)
                        isEditingName = false
                    }
                }) {
                    Text(I18n.get("save", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { isEditingName = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Delete single page confirmation
    pageToDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { pageToDelete = null },
            title = { Text(I18n.get("delete_page_title", lang)) },
            text = { Text(I18n.get("delete_page_confirm", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePage(p)
                        pageToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(I18n.get("delete", lang)) }
            },
            dismissButton = {
                TextButton(onClick = { pageToDelete = null }) { Text(I18n.get("cancel", lang)) }
            }
        )
    }

    // Delete Confirm Dialog
    if (showDeleteConfirmDialog && currentDoc != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text(I18n.get("delete_doc", lang)) },
            text = { Text(I18n.get("confirm_delete_doc", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        viewModel.deleteDocument(currentDoc)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(I18n.get("delete", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Folder Selector Dialog
    if (showFolderDialog && currentDoc != null) {
        AlertDialog(
            onDismissRequest = { showFolderDialog = false },
            title = { Text(I18n.get("folder", lang)) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text(I18n.get("no_folder", lang)) },
                        modifier = Modifier.clickable {
                            viewModel.setDocumentFolder(currentDoc.id, null)
                            showFolderDialog = false
                        }
                    )
                    folders.forEach { f ->
                        ListItem(
                            headlineContent = { Text(f.name) },
                            modifier = Modifier.clickable {
                                viewModel.setDocumentFolder(currentDoc.id, f.id)
                                showFolderDialog = false
                            }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFolderDialog = false }) {
                    Text(I18n.get("done", lang))
                }
            }
        )
    }

    // Tag Selector Dialog
    if (showTagDialog && currentDoc != null) {
        AlertDialog(
            onDismissRequest = { showTagDialog = false },
            title = { Text(I18n.get("tags", lang)) },
            text = {
                Column {
                    tags.forEach { t ->
                        val hasTag = try {
                            val arr = JSONArray(currentDoc.tagIdsJson)
                            var found = false
                            for (i in 0 until arr.length()) {
                                if (arr.optString(i) == t.id) { found = true; break }
                            }
                            found
                        } catch (e: Exception) { false }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.toggleDocumentTag(currentDoc.id, t.id) }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(checked = hasTag, onCheckedChange = { viewModel.toggleDocumentTag(currentDoc.id, t.id) })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("#${t.name}")
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showTagDialog = false }) {
                    Text(I18n.get("done", lang))
                }
            }
        )
    }
}
