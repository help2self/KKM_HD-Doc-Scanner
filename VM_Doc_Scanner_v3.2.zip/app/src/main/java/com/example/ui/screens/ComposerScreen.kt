package com.example.ui.screens

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.i18n.I18n
import com.example.processing.ImageProcessor
import com.example.ui.Screen
import com.example.ui.viewmodel.ScannerViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

private val HandleBlue = Color(0xFF2563EB)
private val HandleRed = Color(0xFFDC2626)

/** Rotates vector (x, y) by [deg] degrees. */
private fun rot(x: Float, y: Float, deg: Float): Offset {
    val r = Math.toRadians(deg.toDouble())
    val c = cos(r).toFloat()
    val s = sin(r).toFloat()
    return Offset(x * c - y * s, x * s + y * c)
}

private fun normDeg(d: Float): Float {
    var a = d % 360f
    if (a > 180f) a -= 360f
    if (a < -180f) a += 360f
    return a
}

/** Handle positions of an object, in page millimetres. */
private class ObjHandles(val center: Offset, val delete: Offset, val rotate: Offset, val resize: Offset)

private fun handlesFor(o: ComposedObject, handleGapMm: Float): ObjHandles {
    val c = Offset(o.xMm + o.widthMm / 2f, o.yMm + o.heightMm / 2f)
    val hw = o.widthMm / 2f
    val hh = o.heightMm / 2f
    return ObjHandles(
        center = c,
        delete = c + rot(hw, -hh, o.rotationDeg),
        rotate = c + rot(0f, -hh - handleGapMm, o.rotationDeg),
        resize = c + rot(hw, hh, o.rotationDeg)
    )
}

/** True when page point [p] (mm) lies inside the rotated object. */
private fun hitObject(o: ComposedObject, p: Offset): Boolean {
    val c = Offset(o.xMm + o.widthMm / 2f, o.yMm + o.heightMm / 2f)
    val local = rot(p.x - c.x, p.y - c.y, -o.rotationDeg)
    return kotlin.math.abs(local.x) <= o.widthMm / 2f && kotlin.math.abs(local.y) <= o.heightMm / 2f
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposerScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lang by viewModel.language.collectAsState()

    val config by viewModel.composerConfig.collectAsState()
    val objects by viewModel.composerObjects.collectAsState()
    val selectedId by viewModel.selectedObjectId.collectAsState()

    val composerHistory by viewModel.composerHistory.collectAsState()
    val composerRedoStack by viewModel.composerRedoStack.collectAsState()

    var showLayoutMenu by remember { mutableStateOf(false) }
    var showPageConfigDialog by remember { mutableStateOf(false) }
    var showAddTextDialog by remember { mutableStateOf(false) }
    var newTextValue by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }

    val activeObject = objects.find { it.id == selectedId }

    val effW = if (config.orientation == PageOrientation.PORTRAIT) config.widthMm else config.heightMm
    val effH = if (config.orientation == PageOrientation.PORTRAIT) config.heightMm else config.widthMm

    // Multi-image picker: every picture keeps its own shape (no stretching)
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val newObjs = viewModel.composerObjects.value.toMutableList()
                var offset = 0f
                var lastId: String? = null
                for (uri in uris) {
                    val file = File(context.filesDir, "comp_${UUID.randomUUID()}.jpg")
                    try {
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                            context.contentResolver.openInputStream(uri)?.use { input ->
                                file.outputStream().use { output -> input.copyTo(output) }
                            }
                        }
                    } catch (e: Exception) {
                        continue
                    }
                    // Make it upright on disk and read its proportions
                    val bmp = ImageProcessor.importPhoto(file, previewEdge = 1600)
                    val aspect = if (bmp != null && bmp.height > 0) bmp.width.toFloat() / bmp.height else 4f / 3f
                    bmp?.recycle()

                    var itemW = (effW - 2 * config.marginMm) * 0.6f
                    var itemH = itemW / aspect
                    val maxH = (effH - 2 * config.marginMm) * 0.6f
                    if (itemH > maxH) {
                        itemH = maxH
                        itemW = itemH * aspect
                    }
                    val obj = ComposedObject(
                        id = UUID.randomUUID().toString(),
                        type = ObjectType.IMAGE,
                        imagePath = file.absolutePath,
                        xMm = (config.marginMm + offset).coerceAtMost(effW - itemW),
                        yMm = (config.marginMm + offset).coerceAtMost(effH - itemH),
                        widthMm = itemW,
                        heightMm = itemH,
                        layer = (newObjs.maxOfOrNull { it.layer } ?: 0) + 1,
                        lockAspectRatio = true
                    )
                    newObjs.add(obj)
                    lastId = obj.id
                    offset += 12f
                }
                viewModel.updateComposerObjects(newObjs)
                viewModel.selectedObjectId.value = lastId
            }
        }
    }

    fun updateActive(transform: (ComposedObject) -> ComposedObject) {
        val id = viewModel.selectedObjectId.value ?: return
        viewModel.updateComposerObjects(viewModel.composerObjects.value.map { if (it.id == id) transform(it) else it })
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(I18n.get("composer_title", lang), fontWeight = FontWeight.Bold, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = I18n.get("back", lang))
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.undoComposer() },
                        enabled = composerHistory.isNotEmpty(),
                        modifier = Modifier.testTag("composer_undo_btn")
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = I18n.get("undo", lang))
                    }
                    IconButton(
                        onClick = { viewModel.redoComposer() },
                        enabled = composerRedoStack.isNotEmpty(),
                        modifier = Modifier.testTag("composer_redo_btn")
                    ) {
                        Icon(Icons.Default.Redo, contentDescription = I18n.get("redo", lang))
                    }
                    IconButton(onClick = { showPageConfigDialog = true }) {
                        Icon(Icons.Default.Tune, contentDescription = I18n.get("page_size", lang))
                    }
                    TextButton(
                        enabled = objects.isNotEmpty() && !isSaving,
                        onClick = {
                            isSaving = true
                            viewModel.selectedObjectId.value = null
                            // Always saved as its own new document; the composer is cleared afterwards
                            viewModel.saveComposedPage(null) {
                                isSaving = false
                                viewModel.navigateTo(Screen.DocumentDetail)
                            }
                        },
                        modifier = Modifier.testTag("save_composed_btn")
                    ) {
                        Text(I18n.get("save", lang), fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    if (activeObject != null) {
                        // Only what is not on the picture itself: copy, layer, lock and a rotate slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            IconButton(onClick = {
                                val dup = activeObject.copy(
                                    id = UUID.randomUUID().toString(),
                                    xMm = (activeObject.xMm + 8f).coerceAtMost(effW - activeObject.widthMm),
                                    yMm = (activeObject.yMm + 8f).coerceAtMost(effH - activeObject.heightMm),
                                    layer = (objects.maxOfOrNull { it.layer } ?: 0) + 1,
                                    isLocked = false
                                )
                                viewModel.updateComposerObjects(objects + dup)
                                viewModel.selectedObjectId.value = dup.id
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = I18n.get("duplicate", lang))
                            }
                            IconButton(onClick = {
                                val maxLayer = objects.maxOfOrNull { it.layer } ?: 0
                                updateActive { it.copy(layer = maxLayer + 1) }
                            }) {
                                Icon(Icons.Default.FlipToFront, contentDescription = I18n.get("bring_front", lang))
                            }
                            IconButton(onClick = {
                                val minLayer = objects.minOfOrNull { it.layer } ?: 0
                                updateActive { it.copy(layer = minLayer - 1) }
                            }) {
                                Icon(Icons.Default.FlipToBack, contentDescription = I18n.get("send_back", lang))
                            }
                            IconButton(onClick = { updateActive { it.copy(isLocked = !it.isLocked) } }) {
                                Icon(
                                    imageVector = if (activeObject.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                    contentDescription = I18n.get("lock", lang),
                                    tint = if (activeObject.isLocked) MaterialTheme.colorScheme.primary else LocalContentColor.current
                                )
                            }
                            IconButton(onClick = { updateActive { it.copy(lockAspectRatio = !it.lockAspectRatio) } }) {
                                Icon(
                                    imageVector = if (activeObject.lockAspectRatio) Icons.Default.AspectRatio else Icons.Default.OpenInFull,
                                    contentDescription = I18n.get("keep_ratio", lang),
                                    tint = if (activeObject.lockAspectRatio) MaterialTheme.colorScheme.primary else LocalContentColor.current
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            var sliderVal by remember(activeObject.id) { mutableStateOf(normDeg(activeObject.rotationDeg)) }
                            LaunchedEffect(activeObject.rotationDeg) { sliderVal = normDeg(activeObject.rotationDeg) }
                            Slider(
                                value = sliderVal,
                                onValueChange = { v ->
                                    // snap to straight angles
                                    val snapped = listOf(-180f, -90f, 0f, 90f, 180f).firstOrNull { kotlin.math.abs(it - v) < 3f } ?: v
                                    sliderVal = snapped
                                    val id = activeObject.id
                                    viewModel.composerObjects.value = viewModel.composerObjects.value.map {
                                        if (it.id == id) it.copy(rotationDeg = snapped) else it
                                    }
                                },
                                onValueChangeFinished = {
                                    // record one undo step for the whole slide
                                    viewModel.updateComposerObjects(viewModel.composerObjects.value)
                                },
                                valueRange = -180f..180f,
                                enabled = !activeObject.isLocked,
                                modifier = Modifier.weight(1f).testTag("composer_rotate_slider")
                            )
                            Text("${sliderVal.roundToInt()}°", style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(44.dp))
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    pickMultipleImagesLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.testTag("import_images_btn")
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(I18n.get("import_images", lang), style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(
                                onClick = { showLayoutMenu = true },
                                modifier = Modifier.testTag("ready_layouts_btn")
                            ) {
                                Icon(Icons.Default.ViewQuilt, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(I18n.get("ready_layouts", lang), style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(
                                onClick = { showAddTextDialog = true },
                                modifier = Modifier.testTag("add_textbox_btn")
                            ) {
                                Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(I18n.get("add_textbox", lang), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 6.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                val density = LocalDensity.current
                // Page uses almost all of the available space
                val mmToDp = minOf(maxWidth.value / effW, maxHeight.value / effH) * 0.98f
                val canvasWidthDp = (effW * mmToDp).dp
                val canvasHeightDp = (effH * mmToDp).dp
                val pxPerMm = with(density) { mmToDp.dp.toPx() }
                val handleRadiusPx = with(density) { 13.dp.toPx() }
                val handleGapMm = with(density) { 28.dp.toPx() } / pxPerMm
                val hitRadiusMm = with(density) { 26.dp.toPx() } / pxPerMm

                val pxState = rememberUpdatedState(pxPerMm)
                val gapState = rememberUpdatedState(handleGapMm)
                val hitState = rememberUpdatedState(hitRadiusMm)
                val pageState = rememberUpdatedState(Pair(effW, effH))

                // Drag modes: 0 none, 1 move, 2 rotate, 3 resize
                var dragMode by remember { mutableStateOf(0) }

                Surface(
                    modifier = Modifier
                        .size(canvasWidthDp, canvasHeightDp)
                        .testTag("composed_page_canvas"),
                    color = Color(config.backgroundColor),
                    shadowElevation = 8.dp
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (config.showGrid) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val stepPx = 10f * (size.width / effW)
                                var x = 0f
                                while (x < size.width) {
                                    drawLine(Color(0xFFE2E8F0), Offset(x, 0f), Offset(x, size.height), 1f)
                                    x += stepPx
                                }
                                var y = 0f
                                while (y < size.height) {
                                    drawLine(Color(0xFFE2E8F0), Offset(0f, y), Offset(size.width, y), 1f)
                                    y += stepPx
                                }
                            }
                        }

                        // Objects, each drawn at its exact size, position and angle
                        objects.sortedBy { it.layer }.forEach { obj ->
                            Box(
                                modifier = Modifier
                                    .offset(x = (obj.xMm * mmToDp).dp, y = (obj.yMm * mmToDp).dp)
                                    .size((obj.widthMm * mmToDp).dp, (obj.heightMm * mmToDp).dp)
                                    .graphicsLayer { rotationZ = obj.rotationDeg }
                            ) {
                                if (obj.type == ObjectType.IMAGE && obj.imagePath != null) {
                                    AsyncImage(
                                        model = File(obj.imagePath),
                                        contentDescription = null,
                                        contentScale = ContentScale.FillBounds,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else if (obj.type == ObjectType.TEXT && obj.text != null) {
                                    val fontSp = with(density) { (obj.fontSizeSp * 25.4f / 160f * mmToDp).dp.toSp() }
                                    Text(
                                        text = obj.text,
                                        color = Color(obj.fontColor),
                                        fontSize = fontSp,
                                        modifier = Modifier.padding(2.dp)
                                    )
                                }
                                if (obj.borderWidthMm > 0f) {
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        drawRect(Color(obj.borderColor), style = Stroke(width = obj.borderWidthMm * pxPerMm))
                                    }
                                }
                            }
                        }

                        // Selection frame + on-picture controls (delete, rotate, resize)
                        val sel = activeObject
                        if (sel != null) {
                            val deleteIcon = rememberVectorPainter(Icons.Default.Close)
                            val rotateIcon = rememberVectorPainter(Icons.Default.Refresh)
                            val resizeIcon = rememberVectorPainter(Icons.Default.OpenInFull)
                            val lockIcon = rememberVectorPainter(Icons.Default.Lock)
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val h = handlesFor(sel, handleGapMm)
                                val c = h.center * pxPerMm
                                val wPx = sel.widthMm * pxPerMm
                                val hPx = sel.heightMm * pxPerMm
                                rotate(sel.rotationDeg, pivot = c) {
                                    drawRect(
                                        color = HandleBlue,
                                        topLeft = Offset(c.x - wPx / 2f, c.y - hPx / 2f),
                                        size = androidx.compose.ui.geometry.Size(wPx, hPx),
                                        style = Stroke(width = 2.dp.toPx())
                                    )
                                    if (!sel.isLocked) {
                                        drawLine(
                                            HandleBlue,
                                            Offset(c.x, c.y - hPx / 2f),
                                            Offset(c.x, c.y - hPx / 2f - handleGapMm * pxPerMm + handleRadiusPx),
                                            2.dp.toPx()
                                        )
                                    }
                                }
                                fun drawHandle(center: Offset, color: Color, painter: androidx.compose.ui.graphics.painter.Painter) {
                                    drawCircle(Color.White, handleRadiusPx + 2.dp.toPx(), center)
                                    drawCircle(color, handleRadiusPx, center)
                                    val iconSize = handleRadiusPx * 1.3f
                                    translate(center.x - iconSize / 2f, center.y - iconSize / 2f) {
                                        with(painter) {
                                            draw(
                                                androidx.compose.ui.geometry.Size(iconSize, iconSize),
                                                colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(Color.White)
                                            )
                                        }
                                    }
                                }
                                drawHandle(h.delete * pxPerMm, HandleRed, deleteIcon)
                                if (!sel.isLocked) {
                                    drawHandle(h.rotate * pxPerMm, HandleBlue, rotateIcon)
                                    drawHandle(h.resize * pxPerMm, HandleBlue, resizeIcon)
                                } else {
                                    drawHandle(h.resize * pxPerMm, Color.Gray, lockIcon)
                                }
                            }
                        }

                        // One gesture layer for the whole page
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectTapGestures { pos ->
                                        val p = pos / pxState.value
                                        val list = viewModel.composerObjects.value
                                        val current = list.find { it.id == viewModel.selectedObjectId.value }
                                        if (current != null) {
                                            val h = handlesFor(current, gapState.value)
                                            if ((h.delete - p).getDistance() <= hitState.value) {
                                                viewModel.updateComposerObjects(list.filter { it.id != current.id })
                                                viewModel.selectedObjectId.value = null
                                                return@detectTapGestures
                                            }
                                        }
                                        val hit = list.sortedByDescending { it.layer }.firstOrNull { hitObject(it, p) }
                                        viewModel.selectedObjectId.value = hit?.id
                                    }
                                }
                                .pointerInput(Unit) {
                                    var startList: List<ComposedObject> = emptyList()
                                    detectDragGestures(
                                        onDragStart = { pos ->
                                            val p = pos / pxState.value
                                            val list = viewModel.composerObjects.value
                                            startList = list
                                            val current = list.find { it.id == viewModel.selectedObjectId.value }
                                            dragMode = 0
                                            if (current != null && !current.isLocked) {
                                                val h = handlesFor(current, gapState.value)
                                                when {
                                                    (h.rotate - p).getDistance() <= hitState.value -> dragMode = 2
                                                    (h.resize - p).getDistance() <= hitState.value -> dragMode = 3
                                                    hitObject(current, p) -> dragMode = 1
                                                }
                                            }
                                            if (dragMode == 0) {
                                                val hit = list.sortedByDescending { it.layer }.firstOrNull { hitObject(it, p) }
                                                if (hit != null) {
                                                    viewModel.selectedObjectId.value = hit.id
                                                    if (!hit.isLocked) dragMode = 1
                                                }
                                            }
                                        },
                                        onDrag = { change, dragAmount ->
                                            if (dragMode == 0) return@detectDragGestures
                                            change.consume()
                                            val id = viewModel.selectedObjectId.value ?: return@detectDragGestures
                                            val pxMm = pxState.value
                                            val (pw, ph) = pageState.value
                                            val p = change.position / pxMm
                                            viewModel.composerObjects.value = viewModel.composerObjects.value.map { o ->
                                                if (o.id != id) return@map o
                                                when (dragMode) {
                                                    1 -> {
                                                        val dx = dragAmount.x / pxMm
                                                        val dy = dragAmount.y / pxMm
                                                        o.copy(
                                                            xMm = (o.xMm + dx).coerceIn(-o.widthMm / 2f, pw - o.widthMm / 2f),
                                                            yMm = (o.yMm + dy).coerceIn(-o.heightMm / 2f, ph - o.heightMm / 2f)
                                                        )
                                                    }
                                                    2 -> {
                                                        val c = Offset(o.xMm + o.widthMm / 2f, o.yMm + o.heightMm / 2f)
                                                        var ang = Math.toDegrees(atan2((p.y - c.y).toDouble(), (p.x - c.x).toDouble())).toFloat() + 90f
                                                        ang = normDeg(ang)
                                                        val snap = listOf(-180f, -90f, 0f, 90f, 180f).firstOrNull { kotlin.math.abs(it - ang) < 4f }
                                                        o.copy(rotationDeg = snap ?: ang)
                                                    }
                                                    3 -> {
                                                        // The opposite (top-left) corner stays where it is
                                                        val c = Offset(o.xMm + o.widthMm / 2f, o.yMm + o.heightMm / 2f)
                                                        val tl = c + rot(-o.widthMm / 2f, -o.heightMm / 2f, o.rotationDeg)
                                                        val v = rot(p.x - tl.x, p.y - tl.y, -o.rotationDeg)
                                                        var nw = max(5f, v.x)
                                                        var nh = max(5f, v.y)
                                                        if (o.lockAspectRatio && o.widthMm > 0f && o.heightMm > 0f) {
                                                            val s = max(nw / o.widthMm, nh / o.heightMm)
                                                            nw = max(5f, o.widthMm * s)
                                                            nh = max(5f, o.heightMm * s)
                                                        }
                                                        val nc = tl + rot(nw / 2f, nh / 2f, o.rotationDeg)
                                                        o.copy(xMm = nc.x - nw / 2f, yMm = nc.y - nh / 2f, widthMm = nw, heightMm = nh)
                                                    }
                                                    else -> o
                                                }
                                            }
                                        },
                                        onDragEnd = {
                                            if (dragMode != 0) {
                                                // one undo step per gesture
                                                val finalList = viewModel.composerObjects.value
                                                viewModel.composerObjects.value = startList
                                                viewModel.updateComposerObjects(finalList)
                                            }
                                            dragMode = 0
                                        },
                                        onDragCancel = { dragMode = 0 }
                                    )
                                }
                        )
                    }
                }

                if (objects.isEmpty()) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.align(Alignment.Center)
                    ) {
                        Text(
                            I18n.get("composer_empty_hint", lang),
                            color = Color.White,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }
    }

    // Ready Layouts Bottom Sheet / Dialog
    if (showLayoutMenu) {
        val existingPaths = objects.mapNotNull { it.imagePath }
        AlertDialog(
            onDismissRequest = { showLayoutMenu = false },
            title = { Text(I18n.get("ready_layouts", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_1", lang)) },
                        modifier = Modifier.clickable {
                            showLayoutMenu = false
                            viewModel.applyReadyLayout("1", existingPaths)
                        }
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_2", lang)) },
                        modifier = Modifier.clickable {
                            showLayoutMenu = false
                            viewModel.applyReadyLayout("2", existingPaths)
                        }
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_4", lang)) },
                        modifier = Modifier.clickable {
                            showLayoutMenu = false
                            viewModel.applyReadyLayout("4", existingPaths)
                        }
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_6", lang)) },
                        modifier = Modifier.clickable {
                            showLayoutMenu = false
                            viewModel.applyReadyLayout("6", existingPaths)
                        }
                    )
                    ListItem(
                        headlineContent = { Text(I18n.get("layout_id_card", lang)) },
                        supportingContent = { Text("A4 page • 2 cards at true size 85.6 x 54 mm") },
                        modifier = Modifier
                            .clickable {
                                showLayoutMenu = false
                                viewModel.applyReadyLayout("id_card", existingPaths)
                            }
                            .testTag("layout_id_card_item")
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showLayoutMenu = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Add Text Dialog
    if (showAddTextDialog) {
        AlertDialog(
            onDismissRequest = { showAddTextDialog = false },
            title = { Text(I18n.get("add_textbox", lang)) },
            text = {
                OutlinedTextField(
                    value = newTextValue,
                    onValueChange = { newTextValue = it },
                    placeholder = { Text("Enter text here...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newTextValue.isNotBlank()) {
                        val txtObj = ComposedObject(
                            id = UUID.randomUUID().toString(),
                            type = ObjectType.TEXT,
                            text = newTextValue,
                            xMm = config.marginMm,
                            yMm = config.marginMm + 30f,
                            widthMm = 100f,
                            heightMm = 25f,
                            layer = objects.size
                        )
                        viewModel.updateComposerObjects(objects + txtObj)
                        viewModel.selectedObjectId.value = txtObj.id
                        newTextValue = ""
                        showAddTextDialog = false
                    }
                }) {
                    Text(I18n.get("add", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTextDialog = false }) {
                    Text(I18n.get("cancel", lang))
                }
            }
        )
    }

    // Page Config Dialog
    if (showPageConfigDialog) {
        AlertDialog(
            onDismissRequest = { showPageConfigDialog = false },
            title = { Text(I18n.get("page_size", lang)) },
            text = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.composerConfig.value = config.copy(orientation = PageOrientation.PORTRAIT)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(I18n.get("portrait", lang))
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel.composerConfig.value = config.copy(orientation = PageOrientation.LANDSCAPE)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(I18n.get("landscape", lang))
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    PageSizePreset.values().forEach { preset ->
                        ListItem(
                            headlineContent = { Text(preset.displayName) },
                            supportingContent = { Text("${preset.widthMm} x ${preset.heightMm} mm") },
                            modifier = Modifier.clickable {
                                viewModel.composerConfig.value = config.copy(
                                    preset = preset,
                                    widthMm = preset.widthMm,
                                    heightMm = preset.heightMm
                                )
                                showPageConfigDialog = false
                            }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPageConfigDialog = false }) {
                    Text(I18n.get("done", lang))
                }
            }
        )
    }
}
