package com.example

import com.example.ui.Screen

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.i18n.I18n
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ScannerViewModel
import com.example.ui.viewmodel.ThemeMode

class MainActivity : ComponentActivity() {

    private val viewModel: ScannerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Opened from Gallery / another app with "Share -> VM Doc Scanner"
        if (savedInstanceState == null) handleShareIntent(intent)

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val isDark = when (themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            MyApplicationTheme(darkTheme = isDark) {
                MainAppContent(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleShareIntent(intent: Intent?) {
        if (intent == null) return
        val uris: List<Uri> = when (intent.action) {
            Intent.ACTION_SEND -> {
                val u: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
                }
                listOfNotNull(u ?: intent.data)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val list: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                }
                list ?: emptyList()
            }
            Intent.ACTION_VIEW -> listOfNotNull(intent.data)
            else -> emptyList()
        }
        if (uris.isNotEmpty()) {
            viewModel.importSharedImages(uris)
            // consume it so a screen rotation does not import the same pictures again
            intent.action = Intent.ACTION_MAIN
        }
    }
}

@Composable
fun MainAppContent(viewModel: ScannerViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val lang by viewModel.language.collectAsState()

    // Determine whether to show the bottom navigation bar
    val showBottomBar = currentScreen is Screen.Home ||
            currentScreen is Screen.Library ||
            currentScreen is Screen.Composer ||
            currentScreen is Screen.PassportSheet ||
            currentScreen is Screen.Storage ||
            currentScreen is Screen.Settings

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(modifier = Modifier.testTag("main_bottom_nav")) {
                    NavigationBarItem(
                        selected = currentScreen is Screen.Home,
                        onClick = { viewModel.navigateTo(Screen.Home) },
                        icon = { Icon(Icons.Default.Home, contentDescription = I18n.get("home", lang)) },
                        label = { Text(I18n.get("home", lang)) },
                        modifier = Modifier.testTag("nav_item_home")
                    )
                    NavigationBarItem(
                        selected = currentScreen is Screen.Library,
                        onClick = { viewModel.navigateTo(Screen.Library) },
                        icon = { Icon(Icons.Default.Folder, contentDescription = I18n.get("library", lang)) },
                        label = { Text(I18n.get("library", lang)) },
                        modifier = Modifier.testTag("nav_item_library")
                    )
                    NavigationBarItem(
                        selected = currentScreen is Screen.CameraCapture,
                        onClick = { viewModel.startNewScan(0) },
                        icon = { Icon(Icons.Default.CameraAlt, contentDescription = I18n.get("scan_document", lang)) },
                        label = { Text(I18n.get("shutter", lang)) },
                        modifier = Modifier.testTag("nav_item_scan")
                    )
                    NavigationBarItem(
                        selected = currentScreen is Screen.Composer,
                        onClick = { viewModel.openComposer() },
                        icon = { Icon(Icons.Default.DashboardCustomize, contentDescription = I18n.get("composer", lang)) },
                        label = { Text(I18n.get("composer", lang)) },
                        modifier = Modifier.testTag("nav_item_composer")
                    )
                    NavigationBarItem(
                        selected = currentScreen is Screen.Settings,
                        onClick = { viewModel.navigateTo(Screen.Settings) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = I18n.get("settings", lang)) },
                        label = { Text(I18n.get("settings", lang)) },
                        modifier = Modifier.testTag("nav_item_settings")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                is Screen.Home -> HomeScreen(viewModel = viewModel)
                is Screen.Library -> LibraryScreen(viewModel = viewModel)
                is Screen.CameraCapture -> CameraCaptureScreen(viewModel = viewModel)
                is Screen.BatchReview -> BatchReviewScreen(viewModel = viewModel)
                is Screen.CornerEditor -> CornerEditorScreen(viewModel = viewModel)
                is Screen.PageEditor -> PageEditorScreen(viewModel = viewModel)
                is Screen.DocumentDetail -> DocumentDetailScreen(viewModel = viewModel)
                is Screen.Composer -> ComposerScreen(viewModel = viewModel)
                is Screen.PassportSheet -> PassportSheetScreen(viewModel = viewModel)
                is Screen.Export -> ExportScreen(viewModel = viewModel)
                is Screen.Storage -> StorageScreen(viewModel = viewModel)
                is Screen.Settings -> SettingsScreen(viewModel = viewModel)
                is Screen.PrintView -> PrintViewScreen(viewModel = viewModel)
            }
        }
    }
}
