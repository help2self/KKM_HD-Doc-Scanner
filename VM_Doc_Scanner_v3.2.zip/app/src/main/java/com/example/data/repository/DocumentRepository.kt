package com.example.data.repository

import android.content.Context
import android.os.Environment
import com.example.data.local.AppDatabase
import com.example.data.local.DocumentEntity
import com.example.data.local.FolderEntity
import com.example.data.local.PageEntity
import com.example.data.local.TagEntity
import com.example.data.model.StorageInfo
import com.example.i18n.I18n
import com.example.i18n.Language
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class DocumentRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val docDao = db.documentDao()
    private val pageDao = db.pageDao()
    private val folderDao = db.folderDao()
    private val tagDao = db.tagDao()

    // Simulation states for Acceptance Test 12
    var isSimulated80: Boolean = false
    var isSimulated95: Boolean = false
    var isSimulatedQuotaError: Boolean = false

    fun getAllDocuments(): Flow<List<DocumentEntity>> = docDao.getAllDocuments()
    fun getPagesForDocument(documentId: String): Flow<List<PageEntity>> = pageDao.getPagesForDocument(documentId)
    fun getAllFolders(): Flow<List<FolderEntity>> = folderDao.getAllFolders()
    fun getAllTags(): Flow<List<TagEntity>> = tagDao.getAllTags()
    fun getTotalPagesCount(): Flow<Int> = pageDao.getTotalPagesCount()
    fun getAllPages(): Flow<List<PageEntity>> = pageDao.getAllPagesFlow()

    suspend fun getDocumentById(id: String): DocumentEntity? = withContext(Dispatchers.IO) {
        docDao.getDocumentById(id)
    }

    suspend fun getPagesForDocumentSync(documentId: String): List<PageEntity> = withContext(Dispatchers.IO) {
        pageDao.getPagesForDocumentSync(documentId)
    }

    suspend fun saveDocument(document: DocumentEntity) = withContext(Dispatchers.IO) {
        if (isSimulatedQuotaError) {
            throw IllegalStateException("SIMULATED_QUOTA_EXCEEDED")
        }
        // IMPORTANT: never use INSERT OR REPLACE for an existing document. REPLACE deletes the old
        // row first and the foreign key (ON DELETE CASCADE) then deletes all of its pages, which is
        // why typing a note / renaming / changing folder made the document's images disappear.
        if (docDao.getDocumentById(document.id) != null) {
            docDao.updateDocument(document)
        } else {
            docDao.insertDocument(document)
        }
    }

    suspend fun savePage(page: PageEntity) = withContext(Dispatchers.IO) {
        if (isSimulatedQuotaError) {
            throw IllegalStateException("SIMULATED_QUOTA_EXCEEDED")
        }
        pageDao.insertPage(page)
    }

    suspend fun savePages(pages: List<PageEntity>) = withContext(Dispatchers.IO) {
        if (isSimulatedQuotaError) {
            throw IllegalStateException("SIMULATED_QUOTA_EXCEEDED")
        }
        pageDao.insertPages(pages)
    }

    suspend fun deleteDocument(document: DocumentEntity) = withContext(Dispatchers.IO) {
        val pages = pageDao.getPagesForDocumentSync(document.id)
        for (page in pages) {
            deletePageFiles(page)
        }
        docDao.deleteDocument(document)
    }

    suspend fun deletePage(page: PageEntity) = withContext(Dispatchers.IO) {
        deletePageFiles(page)
        pageDao.deletePage(page)
    }

    private fun deletePageFiles(page: PageEntity) {
        try {
            if (page.originalImagePath.isNotBlank()) {
                File(page.originalImagePath).delete()
            }
            if (page.thumbnailImagePath.isNotBlank()) {
                File(page.thumbnailImagePath).delete()
            }
            File(context.filesDir, "base_${page.id}.jpg").delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun duplicatePage(page: PageEntity) = withContext(Dispatchers.IO) {
        val newId = UUID.randomUUID().toString()
        val originalFile = File(page.originalImagePath)
        var newOriginalPath = ""
        if (originalFile.exists()) {
            val copyFile = File(context.filesDir, "copy_${newId}.jpg")
            originalFile.copyTo(copyFile, overwrite = true)
            newOriginalPath = copyFile.absolutePath
        }

        val thumbFile = File(page.thumbnailImagePath)
        var newThumbPath = ""
        if (thumbFile.exists()) {
            val copyThumb = File(context.filesDir, "copy_thumb_${newId}.jpg")
            thumbFile.copyTo(copyThumb, overwrite = true)
            newThumbPath = copyThumb.absolutePath
        }

        val baseFile = File(context.filesDir, "base_${page.id}.jpg")
        if (baseFile.exists()) baseFile.copyTo(File(context.filesDir, "base_${newId}.jpg"), overwrite = true)

        val currentPages = pageDao.getPagesForDocumentSync(page.documentId)
        val duplicate = page.copy(
            id = newId,
            pageOrder = currentPages.size,
            originalImagePath = newOriginalPath,
            thumbnailImagePath = newThumbPath
        )
        pageDao.insertPage(duplicate)
    }

    suspend fun reorderPages(documentId: String, newOrder: List<PageEntity>) = withContext(Dispatchers.IO) {
        val updated = newOrder.mapIndexed { index, p -> p.copy(pageOrder = index) }
        pageDao.insertPages(updated)
    }

    suspend fun renameFolder(folder: FolderEntity, newName: String) = withContext(Dispatchers.IO) {
        folderDao.insertFolder(folder.copy(name = newName.trim()))
    }

    suspend fun renameTag(tag: TagEntity, newName: String) = withContext(Dispatchers.IO) {
        tagDao.insertTag(tag.copy(name = newName.trim()))
    }

    suspend fun createFolder(name: String) = withContext(Dispatchers.IO) {
        val folder = FolderEntity(id = UUID.randomUUID().toString(), name = name.trim())
        folderDao.insertFolder(folder)
    }

    suspend fun deleteFolder(folder: FolderEntity) = withContext(Dispatchers.IO) {
        // Universal rule: Deleting a folder moves documents to "No folder" (documents are never deleted)
        docDao.clearFolderFromDocuments(folder.id)
        folderDao.deleteFolder(folder)
    }

    suspend fun createTag(name: String, colorHex: String) = withContext(Dispatchers.IO) {
        val tag = TagEntity(id = UUID.randomUUID().toString(), name = name.trim(), colorHex = colorHex)
        tagDao.insertTag(tag)
    }

    suspend fun deleteTag(tag: TagEntity) = withContext(Dispatchers.IO) {
        // Universal rule: Deleting a tag removes it from documents but never deletes documents
        val docs = docDao.getAllDocumentsSync()
        for (doc in docs) {
            try {
                val array = JSONArray(doc.tagIdsJson)
                val newArray = JSONArray()
                var changed = false
                for (i in 0 until array.length()) {
                    val tid = array.optString(i)
                    if (tid == tag.id) {
                        changed = true
                    } else {
                        newArray.put(tid)
                    }
                }
                if (changed) {
                    docDao.updateDocument(doc.copy(tagIdsJson = newArray.toString()))
                }
            } catch (e: Exception) {
                // Ignore json parse error
            }
        }
        tagDao.deleteTag(tag)
    }

    suspend fun calculateStorageInfo(): StorageInfo = withContext(Dispatchers.IO) {
        var usedBytes = 0L
        fun addDirSize(dir: File) {
            dir.listFiles()?.forEach { file ->
                if (file.isDirectory) addDirSize(file)
                else usedBytes += file.length()
            }
        }
        addDirSize(context.filesDir)
        addDirSize(context.cacheDir)

        val freeSpace = context.filesDir.usableSpace
        val totalSpace = context.filesDir.totalSpace.coerceAtLeast(1024L * 1024L * 1024L)

        // Simulation overrides for testing
        if (isSimulated80) {
            val simTotal = 1000L * 1024L * 1024L
            return@withContext StorageInfo(
                usedBytes = 810L * 1024L * 1024L,
                availableBytes = 190L * 1024L * 1024L,
                totalBytes = simTotal,
                percent = 81,
                isPersistentGranted = true,
                isSimulated80 = true,
                isSimulated95 = false,
                isSimulatedQuotaError = isSimulatedQuotaError
            )
        }

        if (isSimulated95) {
            val simTotal = 1000L * 1024L * 1024L
            return@withContext StorageInfo(
                usedBytes = 960L * 1024L * 1024L,
                availableBytes = 40L * 1024L * 1024L,
                totalBytes = simTotal,
                percent = 96,
                isPersistentGranted = true,
                isSimulated80 = false,
                isSimulated95 = true,
                isSimulatedQuotaError = isSimulatedQuotaError
            )
        }

        val pct = ((usedBytes.toDouble() / totalSpace.toDouble()) * 100).toInt().coerceIn(1, 100)

        StorageInfo(
            usedBytes = usedBytes,
            availableBytes = freeSpace,
            totalBytes = totalSpace,
            percent = pct,
            isPersistentGranted = true,
            isSimulated80 = false,
            isSimulated95 = false,
            isSimulatedQuotaError = isSimulatedQuotaError
        )
    }

    suspend fun getDocumentStorageSize(documentId: String): Long = withContext(Dispatchers.IO) {
        var bytes = 0L
        val pages = pageDao.getPagesForDocumentSync(documentId)
        for (page in pages) {
            if (page.originalImagePath.isNotBlank()) bytes += File(page.originalImagePath).length()
            if (page.thumbnailImagePath.isNotBlank()) bytes += File(page.thumbnailImagePath).length()
        }
        bytes
    }

    suspend fun exportLibraryCsv(lang: Language): File = withContext(Dispatchers.IO) {
        val docs = docDao.getAllDocumentsSync()
        val folders = folderDao.getAllFoldersSync().associateBy { it.id }
        val tags = tagDao.getAllTagsSync().associateBy { it.id }

        val csvFile = File(context.cacheDir, "library_export_${System.currentTimeMillis()}.csv")
        csvFile.bufferedWriter(StandardCharsets.UTF_8).use { writer ->
            writer.write("\uFEFF") // UTF-8 BOM for Excel / Google Sheets compatibility
            writer.write("Document Name,Folder,Tags,Page Count,Created Date,Size (KB),Notes\n")
            for (doc in docs) {
                val folderName = doc.folderId?.let { folders[it]?.name } ?: "None"
                val tagList = mutableListOf<String>()
                try {
                    val arr = JSONArray(doc.tagIdsJson)
                    for (i in 0 until arr.length()) {
                        val t = tags[arr.optString(i)]?.name
                        if (t != null) tagList.add(t)
                    }
                } catch (e: Exception) {}
                val pages = pageDao.getPagesForDocumentSync(doc.id)
                val sizeKb = getDocumentStorageSize(doc.id) / 1024
                val formattedDate = I18n.formatDate(doc.createdAt, lang)
                val cleanNotes = doc.notes.replace("\n", " ").replace("\"", "\"\"")

                writer.write("\"${doc.name}\",\"$folderName\",\"${tagList.joinToString(";")}\",${pages.size},\"$formattedDate\",$sizeKb,\"$cleanNotes\"\n")
            }
        }
        csvFile
    }

    suspend fun createBackupZip(outputZip: File): Boolean = withContext(Dispatchers.IO) {
        try {
            outputZip.parentFile?.mkdirs()
            val docs = docDao.getAllDocumentsSync()
            val pages = pageDao.getAllPagesSync()
            val folders = folderDao.getAllFoldersSync()
            val tags = tagDao.getAllTagsSync()

            val manifest = JSONObject().apply {
                put("version", 1)
                put("createdAt", System.currentTimeMillis())

                val docsArr = JSONArray()
                docs.forEach { d ->
                    docsArr.put(JSONObject().apply {
                        put("id", d.id)
                        put("name", d.name)
                        put("folderId", d.folderId ?: "")
                        put("tagIdsJson", d.tagIdsJson)
                        put("notes", d.notes)
                        put("createdAt", d.createdAt)
                        put("updatedAt", d.updatedAt)
                    })
                }
                put("documents", docsArr)

                val pagesArr = JSONArray()
                pages.forEach { p ->
                    pagesArr.put(JSONObject().apply {
                        put("id", p.id)
                        put("documentId", p.documentId)
                        put("pageOrder", p.pageOrder)
                        put("pageType", p.pageType)
                        put("originalFileName", File(p.originalImagePath).name)
                        put("thumbFileName", File(p.thumbnailImagePath).name)
                        put("editParamsJson", p.editParamsJson)
                        put("cropCornersJson", p.cropCornersJson)
                        put("filterType", p.filterType)
                        put("rotationDeg", p.rotationDeg)
                        put("composedObjectsJson", p.composedObjectsJson)
                        put("composedConfigJson", p.composedConfigJson)
                    })
                }
                put("pages", pagesArr)

                val foldersArr = JSONArray()
                folders.forEach { f ->
                    foldersArr.put(JSONObject().apply {
                        put("id", f.id)
                        put("name", f.name)
                        put("createdAt", f.createdAt)
                    })
                }
                put("folders", foldersArr)

                val tagsArr = JSONArray()
                tags.forEach { t ->
                    tagsArr.put(JSONObject().apply {
                        put("id", t.id)
                        put("name", t.name)
                        put("colorHex", t.colorHex)
                    })
                }
                put("tags", tagsArr)
            }

            ZipOutputStream(BufferedOutputStream(FileOutputStream(outputZip))).use { zos ->
                // Write manifest.json
                val manifestEntry = ZipEntry("manifest.json")
                zos.putNextEntry(manifestEntry)
                zos.write(manifest.toString(2).toByteArray(StandardCharsets.UTF_8))
                zos.closeEntry()

                // Write all images
                val writtenFiles = mutableSetOf<String>()
                pages.forEach { p ->
                    val origFile = File(p.originalImagePath)
                    if (origFile.exists() && writtenFiles.add(origFile.name)) {
                        zos.putNextEntry(ZipEntry("images/${origFile.name}"))
                        origFile.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                    val thumbFile = File(p.thumbnailImagePath)
                    if (thumbFile.exists() && writtenFiles.add(thumbFile.name)) {
                        zos.putNextEntry(ZipEntry("images/${thumbFile.name}"))
                        thumbFile.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun inspectBackupZip(zipFile: File): Pair<Int, Int>? = withContext(Dispatchers.IO) {
        try {
            ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (entry.name == "manifest.json") {
                        val content = zis.bufferedReader(StandardCharsets.UTF_8).readText()
                        val json = JSONObject(content)
                        val docCount = json.optJSONArray("documents")?.length() ?: 0
                        val pageCount = json.optJSONArray("pages")?.length() ?: 0
                        return@withContext Pair(docCount, pageCount)
                    }
                    entry = zis.nextEntry
                }
            }
            null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun restoreBackupZip(zipFile: File): Boolean = withContext(Dispatchers.IO) {
        try {
            var manifestJson: JSONObject? = null
            val imagesDir = File(context.filesDir, "restored_images")
            imagesDir.mkdirs()

            ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (entry.name == "manifest.json") {
                        val content = zis.bufferedReader(StandardCharsets.UTF_8).readText()
                        manifestJson = JSONObject(content)
                    } else if (entry.name.startsWith("images/") && !entry.isDirectory) {
                        val fileName = File(entry.name).name
                        val targetFile = File(context.filesDir, fileName)
                        FileOutputStream(targetFile).use { out ->
                            zis.copyTo(out)
                        }
                    }
                    entry = zis.nextEntry
                }
            }

            val manifest = manifestJson ?: return@withContext false

            // Clear existing and replace
            pageDao.deleteAllPages()
            docDao.deleteAllDocuments()
            folderDao.deleteAllFolders()
            tagDao.deleteAllTags()

            // Restore folders
            val foldersArr = manifest.optJSONArray("folders")
            if (foldersArr != null) {
                for (i in 0 until foldersArr.length()) {
                    val obj = foldersArr.getJSONObject(i)
                    folderDao.insertFolder(FolderEntity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    ))
                }
            }

            // Restore tags
            val tagsArr = manifest.optJSONArray("tags")
            if (tagsArr != null) {
                for (i in 0 until tagsArr.length()) {
                    val obj = tagsArr.getJSONObject(i)
                    tagDao.insertTag(TagEntity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        colorHex = obj.optString("colorHex", "#3B82F6")
                    ))
                }
            }

            // Restore documents
            val docsArr = manifest.optJSONArray("documents")
            if (docsArr != null) {
                for (i in 0 until docsArr.length()) {
                    val obj = docsArr.getJSONObject(i)
                    docDao.insertDocument(DocumentEntity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        folderId = obj.optString("folderId").ifBlank { null },
                        tagIdsJson = obj.optString("tagIdsJson", "[]"),
                        notes = obj.optString("notes", ""),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    ))
                }
            }

            // Restore pages
            val pagesArr = manifest.optJSONArray("pages")
            if (pagesArr != null) {
                for (i in 0 until pagesArr.length()) {
                    val obj = pagesArr.getJSONObject(i)
                    val origName = obj.optString("originalFileName")
                    val thumbName = obj.optString("thumbFileName")
                    pageDao.insertPage(PageEntity(
                        id = obj.getString("id"),
                        documentId = obj.getString("documentId"),
                        pageOrder = obj.getInt("pageOrder"),
                        pageType = obj.optString("pageType", "scan"),
                        originalImagePath = if (origName.isNotBlank()) File(context.filesDir, origName).absolutePath else "",
                        thumbnailImagePath = if (thumbName.isNotBlank()) File(context.filesDir, thumbName).absolutePath else "",
                        editParamsJson = obj.optString("editParamsJson", "{}"),
                        cropCornersJson = obj.optString("cropCornersJson", "{}"),
                        filterType = obj.optString("filterType", "ORIGINAL"),
                        rotationDeg = obj.optInt("rotationDeg", 0),
                        composedObjectsJson = obj.optString("composedObjectsJson", "[]"),
                        composedConfigJson = obj.optString("composedConfigJson", "{}")
                    ))
                }
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun eraseAllData(): Boolean = withContext(Dispatchers.IO) {
        try {
            pageDao.deleteAllPages()
            docDao.deleteAllDocuments()
            folderDao.deleteAllFolders()
            tagDao.deleteAllTags()
            context.filesDir.listFiles()?.forEach { it.deleteRecursively() }
            context.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
