package com.example.data.model

enum class PageType {
    SCAN,
    COMPOSED
}

enum class FilterType {
    ORIGINAL,
    MAGIC_COLOR,
    DOCUMENT_BW,
    BW2,
    GRAYSCALE,
    LIGHTEN,
    AUTO_ENHANCE,
    REMOVE_SHADOW
}

data class EditParameters(
    val brightness: Float = 0f, // -1.0 to 1.0
    val contrast: Float = 1f,   // 0.5 to 2.0
    val sharpness: Float = 0f,  // 0.0 to 2.0
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val straightenAngle: Float = 0f // -45 to 45 degrees
)

data class CornerPoints(
    val tlX: Float = 0f,
    val tlY: Float = 0f,
    val trX: Float = 1f,
    val trY: Float = 0f,
    val brX: Float = 1f,
    val brY: Float = 1f,
    val blX: Float = 0f,
    val blY: Float = 1f
) {
    fun toNormalizedArray(): FloatArray = floatArrayOf(tlX, tlY, trX, trY, brX, brY, blX, blY)

    companion object {
        fun defaultFull(): CornerPoints = CornerPoints(
            tlX = 0f, tlY = 0f,
            trX = 1f, trY = 0f,
            brX = 1f, brY = 1f,
            blX = 0f, blY = 1f
        )
    }
}

enum class PageSizePreset(val displayName: String, val widthMm: Float, val heightMm: Float) {
    A4("A4", 210f, 297f),
    A5("A5", 148f, 210f),
    A3("A3", 297f, 420f),
    LETTER("Letter", 215.9f, 279.4f),
    LEGAL("Legal", 215.9f, 355.6f),
    PASSPORT_SHEET("4x6 Photo", 101.6f, 152.4f),
    CUSTOM("Custom", 210f, 297f)
}

enum class PageOrientation {
    PORTRAIT,
    LANDSCAPE
}

enum class ObjectType {
    IMAGE,
    TEXT
}

data class ComposedObject(
    val id: String,
    val type: ObjectType = ObjectType.IMAGE,
    val imagePath: String? = null,
    val text: String? = null,
    val fontSizeSp: Float = 18f,
    val fontColor: Int = 0xFF1E293B.toInt(),
    val xMm: Float,
    val yMm: Float,
    val widthMm: Float,
    val heightMm: Float,
    val rotationDeg: Float = 0f,
    val layer: Int = 0,
    val isLocked: Boolean = false,
    val borderWidthMm: Float = 0f,
    val borderColor: Int = 0xFF000000.toInt(),
    val lockAspectRatio: Boolean = true
)

data class ComposedPageConfig(
    val preset: PageSizePreset = PageSizePreset.A4,
    val orientation: PageOrientation = PageOrientation.PORTRAIT,
    val widthMm: Float = 210f,
    val heightMm: Float = 297f,
    val backgroundColor: Int = 0xFFFFFFFF.toInt(),
    val marginMm: Float = 10f,
    val showGrid: Boolean = true,
    val snapToGrid: Boolean = false,
    val showRulers: Boolean = true
)

enum class PassportSizePreset(val labelKey: String, val widthMm: Float, val heightMm: Float) {
    SIZE_35_45("size_35_45", 35f, 45f),
    SIZE_51_51("size_51_51", 50.8f, 50.8f), // 2x2 inch
    SIZE_25_35("size_25_35", 25f, 35f),
    CUSTOM("custom_size", 35f, 45f)
}

enum class PassportSheetPreset(val labelKey: String, val widthMm: Float, val heightMm: Float) {
    SHEET_4_6("sheet_4_6", 101.6f, 152.4f), // 4x6 inch
    SHEET_A4("sheet_a4", 210f, 297f),
    SHEET_CUSTOM("custom_size", 101.6f, 152.4f)
}

data class PassportConfig(
    val photoPath: String = "",
    val photoPreset: PassportSizePreset = PassportSizePreset.SIZE_35_45,
    val sheetPreset: PassportSheetPreset = PassportSheetPreset.SHEET_4_6,
    val customPhotoWidthMm: Float = 35f,
    val customPhotoHeightMm: Float = 45f,
    val customSheetWidthMm: Float = 101.6f,
    val customSheetHeightMm: Float = 152.4f,
    val isFitMaximum: Boolean = true,
    val copiesCount: Int = 8,
    val gapMm: Float = 3f,
    val marginMm: Float = 5f,
    val showCutLines: Boolean = true
)

enum class ExportFormat {
    PDF,
    JPG,
    PNG
}

enum class ExportQuality(val scale: Float, val jpegQuality: Int, val dpi: Int) {
    ORIGINAL(1.0f, 100, 300),
    HIGH(1.0f, 90, 300),
    MEDIUM(0.7f, 80, 150),
    SMALL(0.5f, 65, 100)
}

data class StorageInfo(
    val usedBytes: Long = 0L,
    val availableBytes: Long = 1024L * 1024L * 1024L * 8L, // 8 GB default
    val totalBytes: Long = 1024L * 1024L * 1024L * 16L,
    val percent: Int = 5,
    val isPersistentGranted: Boolean = true,
    val isSimulated80: Boolean = false,
    val isSimulated95: Boolean = false,
    val isSimulatedQuotaError: Boolean = false
)
