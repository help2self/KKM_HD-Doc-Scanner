package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "documents",
    indices = [Index(value = ["folderId"])]
)
data class DocumentEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val folderId: String? = null,
    val tagIdsJson: String = "[]",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "pages",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["documentId"]), Index(value = ["pageOrder"])]
)
data class PageEntity(
    @PrimaryKey
    val id: String,
    val documentId: String,
    val pageOrder: Int,
    val pageType: String = "scan", // "scan" or "composed"
    val originalImagePath: String = "",
    val thumbnailImagePath: String = "",
    val editParamsJson: String = "{}",
    val cropCornersJson: String = "{}",
    val filterType: String = "ORIGINAL",
    val rotationDeg: Int = 0,
    val composedObjectsJson: String = "[]",
    val composedConfigJson: String = "{}"
)

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tags")
data class TagEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val colorHex: String = "#3B82F6"
)
