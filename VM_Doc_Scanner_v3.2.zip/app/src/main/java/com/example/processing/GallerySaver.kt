package com.example.processing

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Saves exported files where the user can actually find them:
 *  - Images (JPG / PNG) -> phone Gallery, album "Pictures/<folder>"
 *  - PDF -> "Documents/<folder>" (visible in Files app and file managers)
 *  - Or, if the user picked a custom folder in Settings, straight into that folder.
 *
 * Settings are kept in SharedPreferences "scanner_prefs":
 *  - "save_folder_name"  : album / sub-folder name (default "VM Doc Scanner")
 *  - "save_tree_uri"     : optional custom folder chosen with the system folder picker
 */
object GallerySaver {

    const val DEFAULT_FOLDER = "VM Doc Scanner"
    private const val PREFS = "scanner_prefs"
    private const val KEY_FOLDER = "save_folder_name"
    private const val KEY_TREE = "save_tree_uri"

    fun folderName(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_FOLDER, DEFAULT_FOLDER)?.ifBlank { DEFAULT_FOLDER } ?: DEFAULT_FOLDER

    fun setFolderName(context: Context, name: String) {
        val clean = name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "").ifBlank { DEFAULT_FOLDER }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_FOLDER, clean).apply()
    }

    fun customTreeUri(context: Context): Uri? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TREE, null)?.let { Uri.parse(it) }

    fun setCustomTreeUri(context: Context, uri: Uri?) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (uri == null) prefs.remove(KEY_TREE) else prefs.putString(KEY_TREE, uri.toString())
        prefs.apply()
    }

    /** Human readable description of where files go, shown in Settings and after saving. */
    fun describeLocation(context: Context, isPdf: Boolean? = null): String {
        val tree = customTreeUri(context)
        if (tree != null) {
            val docId = try { DocumentsContract.getTreeDocumentId(tree) } catch (e: Exception) { null }
            // "primary:Download/Scans" -> "Internal storage/Download/Scans"
            val readable = docId?.replace("primary:", "Internal storage/")?.replace(":", "/") ?: tree.toString()
            return readable
        }
        val folder = folderName(context)
        return when (isPdf) {
            true -> "Documents/$folder"
            false -> "Pictures/$folder (Gallery)"
            null -> "Pictures/$folder (images) • Documents/$folder (PDF)"
        }
    }

    /**
     * Copies [file] to the public location. Returns a short text telling the user where it went,
     * or throws on failure.
     */
    suspend fun save(context: Context, file: File, displayName: String, mimeType: String): String = withContext(Dispatchers.IO) {
        val isPdf = mimeType == "application/pdf"
        val tree = customTreeUri(context)
        if (tree != null) {
            try {
                saveToTree(context, tree, file, displayName, mimeType)
                return@withContext describeLocation(context, isPdf) + "/" + displayName
            } catch (e: Exception) {
                // Permission to the folder was lost -> fall back to the standard location
                e.printStackTrace()
                setCustomTreeUri(context, null)
            }
        }

        val folder = folderName(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    (if (isPdf) Environment.DIRECTORY_DOCUMENTS else Environment.DIRECTORY_PICTURES) + "/" + folder
                )
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val collection = if (isPdf) {
                MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val uri = resolver.insert(collection, values) ?: throw IllegalStateException("Could not create file")
            try {
                resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                    ?: throw IllegalStateException("Could not open file")
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
        } else {
            // Android 9 and older: write into the public folder (needs WRITE_EXTERNAL_STORAGE)
            @Suppress("DEPRECATION")
            val base = Environment.getExternalStoragePublicDirectory(
                if (isPdf) Environment.DIRECTORY_DOCUMENTS else Environment.DIRECTORY_PICTURES
            )
            val dir = File(base, folder).apply { mkdirs() }
            val dest = uniqueFile(dir, displayName)
            file.copyTo(dest, overwrite = false)
            MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf(mimeType), null)
        }
        describeLocation(context, isPdf) + "/" + displayName
    }

    private fun saveToTree(context: Context, tree: Uri, file: File, displayName: String, mimeType: String) {
        val resolver = context.contentResolver
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val nameNoExt = displayName.substringBeforeLast('.')
        val newDoc = DocumentsContract.createDocument(resolver, parent, mimeType, nameNoExt)
            ?: throw IllegalStateException("Could not create file in chosen folder")
        resolver.openOutputStream(newDoc)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            ?: throw IllegalStateException("Could not write file in chosen folder")
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var i = 1
        while (f.exists()) {
            f = File(dir, if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext")
            i++
        }
        return f
    }

    /** Removes characters that are not allowed in file names. */
    fun safeName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "scan" }
}
