package com.example

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.CornerPoints
import com.example.i18n.I18n
import com.example.i18n.Language
import com.example.processing.ImageProcessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VM Doc Scanner", appName)
    }

    @Test
    fun `i18n hindi dictionary returns correct devanagari strings`() {
        val titleHindi = I18n.get("app_title", Language.HINDI)
        assertEquals("VM Doc Scanner", titleHindi)

        val autoDetectFailedHindi = I18n.get("auto_detect_failed", Language.HINDI)
        assertTrue(autoDetectFailedHindi.contains("ऑटो डिटेक्ट विफल"))

        val dateStr = I18n.formatDate(1700000000000L, Language.HINDI)
        assertTrue(dateStr.contains("/"))
    }

    @Test
    fun `auto crop fallback on uniform image returns full bounds`() = runBlocking {
        // Uniform white bitmap has no edges -> auto detect fails gracefully
        val bmp = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(android.graphics.Color.WHITE)

        val (corners, success) = ImageProcessor.detectCorners(bmp)
        assertFalse("Auto detect should gracefully fail on featureless image", success)
        assertEquals(0f, corners.tlX, 0.01f)
        assertEquals(0f, corners.tlY, 0.01f)
        assertEquals(1f, corners.brX, 0.01f)
        assertEquals(1f, corners.brY, 0.01f)
    }
}
